// ⚠️  IMPORTANT: Change this to your computer's local IP address
// How to find your IP:
//   Windows → open CMD → type: ipconfig → look for IPv4 Address
//   Mac     → open Terminal → type: ifconfig | grep "inet " → look for 192.168.x.x
//
// Your phone and computer must be on the SAME WiFi network.
//
// Example: if your IP is 192.168.1.50, change to:
//   export const API_BASE_URL = 'http://192.168.1.50:3000/api/v1';
//   export const SOCKET_URL   = 'http://192.168.1.50:3000';

export const API_BASE_URL = 'http://192.168.1.6:3000/api/v1';
export const SOCKET_URL   = 'http://192.168.1.6:3000';
export const SOCKET_NAMESPACE = '/realtime';

export const SERVICE_TYPES = [
  { key: 'electrician',   label: 'Electrician', icon: '⚡' },
  { key: 'plumber',       label: 'Plumber',     icon: '🔧' },
  { key: 'ac_technician', label: 'AC Tech',     icon: '❄️' },
  { key: 'painter',       label: 'Painter',     icon: '🎨' },
  { key: 'carpenter',     label: 'Carpenter',   icon: '🔨' },
  { key: 'cleaner',       label: 'Cleaner',     icon: '🧹' },
  { key: 'welder',        label: 'Welder',      icon: '🔥' },
  { key: 'other',         label: 'Other',       icon: '🛠️' },
];

export const BOOKING_STATUS_LABELS: Record<string,string> = {
  pending:'Pending', accepted:'Accepted', en_route:'En Route',
  in_progress:'In Progress', completed:'Completed', confirmed:'Confirmed',
  cancelled:'Cancelled', rejected:'Rejected',
};

export const BOOKING_STATUS_COLORS: Record<string,string> = {
  pending:'#F59E0B', accepted:'#3B82F6', en_route:'#8B5CF6',
  in_progress:'#FF5C1A', completed:'#22C55E', confirmed:'#22C55E',
  cancelled:'#EF4444', rejected:'#EF4444',
};
