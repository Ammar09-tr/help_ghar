export const Colors = {
  primary: '#FF5C1A',
  primaryDark: '#E04A0F',
  primaryLight: '#FF8C5A',
  primaryBg: 'rgba(255,92,26,0.12)',
  bg: '#0D0D0D',
  surface: '#181818',
  surface2: '#232323',
  surface3: '#2D2D2D',
  text: '#F5F5F0',
  textMuted: '#888880',
  textLight: '#BBBBBB',
  success: '#22C55E',
  successBg: 'rgba(34,197,94,0.12)',
  warning: '#F59E0B',
  warningBg: 'rgba(245,158,11,0.12)',
  danger: '#EF4444',
  dangerBg: 'rgba(239,68,68,0.12)',
  info: '#3B82F6',
  infoBg: 'rgba(59,130,246,0.12)',
  border: 'rgba(255,255,255,0.08)',
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
};

export const Spacing = { xs:4, sm:8, md:12, lg:16, xl:20, xxl:24, xxxl:32 };
export const Radius  = { sm:8, md:12, lg:16, xl:20, full:999 };
export const FontSize = { xs:11, sm:12, md:14, lg:16, xl:18, xxl:20, xxxl:24, display:28, hero:36 };
export const FontWeight = {
  regular:'400' as const, medium:'500' as const,
  semibold:'600' as const, bold:'700' as const, extrabold:'800' as const,
};
export const Shadow = {
  sm:  { shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.3, shadowRadius:4,  elevation:3 },
  md:  { shadowColor:'#000', shadowOffset:{width:0,height:4}, shadowOpacity:0.4, shadowRadius:8,  elevation:6 },
  primary: { shadowColor:'#FF5C1A', shadowOffset:{width:0,height:4}, shadowOpacity:0.4, shadowRadius:12, elevation:8 },
};
