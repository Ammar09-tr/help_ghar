export type UserRole = 'customer'|'technician'|'admin';
export type ServiceType = 'electrician'|'plumber'|'ac_technician'|'painter'|'carpenter'|'cleaner'|'welder'|'other';
export type TechnicianStatus = 'pending'|'approved'|'rejected'|'suspended';
export type TechnicianAvailability = 'online'|'offline'|'busy';
export type BookingStatus = 'pending'|'accepted'|'en_route'|'in_progress'|'completed'|'confirmed'|'cancelled'|'rejected';
export type CommissionStatus = 'pending'|'paid';
export type VerificationStatus = 'unverified'|'pending'|'verified'|'rejected';

export interface User {
  _id:string; fullName:string; email:string; phone:string; role:UserRole;
  isActive:boolean; profilePicture?:string;
  totalBookings:number; averageRating:number; totalRatings:number; createdAt?:string;
}
export interface Technician {
  _id:string; user:User|string; skill:ServiceType; cnic?:string;
  cnicFrontImage?:string; cnicBackImage?:string; cnicVerificationStatus?:VerificationStatus;
  status:TechnicianStatus; availability:TechnicianAvailability;
  isCommissionLocked:boolean; pendingCommission:number;
  totalEarnings:number; totalJobs:number; averageRating:number; totalRatings:number;
  activeBooking?:string|null; bio?:string; yearsOfExperience:number;
  currentLocation?:{type:string;coordinates:[number,number];updatedAt:string};
}
export interface Booking {
  _id:string; customer:User|string; technician?:Technician|string;
  serviceType:ServiceType; problemDescription:string; problemImages?:string[];
  customerLocation:{type:string;coordinates:[number,number];address:string;city:string};
  status:BookingStatus; quotedPrice?:number; finalPrice?:number;
  commissionAmount?:number; commissionPaid?:boolean;
  customerNote?:string; technicianNote?:string; scheduledFor?:string;
  acceptedAt?:string; startedAt?:string; completedAt?:string; confirmedAt?:string;
  customerRating?:number; customerReview?:string;
  cancellationReason?:string; cancelledBy?:string;
  createdAt:string; updatedAt:string;
}
export interface Message {
  _id:string; booking:string; sender:User|string;
  content:string; isRead:boolean; readAt?:string; createdAt:string;
}
export interface Commission {
  _id:string; technician:Technician|string; booking:Booking|string;
  jobPrice:number; commissionRate:number; commissionAmount:number;
  status:CommissionStatus; paidAt?:string; paymentMethod?:string; transactionId?:string; createdAt:string;
}
export interface Notification {
  _id:string; user:string; title:string; message:string;
  type:'booking'|'chat'|'commission'|'system'|'payment';
  isRead:boolean; data?:Record<string,any>; createdAt:string;
}
export interface AuthResponse {
  access_token:string;
  user:{_id:string;fullName:string;email:string;phone:string;role:UserRole};
}
