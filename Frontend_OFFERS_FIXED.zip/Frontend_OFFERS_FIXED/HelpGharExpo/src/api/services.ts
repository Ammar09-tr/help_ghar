import apiClient from './client';
import { AuthResponse, Booking, Technician, User, Message, Commission } from '../types';

export const authApi = {
  registerCustomer: (data:{fullName:string;email:string;phone:string;password:string}) =>
    apiClient.post<AuthResponse>('/auth/register/customer', data),
  registerTechnician: (data:{fullName:string;email:string;phone:string;password:string;cnic:string;skill:string;yearsOfExperience?:number;bio?:string}) =>
    apiClient.post('/auth/register/technician', data),
  login: (data:{email:string;password:string}) =>
    apiClient.post<AuthResponse>('/auth/login', data),
  getMe: () => apiClient.get<User>('/auth/me'),
};

export const usersApi = {
  getProfile: () => apiClient.get<User>('/users/profile'),
  updateProfile: (data:{fullName?:string;email?:string;phone?:string}) =>
    apiClient.patch<User>('/users/profile', data),
  updateFcmToken: (fcmToken:string) =>
    apiClient.patch<User>('/users/profile', data),
};

export const techniciansApi = {
  getMyProfile: () => apiClient.get<Technician>('/technicians/me'),
  updateAvailability: (availability:'online'|'offline'|'busy') =>
    apiClient.patch('/technicians/me/availability', { availability }),
  updateLocation: (longitude:number, latitude:number) =>
    apiClient.patch('/technicians/me/location', { longitude, latitude }),
  getNearby: (serviceType:string, longitude:number, latitude:number, radius=15) =>
    apiClient.get<Technician[]>('/technicians/nearby', { params:{serviceType,longitude,latitude,radius} }),
};

export const bookingsApi = {
  create: (data:{serviceType:string;problemDescription:string;customerNote?:string;customerLocation:{longitude:number;latitude:number;address:string;city:string}}) =>
    apiClient.post<Booking>('/bookings', data),
  getMyBookings: (status?:string) =>
    apiClient.get<Booking[]>('/bookings/my', { params: status?{status}:{} }),
  getNearbyPending: (radius=10) =>
    apiClient.get<Booking[]>('/bookings/nearby', { params:{radius} }),
  getMyJobs: (status?:string) =>
    apiClient.get<Booking[]>('/bookings/tech/my-jobs', { params: status?{status}:{} }),
  getById: (id:string) => apiClient.get<Booking>(`/bookings/${id}`),
  // ── InDrive Multi-Offer ──
  sendOffer: (id:string, price:number, note?:string) =>
    apiClient.post(`/bookings/${id}/offer`, { price, note }),
  getOffers: (id:string) =>
    apiClient.get(`/bookings/${id}/offers`),
  selectOffer: (bookingId:string, offerId:string) =>
    apiClient.patch(`/bookings/${bookingId}/select-offer`, { offerId }),
  rejectOffer: (bookingId:string, offerId:string) =>
    apiClient.patch(`/bookings/${bookingId}/reject-offer`, { offerId }),
  // ── Lifecycle ──
  accept: (id:string) => apiClient.patch<Booking>(`/bookings/${id}/accept`),
  reject: (id:string) => apiClient.patch(`/bookings/${id}/reject`),
  setPrice: (id:string, quotedPrice:number, technicianNote?:string) =>
    apiClient.patch<Booking>(`/bookings/${id}/set-price`, {quotedPrice,technicianNote}),
  startJob: (id:string) => apiClient.patch<Booking>(`/bookings/${id}/start`),
  completeJob: (id:string) => apiClient.patch<Booking>(`/bookings/${id}/complete`),
  confirmCompletion: (id:string, data:{finalPrice:number;rating:number;review?:string}) =>
    apiClient.patch<Booking>(`/bookings/${id}/confirm`, data),
  cancel: (id:string, reason?:string) =>
    apiClient.patch(`/bookings/${id}/cancel`, {reason}),
};

export const chatApi = {
  sendMessage: (bookingId:string, content:string) =>
    apiClient.post<Message>(`/chat/${bookingId}/messages`, {content}),
  getMessages: (bookingId:string) =>
    apiClient.get<Message[]>(`/chat/${bookingId}/messages`),
  getUnreadCount: () => apiClient.get<number>('/chat/unread-count'),
};

export const commissionApi = {
  getMyPending: () => apiClient.get<Commission[]>('/commission/my/pending'),
  getMyHistory: () => apiClient.get<Commission[]>('/commission/my/history'),
  pay: (paymentMethod:string, transactionId?:string) =>
    apiClient.post('/commission/pay', {paymentMethod,transactionId}),
  adminGetStats: () => apiClient.get('/commission/admin/stats'),
  adminGetAllPending: () => apiClient.get<Commission[]>('/commission/admin/pending'),
};

export const adminApi = {
  getDashboard: () => apiClient.get('/admin/dashboard'),
  getTechnicians: (status?:string) =>
    apiClient.get<Technician[]>('/admin/technicians', { params: status?{status}:{} }),
  approveTechnician: (id:string) => apiClient.patch(`/admin/technicians/${id}/approve`),
  rejectTechnician: (id:string, reason?:string) =>
    apiClient.patch(`/admin/technicians/${id}/reject`, {reason}),
  suspendTechnician: (id:string) => apiClient.patch(`/admin/technicians/${id}/suspend`),
  getUsers: (role?:string) =>
    apiClient.get<User[]>('/admin/users', { params: role?{role}:{} }),
  deactivateUser: (id:string) => apiClient.delete(`/admin/users/${id}`),
  getAllBookings: (status?:string) =>
    apiClient.get<Booking[]>('/admin/bookings', { params: status?{status}:{} }),
  cancelBooking: (id:string, reason:string) =>
    apiClient.patch(`/admin/bookings/${id}/cancel`, {reason}),
  markCommissionPaid: (id:string) =>
    apiClient.patch(`/admin/commission/${id}/mark-paid`),
  adminGetStats: () => apiClient.get('/commission/admin/stats'),
};
