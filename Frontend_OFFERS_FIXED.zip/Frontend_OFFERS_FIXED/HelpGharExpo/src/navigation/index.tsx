import React, { useEffect } from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuthStore } from '../store/authStore';
import { Colors, FontSize } from '../constants/theme';

// Auth
import SplashScreen          from '../screens/auth/SplashScreen';
import LoginScreen           from '../screens/auth/LoginScreen';
import RegisterScreen        from '../screens/auth/RegisterScreen';
import ForgotPasswordScreen  from '../screens/auth/ForgotPasswordScreen';

// Customer
import CustomerHome          from '../screens/customer/HomeScreen';
import BookServiceScreen     from '../screens/customer/BookServiceScreen';
import MyBookingsScreen      from '../screens/customer/MyBookingsScreen';
import BookingDetailScreen   from '../screens/customer/BookingDetailScreen';
import TrackBookingScreen    from '../screens/customer/TrackBookingScreen';
import TechnicianListScreen  from '../screens/customer/TechnicianListScreen';
import OffersScreen          from '../screens/customer/OffersScreen';

// Technician
import TechHomeScreen        from '../screens/technician/HomeScreen';
import TechJobsScreen        from '../screens/technician/JobsScreen';
import SetPriceScreen        from '../screens/technician/SetPriceScreen';
import ActiveJobScreen       from '../screens/technician/ActiveJobScreen';
import CommissionScreen      from '../screens/technician/CommissionScreen';
import EarningsScreen        from '../screens/technician/EarningsScreen';
import CnicUploadScreen      from '../screens/technician/CnicUploadScreen';

// Admin
import AdminDashScreen       from '../screens/admin/DashboardScreen';
import AdminTechsScreen      from '../screens/admin/TechniciansScreen';
import AdminBookingsScreen   from '../screens/admin/BookingsScreen';
import AdminUsersScreen      from '../screens/admin/UsersScreen';

// Shared
import ChatScreen            from '../screens/shared/ChatScreen';
import ProfileScreen         from '../screens/shared/ProfileScreen';
import NotificationsScreen   from '../screens/shared/NotificationsScreen';
import SupportScreen         from '../screens/shared/SupportScreen';
import PaymentScreen         from '../screens/shared/PaymentScreen';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();
const NO_HEADER = { headerShown: false, animation: 'slide_from_right' as const };

function TabIcon({ name, focused }: { name:string; focused:boolean }) {
  const icons: Record<string,string> = {
    Home:'🏠', Bookings:'📋', Chat:'💬', Profile:'👤',
    Dashboard:'🏠', Jobs:'📋', Earnings:'💰',
    'Admin Home':'📊', Technicians:'🔧', 'All Bookings':'📋', Users:'👥',
  };
  return <Text style={{ fontSize: focused ? 22 : 19, opacity: focused ? 1 : 0.55 }}>{icons[name]||'●'}</Text>;
}

function CustomerTabs() {
  return (
    <Tab.Navigator screenOptions={({route})=>({
      headerShown:false, tabBarStyle:styles.tabBar,
      tabBarActiveTintColor:Colors.primary, tabBarInactiveTintColor:Colors.textMuted,
      tabBarLabelStyle:styles.tabLabel,
      tabBarIcon:({focused})=><TabIcon name={route.name} focused={focused}/>,
    })}>
      <Tab.Screen name="Home"     component={CustomerHome}    />
      <Tab.Screen name="Bookings" component={MyBookingsScreen} />
      <Tab.Screen name="Chat"     component={ChatScreen}      />
      <Tab.Screen name="Profile"  component={ProfileScreen}   />
    </Tab.Navigator>
  );
}

function TechnicianTabs() {
  return (
    <Tab.Navigator screenOptions={({route})=>({
      headerShown:false, tabBarStyle:styles.tabBar,
      tabBarActiveTintColor:Colors.primary, tabBarInactiveTintColor:Colors.textMuted,
      tabBarLabelStyle:styles.tabLabel,
      tabBarIcon:({focused})=><TabIcon name={route.name} focused={focused}/>,
    })}>
      <Tab.Screen name="Dashboard" component={TechHomeScreen} />
      <Tab.Screen name="Jobs"      component={TechJobsScreen} />
      <Tab.Screen name="Earnings"  component={EarningsScreen} />
      <Tab.Screen name="Profile"   component={ProfileScreen}  />
    </Tab.Navigator>
  );
}

function AdminTabs() {
  return (
    <Tab.Navigator screenOptions={({route})=>({
      headerShown:false, tabBarStyle:styles.tabBar,
      tabBarActiveTintColor:Colors.primary, tabBarInactiveTintColor:Colors.textMuted,
      tabBarLabelStyle:styles.tabLabel,
      tabBarIcon:({focused})=><TabIcon name={route.name} focused={focused}/>,
    })}>
      <Tab.Screen name="Admin Home"   component={AdminDashScreen}     />
      <Tab.Screen name="Technicians"  component={AdminTechsScreen}    />
      <Tab.Screen name="All Bookings" component={AdminBookingsScreen} />
      <Tab.Screen name="Users"        component={AdminUsersScreen}    />
      <Tab.Screen name="Profile"      component={ProfileScreen}       />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { isAuthenticated, user, isLoading, loadFromStorage } = useAuthStore();
  useEffect(() => { loadFromStorage(); }, []);

  if (isLoading) return (
    <View style={styles.loading}>
      <ActivityIndicator size="large" color={Colors.primary}/>
    </View>
  );

  const initialRoute =
    !isAuthenticated              ? 'Splash'
    : user?.role === 'technician' ? 'TechnicianApp'
    : user?.role === 'admin'      ? 'AdminApp'
    : 'CustomerApp';

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={initialRoute} screenOptions={NO_HEADER}>
        {/* Auth */}
        <Stack.Screen name="Splash"          component={SplashScreen}         />
        <Stack.Screen name="Login"           component={LoginScreen}          />
        <Stack.Screen name="Register"        component={RegisterScreen}       />
        <Stack.Screen name="ForgotPassword"  component={ForgotPasswordScreen} />

        {/* Customer */}
        <Stack.Screen name="CustomerApp"     component={CustomerTabs}         />
        <Stack.Screen name="BookService"     component={BookServiceScreen}    />
        <Stack.Screen name="TechnicianList"  component={TechnicianListScreen} />
        <Stack.Screen name="TrackBooking"    component={TrackBookingScreen}   />
        <Stack.Screen name="BookingDetail"   component={BookingDetailScreen}  />
        <Stack.Screen name="Offers"          component={OffersScreen}         />

        {/* Technician */}
        <Stack.Screen name="TechnicianApp"  component={TechnicianTabs}   />
        <Stack.Screen name="SetPrice"       component={SetPriceScreen}   />
        <Stack.Screen name="ActiveJob"      component={ActiveJobScreen}  />
        <Stack.Screen name="Commission"     component={CommissionScreen} />
        <Stack.Screen name="CnicUpload"     component={CnicUploadScreen} />

        {/* Shared */}
        <Stack.Screen name="Chat"           component={ChatScreen}           />
        <Stack.Screen name="Notifications"  component={NotificationsScreen}  />
        <Stack.Screen name="Support"        component={SupportScreen}        />
        <Stack.Screen name="Payment"        component={PaymentScreen}        />

        {/* Admin */}
        <Stack.Screen name="AdminApp"       component={AdminTabs}            />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loading: {flex:1, backgroundColor:Colors.bg, alignItems:'center', justifyContent:'center'},
  tabBar:  {backgroundColor:Colors.surface, borderTopColor:Colors.border, borderTopWidth:1, paddingBottom:8, paddingTop:4, height:62},
  tabLabel:{fontSize:FontSize.xs, fontWeight:'600'},
});
