import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';

interface AuthState {
  token: string|null; user: User|null;
  isLoading: boolean; isAuthenticated: boolean;
  setAuth: (token:string, user:User) => Promise<void>;
  updateUser: (u:Partial<User>) => void;
  logout: () => Promise<void>;
  loadFromStorage: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  token: null, user: null, isLoading: true, isAuthenticated: false,

  setAuth: async (token, user) => {
    await AsyncStorage.setItem('hg_token', token);
    await AsyncStorage.setItem('hg_user', JSON.stringify(user));
    set({ token, user, isAuthenticated: true });
  },

  updateUser: (partial) => {
    const cur = get().user;
    if (!cur) return;
    const updated = { ...cur, ...partial };
    set({ user: updated });
    AsyncStorage.setItem('hg_user', JSON.stringify(updated));
  },

  logout: async () => {
    await AsyncStorage.multiRemove(['hg_token','hg_user']);
    set({ token:null, user:null, isAuthenticated:false });
  },

  loadFromStorage: async () => {
    try {
      const token = await AsyncStorage.getItem('hg_token');
      const userStr = await AsyncStorage.getItem('hg_user');
      const user = userStr ? JSON.parse(userStr) : null;
      set({ token, user, isAuthenticated:!!token, isLoading:false });
    } catch {
      set({ isLoading:false });
    }
  },
}));
