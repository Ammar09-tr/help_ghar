import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Notification } from '../types';

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  addLocalNotification: (title:string, message:string, type:Notification['type'], data?:any) => void;
  markRead: (id:string) => void;
  markAllRead: () => void;
  clearAll: () => void;
  loadFromStorage: () => Promise<void>;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,

  addLocalNotification: (title, message, type, data) => {
    const n: Notification = {
      _id: Date.now().toString() + Math.random().toString(36).slice(2),
      user: '',
      title, message, type,
      isRead: false,
      data,
      createdAt: new Date().toISOString(),
    };
    set(state => {
      const updated = [n, ...state.notifications].slice(0, 50);
      AsyncStorage.setItem('hg_notifications', JSON.stringify(updated));
      return { notifications: updated, unreadCount: state.unreadCount + 1 };
    });
  },

  markRead: (id) => {
    set(state => {
      const updated = state.notifications.map(n => n._id === id ? { ...n, isRead: true } : n);
      const unread = updated.filter(n => !n.isRead).length;
      AsyncStorage.setItem('hg_notifications', JSON.stringify(updated));
      return { notifications: updated, unreadCount: unread };
    });
  },

  markAllRead: () => {
    set(state => {
      const updated = state.notifications.map(n => ({ ...n, isRead: true }));
      AsyncStorage.setItem('hg_notifications', JSON.stringify(updated));
      return { notifications: updated, unreadCount: 0 };
    });
  },

  clearAll: () => {
    AsyncStorage.removeItem('hg_notifications');
    set({ notifications: [], unreadCount: 0 });
  },

  loadFromStorage: async () => {
    try {
      const stored = await AsyncStorage.getItem('hg_notifications');
      if (stored) {
        const notifs = JSON.parse(stored) as Notification[];
        set({ notifications: notifs, unreadCount: notifs.filter(n => !n.isRead).length });
      }
    } catch {}
  },
}));
