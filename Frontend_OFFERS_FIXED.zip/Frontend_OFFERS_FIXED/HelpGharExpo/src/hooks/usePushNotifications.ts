import { useEffect, useRef } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { useAuthStore } from '../store/authStore';
import { usersApi } from '../api/services';

// ── Configure how notifications appear ────────────────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  true,
  }),
});

export const usePushNotifications = (navigation?: any) => {
  const user  = useAuthStore(s => s.user);
  const token = useAuthStore(s => s.token);
  const notifListener = useRef<any>();
  const responseListener = useRef<any>();

  useEffect(() => {
    if (!token || !user) return;
    registerForPushNotifications();
    setupListeners();
    return () => {
      Notifications.removeNotificationSubscription(notifListener.current);
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, [token]);

  const registerForPushNotifications = async () => {
    try {
      if (!Device.isDevice) {
        console.log('Push notifications only work on physical devices');
        return;
      }

      const { status: existing } = await Notifications.getPermissionsAsync();
      let finalStatus = existing;

      if (existing !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        console.log('Push notification permission denied');
        return;
      }

      // Get Expo push token
      const tokenData = await Notifications.getExpoPushTokenAsync({
        projectId: 'your-expo-project-id', // from app.json extra.eas.projectId
      });

      console.log('📱 Push token:', tokenData.data);

      // Save token to backend
      try {
        await usersApi.updateFcmToken(tokenData.data);
        console.log('✅ FCM token saved to backend');
      } catch (err) {
        console.log('Failed to save FCM token:', err);
      }

      if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('helpghar', {
          name: 'HelpGhar Notifications',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF5C1A',
          sound: 'default',
        });
      }
    } catch (err) {
      console.log('Push notification setup error:', err);
    }
  };

  const setupListeners = () => {
    // Notification received while app is open
    notifListener.current = Notifications.addNotificationReceivedListener(notification => {
      console.log('📩 Notification received:', notification.request.content.title);
    });

    // User tapped on notification
    responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
      const data = response.notification.request.content.data as any;
      console.log('👆 Notification tapped:', data);

      if (!navigation) return;

      // Navigate based on notification type
      if (data?.bookingId) {
        if (data?.type === 'chat') {
          navigation.navigate('Chat', { bookingId: data.bookingId });
        } else if (data?.type === 'offer') {
          navigation.navigate('BookingDetail', { bookingId: data.bookingId });
        } else {
          navigation.navigate('BookingDetail', { bookingId: data.bookingId });
        }
      } else if (data?.type === 'commission') {
        navigation.navigate('Commission');
      }
    });
  };
};

// ── Send local notification (when app is foreground) ──────────────────────────
export const sendLocalNotification = async (
  title: string,
  body: string,
  data?: Record<string, any>
) => {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, data: data || {}, sound: 'default' },
    trigger: null,
  });
};
