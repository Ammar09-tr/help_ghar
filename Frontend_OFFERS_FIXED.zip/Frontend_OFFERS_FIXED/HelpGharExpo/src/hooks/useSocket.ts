import { useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { SOCKET_URL, SOCKET_NAMESPACE } from '../constants/api';
import { useAuthStore } from '../store/authStore';

let socket: Socket | null = null;

export const useSocket = () => {
  const token = useAuthStore(s => s.token);

  const connect = useCallback(() => {
    if (!token) return;
    if (socket?.connected) return;

    if (socket) { socket.disconnect(); socket = null; }

    console.log('🔌 Connecting to:', SOCKET_URL + SOCKET_NAMESPACE);
    socket = io(`${SOCKET_URL}${SOCKET_NAMESPACE}`, {
      auth: { token },
      transports: ['polling', 'websocket'], // polling first for stability
      reconnection: true,
      reconnectionAttempts: 15,
      reconnectionDelay: 2000,
      timeout: 20000,
      forceNew: true,
    });

    socket.on('connect',       () => console.log('✅ Socket connected:', socket?.id));
    socket.on('connected',     (d: any) => console.log('✅ Server:', d?.message));
    socket.on('disconnect',    (r: any) => console.log('🔴 Disconnected:', r));
    socket.on('connect_error', (e: any) => console.log('❌ Error:', e.message));
  }, [token]);

  const disconnect = useCallback(() => {
    if (socket) { socket.disconnect(); socket = null; }
  }, []);

  const on = useCallback((event: string, handler: (...a: any[]) => void) => {
    if (!socket) return () => {};
    socket.on(event, handler);
    return () => { socket?.off(event, handler); };
  }, []);

  const emit = useCallback((event: string, data?: any) => {
    if (socket?.connected) socket.emit(event, data);
  }, []);

  const joinBookingRoom  = useCallback((id: string) => {
    if (socket?.connected) socket.emit('booking:join', { bookingId: id });
  }, []);

  const leaveBookingRoom = useCallback((id: string) => {
    if (socket?.connected) socket.emit('booking:leave', { bookingId: id });
  }, []);

  const sendTyping = useCallback((id: string, isTyping: boolean) => {
    if (socket?.connected) socket.emit('chat:typing', { bookingId: id, isTyping });
  }, []);

  const sendLocation = useCallback((id: string, lat: number, lng: number) => {
    if (socket?.connected) socket.emit('location:update', { bookingId: id, latitude: lat, longitude: lng });
  }, []);

  const isConnected = () => socket?.connected || false;

  return { connect, disconnect, on, emit, joinBookingRoom, leaveBookingRoom, sendTyping, sendLocation, isConnected };
};
