import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ActivityIndicator,
  StyleSheet, ViewStyle, TextStyle, TextInputProps,
} from 'react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

// ── Button ────────────────────────────────────────────────────────────────────
type BtnVariant = 'primary'|'outline'|'ghost'|'danger'|'success';
type BtnSize    = 'sm'|'md'|'lg';
interface BtnProps {
  title:string; onPress:()=>void; variant?:BtnVariant; size?:BtnSize;
  loading?:boolean; disabled?:boolean; icon?:string; style?:ViewStyle;
}
export const Button:React.FC<BtnProps> = ({
  title,onPress,variant='primary',size='md',loading=false,disabled=false,icon,style
})=>{
  const dis = disabled||loading;
  const bgColor:Record<BtnVariant,string> = {
    primary:Colors.primary, outline:Colors.transparent,
    ghost:Colors.surface2, danger:Colors.danger, success:Colors.success,
  };
  const txtColor:Record<BtnVariant,string> = {
    primary:Colors.white, outline:Colors.text,
    ghost:Colors.text, danger:Colors.white, success:Colors.white,
  };
  const pad:Record<BtnSize,ViewStyle> = {
    sm:{ paddingVertical:10,paddingHorizontal:16 },
    md:{ paddingVertical:14,paddingHorizontal:20,width:'100%' },
    lg:{ paddingVertical:16,paddingHorizontal:24,width:'100%' },
  };
  return (
    <TouchableOpacity
      style={[styles.btnBase,{backgroundColor:bgColor[variant]},
        variant==='outline'&&{borderWidth:1.5,borderColor:Colors.border},
        pad[size],dis&&{opacity:0.5},style]}
      onPress={onPress} disabled={dis} activeOpacity={0.8}
    >
      {loading
        ? <ActivityIndicator color={variant==='outline'||variant==='ghost'?Colors.primary:Colors.white} size="small"/>
        : <Text style={{fontSize:FontSize.md,fontWeight:FontWeight.semibold,color:txtColor[variant]}}>
            {icon?`${icon}  `:''}{title}
          </Text>
      }
    </TouchableOpacity>
  );
};

// ── Input ─────────────────────────────────────────────────────────────────────
interface InputProps extends TextInputProps {
  label?:string; error?:string; containerStyle?:ViewStyle; leftIcon?:string;
}
export const Input:React.FC<InputProps> = ({label,error,containerStyle,leftIcon,style,...props})=>{
  const [focused,setFocused] = useState(false);
  return (
    <View style={[{marginBottom:Spacing.md},containerStyle]}>
      {label&&<Text style={styles.inputLabel}>{label}</Text>}
      <View style={[styles.inputWrap,focused&&{borderColor:Colors.primary},!!error&&{borderColor:Colors.danger}]}>
        {leftIcon&&<Text style={{fontSize:18,marginRight:Spacing.sm}}>{leftIcon}</Text>}
        <TextInput
          style={[styles.inputField,style as TextStyle]}
          placeholderTextColor={Colors.textMuted}
          onFocus={()=>setFocused(true)}
          onBlur={()=>setFocused(false)}
          {...props}
        />
      </View>
      {error&&<Text style={{fontSize:FontSize.xs,color:Colors.danger,marginTop:4}}>{error}</Text>}
    </View>
  );
};

// ── Card ──────────────────────────────────────────────────────────────────────
interface CardProps { children:React.ReactNode; style?:ViewStyle; onPress?:()=>void; highlight?:boolean; }
export const Card:React.FC<CardProps> = ({children,style,onPress,highlight})=>{
  const s = [styles.card,highlight&&{borderColor:'rgba(255,92,26,0.4)'},style];
  if(onPress) return <TouchableOpacity style={s as any} onPress={onPress} activeOpacity={0.85}>{children}</TouchableOpacity>;
  return <View style={s as any}>{children}</View>;
};

// ── Badge ─────────────────────────────────────────────────────────────────────
interface BadgeProps { label:string; color?:string; bg?:string; dot?:boolean; }
export const Badge:React.FC<BadgeProps> = ({label,color=Colors.primary,bg=Colors.primaryBg,dot})=>(
  <View style={{flexDirection:'row',alignItems:'center',gap:4,paddingVertical:4,paddingHorizontal:10,borderRadius:Radius.full,backgroundColor:bg}}>
    {dot&&<View style={{width:6,height:6,borderRadius:3,backgroundColor:color}}/>}
    <Text style={{fontSize:FontSize.xs,fontWeight:FontWeight.semibold,color}}>{label}</Text>
  </View>
);

// ── Stars ─────────────────────────────────────────────────────────────────────
export const Stars:React.FC<{rating:number;size?:number}> = ({rating,size=14})=>(
  <Text style={{fontSize:size,color:Colors.warning,letterSpacing:1}}>
    {[1,2,3,4,5].map(i=>i<=Math.round(rating)?'★':'☆').join('')}
  </Text>
);

// ── Avatar ────────────────────────────────────────────────────────────────────
export const Avatar:React.FC<{emoji?:string;size?:number;bg?:string}> = ({emoji='👤',size=44,bg=Colors.surface2})=>(
  <View style={{width:size,height:size,borderRadius:size/2,backgroundColor:bg,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontSize:size*0.45}}>{emoji}</Text>
  </View>
);

// ── Divider ───────────────────────────────────────────────────────────────────
export const Divider:React.FC<{style?:ViewStyle}> = ({style})=>(
  <View style={[{height:1,backgroundColor:Colors.border,marginVertical:Spacing.lg},style]}/>
);

// ── EmptyState ────────────────────────────────────────────────────────────────
interface EmptyProps { emoji?:string; title:string; subtitle?:string; action?:string; onAction?:()=>void; }
export const EmptyState:React.FC<EmptyProps> = ({emoji='📭',title,subtitle,action,onAction})=>(
  <View style={{alignItems:'center',paddingVertical:Spacing.xxxl,paddingHorizontal:Spacing.xxl}}>
    <Text style={{fontSize:48,marginBottom:Spacing.md}}>{emoji}</Text>
    <Text style={{fontSize:FontSize.xl,fontWeight:FontWeight.bold,color:Colors.text,textAlign:'center'}}>{title}</Text>
    {subtitle&&<Text style={{fontSize:FontSize.md,color:Colors.textMuted,textAlign:'center',marginTop:Spacing.sm,lineHeight:22}}>{subtitle}</Text>}
    {action&&onAction&&<Button title={action} onPress={onAction} style={{marginTop:Spacing.lg,width:'auto',paddingHorizontal:24} as ViewStyle}/>}
  </View>
);

// ── BookingCard ───────────────────────────────────────────────────────────────
import { Booking } from '../../types';
import { BOOKING_STATUS_COLORS, BOOKING_STATUS_LABELS, SERVICE_TYPES } from '../../constants/api';

interface BCProps { booking:Booking; onPress?:()=>void; viewAs?:'customer'|'technician'|'admin'; }
export const BookingCard:React.FC<BCProps> = ({booking,onPress,viewAs='customer'})=>{
  const svc    = SERVICE_TYPES.find(s=>s.key===booking.serviceType);
  const sColor = BOOKING_STATUS_COLORS[booking.status]||Colors.textMuted;
  const tech   = booking.technician as any;
  const cust   = booking.customer  as any;
  const techUser = tech?.user||tech;
  const timeAgo = (()=>{
    try {
      const d=Date.now()-new Date(booking.createdAt).getTime();
      if(d<60000) return 'Just now';
      if(d<3600000) return `${Math.floor(d/60000)}m ago`;
      if(d<86400000) return `${Math.floor(d/3600000)}h ago`;
      return `${Math.floor(d/86400000)}d ago`;
    } catch { return ''; }
  })();
  return (
    <TouchableOpacity style={styles.bCard} onPress={onPress} activeOpacity={onPress?0.85:1}>
      <View style={{flexDirection:'row',alignItems:'center',gap:Spacing.md,marginBottom:Spacing.sm}}>
        <View style={styles.bIcon}><Text style={{fontSize:22}}>{svc?.icon||'🛠️'}</Text></View>
        <View style={{flex:1}}>
          <Text style={{fontSize:FontSize.md,fontWeight:FontWeight.bold,color:Colors.text}}>{svc?.label||booking.serviceType}</Text>
          <Text style={{fontSize:FontSize.sm,color:Colors.textMuted,marginTop:2}} numberOfLines={1}>{booking.customerLocation?.address||booking.customerLocation?.city}</Text>
          <Text style={{fontSize:FontSize.xs,color:Colors.textMuted,marginTop:1}}>{timeAgo}</Text>
        </View>
        <Badge label={BOOKING_STATUS_LABELS[booking.status]||booking.status} color={sColor} bg={sColor+'20'} dot/>
      </View>
      {booking.problemDescription&&<Text style={{fontSize:FontSize.sm,color:Colors.textLight,lineHeight:18,marginBottom:Spacing.sm}} numberOfLines={2}>{booking.problemDescription}</Text>}
      <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:Spacing.xs}}>
        {viewAs==='customer'&&techUser?.fullName&&<Text style={{fontSize:FontSize.sm,color:Colors.textMuted}}>👨‍🔧 {techUser.fullName}</Text>}
        {viewAs==='technician'&&cust?.fullName&&<Text style={{fontSize:FontSize.sm,color:Colors.textMuted}}>👤 {cust.fullName}</Text>}
        {(booking.quotedPrice||booking.finalPrice)
          ? <Text style={{fontSize:FontSize.md,fontWeight:FontWeight.bold,color:Colors.primary}}>₨ {(booking.finalPrice||booking.quotedPrice||0).toLocaleString()}</Text>
          : <Text style={{fontSize:FontSize.sm,color:Colors.textMuted}}>Price TBD</Text>
        }
      </View>
      {booking.customerRating&&(
        <View style={{flexDirection:'row',alignItems:'center',gap:Spacing.sm,marginTop:Spacing.sm,paddingTop:Spacing.sm,borderTopWidth:1,borderTopColor:Colors.border}}>
          <Stars rating={booking.customerRating}/>
          {booking.customerReview&&<Text style={{flex:1,fontSize:FontSize.xs,color:Colors.textMuted,fontStyle:'italic'}} numberOfLines={1}>"{booking.customerReview}"</Text>}
        </View>
      )}
    </TouchableOpacity>
  );
};

// ── ScreenWrapper ─────────────────────────────────────────────────────────────
import { ScrollView, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

interface SWProps {
  children:React.ReactNode; title?:string; showBack?:boolean; rightElement?:React.ReactNode;
  scrollable?:boolean; style?:ViewStyle; onRefresh?:()=>void; refreshing?:boolean; noPadding?:boolean;
}
export const ScreenWrapper:React.FC<SWProps> = ({
  children,title,showBack=false,rightElement,scrollable=false,style,onRefresh,refreshing=false,noPadding=false
})=>{
  const nav = useNavigation();
  const inner = <View style={[styles.swContent,noPadding&&{paddingHorizontal:0,paddingTop:0},style]}>{children}</View>;
  return (
    <SafeAreaView style={{flex:1,backgroundColor:Colors.bg}}>
      {(title||showBack||rightElement)&&(
        <View style={styles.swHeader}>
          {showBack
            ? <TouchableOpacity style={styles.backBtn} onPress={()=>nav.goBack()}>
                <Text style={{fontSize:18,color:Colors.text}}>←</Text>
              </TouchableOpacity>
            : <View style={{width:36}}/>
          }
          {title&&<Text style={styles.swTitle} numberOfLines={1}>{title}</Text>}
          <View style={{width:36,alignItems:'flex-end'}}>{rightElement}</View>
        </View>
      )}
      {scrollable
        ? <ScrollView showsVerticalScrollIndicator={false}
            refreshControl={onRefresh?<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary}/>:undefined}
            contentContainerStyle={{flexGrow:1}}
          >{inner}</ScrollView>
        : inner}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  btnBase:  {flexDirection:'row',alignItems:'center',justifyContent:'center',borderRadius:Radius.lg,gap:8},
  inputLabel: {fontSize:FontSize.xs,color:Colors.textMuted,fontWeight:FontWeight.medium,marginBottom:6,textTransform:'uppercase',letterSpacing:0.5},
  inputWrap:  {flexDirection:'row',alignItems:'center',backgroundColor:Colors.surface2,borderWidth:1.5,borderColor:Colors.border,borderRadius:Radius.md,paddingHorizontal:Spacing.md},
  inputField: {flex:1,color:Colors.text,fontSize:FontSize.md,paddingVertical:13},
  card: {backgroundColor:Colors.surface,borderRadius:Radius.lg,borderWidth:1,borderColor:Colors.border,padding:Spacing.lg,marginBottom:Spacing.md},
  bCard:{backgroundColor:Colors.surface,borderRadius:Radius.lg,borderWidth:1,borderColor:Colors.border,padding:Spacing.lg,marginBottom:Spacing.md},
  bIcon:{width:44,height:44,borderRadius:Radius.md,backgroundColor:Colors.surface2,alignItems:'center',justifyContent:'center'},
  swHeader:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:Spacing.xl,paddingVertical:Spacing.md,backgroundColor:Colors.bg,borderBottomWidth:1,borderBottomColor:Colors.border},
  swTitle:{flex:1,fontSize:FontSize.lg,fontWeight:FontWeight.bold,color:Colors.text,textAlign:'center'},
  swContent:{flex:1,backgroundColor:Colors.bg,paddingHorizontal:Spacing.xl,paddingTop:Spacing.xl},
  backBtn:{width:36,height:36,borderRadius:18,backgroundColor:Colors.surface2,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:Colors.border},
});
