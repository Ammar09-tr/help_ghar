import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput, ActivityIndicator
} from 'react-native';
import { bookingsApi } from '../../api/services';
import { Button, Card, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

const QUICK_PRICES = [500, 800, 1000, 1200, 1500, 2000, 2500, 3000, 4000, 5000];
const COMMISSION_RATE = 10;

export default function SetPriceScreen({ navigation, route }: any) {
  const { bookingId, mode } = route.params;
  // mode = 'offer' (InDrive bid) OR 'setprice' (after direct accept)
  const isOfferMode = mode === 'offer' || !mode;

  const [booking, setBooking]     = useState<any>(null);
  const [price, setPrice]         = useState('');
  const [note, setNote]           = useState('');
  const [loading, setLoading]     = useState(false);
  const [fetching, setFetching]   = useState(true);
  const [alreadyOffered, setAlreadyOffered] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      const r = await bookingsApi.getById(bookingId);
      setBooking(r.data);
    } catch {}
    finally { setFetching(false); }
  };

  const commission = price ? Math.round((Number(price) * COMMISSION_RATE) / 100) : 0;
  const earnings   = price ? Number(price) - commission : 0;

  const handleSubmit = async () => {
    if (!price || Number(price) < 100) {
      Alert.alert('Invalid Price', 'Minimum price is ₨ 100');
      return;
    }
    setLoading(true);
    try {
      if (isOfferMode) {
        // InDrive: Send offer — multiple technicians can bid
        await bookingsApi.sendOffer(bookingId, Number(price), note.trim() || undefined);
        Alert.alert(
          'Offer Sent! 📤',
          `Your offer of ₨${Number(price).toLocaleString()} has been sent to the customer.\n\nYou will be notified if the customer selects you.`,
          [{ text: 'OK', onPress: () => navigation.goBack() }]
        );
      } else {
        // Direct: Set final price after accept
        await bookingsApi.setPrice(bookingId, Number(price), note.trim() || undefined);
        navigation.replace('ActiveJob', { bookingId });
      }
    } catch (err: any) {
      const msg = err?.response?.data?.message || 'Failed to submit';
      if (msg.includes('already submitted')) {
        setAlreadyOffered(true);
        Alert.alert('Already Offered', 'You already sent an offer. Wait for customer to respond.');
      } else {
        Alert.alert('Error', msg);
      }
    } finally { setLoading(false); }
  };

  const service = SERVICE_TYPES.find(s => s.key === booking?.serviceType);
  const cust    = booking?.customer as any;

  if (fetching) return (
    <ScreenWrapper title={isOfferMode ? 'Send Offer' : 'Set Price'} showBack>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </ScreenWrapper>
  );

  return (
    <ScreenWrapper title={isOfferMode ? '📤 Send Your Offer' : '💰 Set Your Price'} showBack>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom:40 }}>

        {/* Booking info */}
        {booking && (
          <Card style={[s.bookingCard, { borderColor:'rgba(255,92,26,0.3)' }]}>
            <View style={{ flexDirection:'row', gap:12, alignItems:'center' }}>
              <Text style={{ fontSize:28 }}>{service?.icon || '🛠️'}</Text>
              <View style={{ flex:1 }}>
                <Text style={s.bookingService}>{service?.label || booking.serviceType}</Text>
                <Text style={s.bookingMeta}>👤 {cust?.fullName || 'Customer'}</Text>
                <Text style={s.bookingMeta}>📍 {booking.customerLocation?.address}</Text>
              </View>
            </View>
            {booking.problemDescription && (
              <Text style={s.bookingDesc} numberOfLines={3}>{booking.problemDescription}</Text>
            )}
            {booking.customerNote && (
              <Text style={s.bookingNote}>📝 "{booking.customerNote}"</Text>
            )}
          </Card>
        )}

        {/* InDrive info banner */}
        {isOfferMode && (
          <View style={s.indriveBox}>
            <Text style={s.indriveTitle}>🏎️ InDrive Bidding Mode</Text>
            <Text style={s.indriveTxt}>
              Multiple technicians can send offers. Customer will see all offers sorted by price and choose the best one.
              Lower price = Higher chance of selection!
            </Text>
          </View>
        )}

        {/* Already offered warning */}
        {alreadyOffered && (
          <View style={s.warnBox}>
            <Text style={{ color:Colors.warning, fontSize:FontSize.sm }}>
              ⏳ You already sent an offer for this booking. Waiting for customer decision.
            </Text>
          </View>
        )}

        {/* Quick price buttons */}
        <Text style={s.label}>Quick Select (PKR)</Text>
        <View style={s.quickGrid}>
          {QUICK_PRICES.map(p => (
            <TouchableOpacity key={p}
              style={[s.quickBtn, price === String(p) && s.quickBtnActive]}
              onPress={() => setPrice(String(p))}
            >
              <Text style={[s.quickBtnTxt, price === String(p) && { color:Colors.primary }]}>
                ₨ {p.toLocaleString()}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Custom price */}
        <Text style={s.label}>Custom Price (PKR) *</Text>
        <TextInput
          style={s.priceInput}
          value={price}
          onChangeText={setPrice}
          keyboardType="numeric"
          placeholder="Enter your price..."
          placeholderTextColor={Colors.textMuted}
        />

        {/* Breakdown */}
        {price && Number(price) > 0 && (
          <Card style={{ backgroundColor:Colors.surface2, borderColor:Colors.border, marginBottom:Spacing.lg }}>
            <View style={s.bRow}>
              <Text style={s.bLabel}>Your Offer Price</Text>
              <Text style={[s.bVal, { color:Colors.primary }]}>₨ {Number(price).toLocaleString()}</Text>
            </View>
            <View style={s.bRow}>
              <Text style={s.bLabel}>Platform Commission ({COMMISSION_RATE}%)</Text>
              <Text style={[s.bVal, { color:Colors.danger }]}>- ₨ {commission.toLocaleString()}</Text>
            </View>
            <View style={[s.bRow, { borderTopWidth:1, borderTopColor:Colors.border, paddingTop:8, marginTop:4, marginBottom:0 }]}>
              <Text style={{ fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text }}>You Earn</Text>
              <Text style={{ fontSize:FontSize.xl, fontWeight:FontWeight.extrabold, color:Colors.success }}>
                ₨ {earnings.toLocaleString()}
              </Text>
            </View>
          </Card>
        )}

        {/* Note */}
        <Text style={s.label}>Note to Customer (optional)</Text>
        <TextInput
          style={[s.priceInput, { height:80, textAlignVertical:'top', paddingTop:12 }]}
          value={note}
          onChangeText={setNote}
          placeholder="e.g. I can start immediately, price may change after inspection..."
          placeholderTextColor={Colors.textMuted}
          multiline
        />

        <Button
          title={
            loading ? 'Sending...' :
            alreadyOffered ? '✅ Offer Already Sent' :
            isOfferMode ? `📤 Send Offer — ₨${price ? Number(price).toLocaleString() : '?'}` :
            `✅ Set Price & Proceed`
          }
          onPress={alreadyOffered ? undefined : handleSubmit}
          loading={loading}
          disabled={alreadyOffered || !price || Number(price) < 100}
          style={{ marginTop:8 }}
        />
      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:       { flex:1, alignItems:'center', justifyContent:'center' },
  bookingCard:  { marginBottom:Spacing.lg },
  bookingService:{ fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text },
  bookingMeta:  { fontSize:FontSize.sm, color:Colors.textMuted, marginTop:1 },
  bookingDesc:  { fontSize:FontSize.sm, color:Colors.textMuted, lineHeight:18, marginTop:10, fontStyle:'italic' },
  bookingNote:  { fontSize:FontSize.sm, color:Colors.info, marginTop:6 },
  indriveBox:   { backgroundColor:'rgba(59,130,246,0.1)', borderRadius:Radius.lg, borderWidth:1, borderColor:'rgba(59,130,246,0.3)', padding:Spacing.lg, marginBottom:Spacing.lg },
  indriveTitle: { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.info, marginBottom:6 },
  indriveTxt:   { fontSize:FontSize.sm, color:Colors.info, lineHeight:18 },
  warnBox:      { backgroundColor:Colors.warningBg, borderRadius:Radius.md, borderWidth:1, borderColor:'rgba(245,158,11,0.3)', padding:Spacing.md, marginBottom:Spacing.lg },
  label:        { fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:8, textTransform:'uppercase', letterSpacing:0.5 },
  quickGrid:    { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:Spacing.lg },
  quickBtn:     { paddingVertical:9, paddingHorizontal:14, borderRadius:Radius.full, borderWidth:1.5, borderColor:Colors.border, backgroundColor:Colors.surface2 },
  quickBtnActive:{ borderColor:Colors.primary, backgroundColor:Colors.primaryBg },
  quickBtnTxt:  { fontSize:FontSize.sm, color:Colors.textMuted, fontWeight:FontWeight.medium },
  priceInput:   { backgroundColor:Colors.surface2, borderRadius:Radius.md, borderWidth:1.5, borderColor:Colors.border, padding:13, color:Colors.text, fontSize:FontSize.lg, fontWeight:FontWeight.bold, marginBottom:Spacing.lg },
  bRow:         { flexDirection:'row', justifyContent:'space-between', marginBottom:8 },
  bLabel:       { fontSize:FontSize.sm, color:Colors.textMuted },
  bVal:         { fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.text },
});
