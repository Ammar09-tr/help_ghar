import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { bookingsApi } from '../../api/services';
import { Booking } from '../../types';
import { BookingCard, EmptyState } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const FILTERS = [
  {key:'',label:'All'},{key:'confirmed',label:'Completed'},
  {key:'in_progress',label:'Active'},{key:'rejected',label:'Rejected'},
];

export default function TechJobsScreen({ navigation }: any) {
  const [jobs, setJobs]           = useState<Booking[]>([]);
  const [filter, setFilter]       = useState('');
  const [loading, setLoading]     = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async (status?: string) => {
    try { const r = await bookingsApi.getMyJobs(status||undefined); setJobs(r.data); }
    catch {} finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { setLoading(true); load(filter); }, [filter]));

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}><Text style={s.title}>Job History</Text></View>
      <FlatList horizontal data={FILTERS} keyExtractor={i=>i.key}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{paddingHorizontal:Spacing.xl,paddingBottom:Spacing.md,gap:8}}
        renderItem={({item})=>(
          <TouchableOpacity style={[s.filterBtn,filter===item.key&&s.filterBtnActive]} onPress={()=>setFilter(item.key)}>
            <Text style={[s.filterTxt,filter===item.key&&{color:Colors.primary}]}>{item.label}</Text>
          </TouchableOpacity>
        )}
      />
      {loading
        ? <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
        : <FlatList data={jobs} keyExtractor={b=>b._id}
            contentContainerStyle={{paddingHorizontal:Spacing.xl,paddingBottom:100}}
            showsVerticalScrollIndicator={false}
            onRefresh={()=>{setRefreshing(true);load(filter);}}
            refreshing={refreshing}
            ListEmptyComponent={<EmptyState emoji="📋" title="No jobs found" subtitle="Completed jobs appear here"/>}
            renderItem={({item})=>(
              <BookingCard booking={item} viewAs="technician"
                onPress={()=>{
                  if (['en_route','in_progress','completed'].includes(item.status))
                    navigation.navigate('ActiveJob',{bookingId:item._id});
                }}
              />
            )}
          />
      }
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:   {flex:1,backgroundColor:Colors.bg},
  center: {flex:1,alignItems:'center',justifyContent:'center'},
  header: {paddingHorizontal:Spacing.xl,paddingTop:Spacing.lg,paddingBottom:Spacing.md},
  title:  {fontSize:FontSize.xxl,fontWeight:FontWeight.extrabold,color:Colors.text},
  filterBtn:{paddingVertical:8,paddingHorizontal:16,borderRadius:Radius.full,backgroundColor:Colors.surface2,borderWidth:1,borderColor:Colors.border},
  filterBtnActive:{backgroundColor:Colors.primaryBg,borderColor:Colors.primary},
  filterTxt:{fontSize:FontSize.sm,fontWeight:FontWeight.medium,color:Colors.textMuted},
});
