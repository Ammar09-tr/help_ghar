import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { commissionApi, techniciansApi } from '../../api/services';
import { Commission } from '../../types';
import { Card, Button, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const METHODS = [
  { key:'jazzcash',  label:'📱 JazzCash',      number:'0300-1234567' },
  { key:'easypaisa', label:'💚 EasyPaisa',     number:'0311-1234567' },
  { key:'bank',      label:'🏦 Bank Transfer', number:'HBL: 01234567890' },
  { key:'cash',      label:'💵 Cash',          number:'Visit office' },
];

export default function CommissionScreen({ navigation }: any) {
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [profile, setProfile]         = useState<any>(null);
  const [method, setMethod]           = useState('jazzcash');
  const [loading, setLoading]         = useState(true);
  const [paying, setPaying]           = useState(false);

  useFocusEffect(useCallback(() => {
    load();
  }, []));

  const load = async () => {
    setLoading(true);
    try {
      const [pRes, cRes] = await Promise.all([
        techniciansApi.getMyProfile(),
        commissionApi.getMyPending(),
      ]);
      setProfile(pRes.data);
      setCommissions(cRes.data);
      console.log('Commission loaded:', cRes.data?.length, 'total:', cRes.data?.reduce((s: number, c: any) => s + c.commissionAmount, 0));
    } catch (err: any) {
      console.log('Load error:', JSON.stringify(err?.response?.data));
    } finally {
      setLoading(false);
    }
  };

  const total = commissions.reduce((sum, c) => sum + c.commissionAmount, 0);

  const handlePay = () => {
    if (total === 0) {
      Alert.alert('No Commission', 'No pending commission to pay.');
      return;
    }

    const selected = METHODS.find(m => m.key === method);

    Alert.alert(
      'Confirm Payment',
      `Pay ₨ ${total.toLocaleString()} via ${selected?.label}?\n\nSend to: ${selected?.number}\n\nYour account will be unlocked after payment.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Yes, Pay Now ✅',
          onPress: async () => {
            setPaying(true);
            try {
              const txnId = `TXN${Date.now()}`;
              console.log('Paying commission with method:', method, 'txn:', txnId);
              const res = await commissionApi.pay(method, txnId);
              console.log('Pay response:', JSON.stringify(res.data));
              Alert.alert(
                'Commission Paid! 🔓',
                'Your account is now unlocked.\nYou can now accept new jobs!',
                [{
                  text: 'OK',
                  onPress: () => {
                    load();
                    navigation.goBack();
                  }
                }]
              );
            } catch (err: any) {
              console.log('Pay error:', JSON.stringify(err?.response?.data));
              Alert.alert(
                'Payment Failed',
                err?.response?.data?.message || 'Could not process payment. Try again.'
              );
            } finally {
              setPaying(false);
            }
          }
        },
      ]
    );
  };

  if (loading) return (
    <ScreenWrapper title="Pay Commission" showBack>
      <View style={s.center}>
        <ActivityIndicator color={Colors.primary} size="large"/>
      </View>
    </ScreenWrapper>
  );

  return (
    <ScreenWrapper title="Pay Commission" showBack>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        {/* Hero */}
        <View style={s.hero}>
          <Text style={{ fontSize: 52 }}>🔒</Text>
          <Text style={s.heroTitle}>Commission Due</Text>
          <Text style={s.heroAmount}>₨ {total.toLocaleString()}</Text>
          <Text style={s.heroSub}>
            Pay to unlock your account and receive new job requests
          </Text>
        </View>

        {/* Pending Commissions List */}
        {commissions.length > 0 && (
          <>
            <Text style={s.sectionLabel}>
              Pending Commissions ({commissions.length})
            </Text>
            {commissions.map(c => {
              const b = c.booking as any;
              return (
                <Card key={c._id}>
                  <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
                    <View>
                      <Text style={{ color:Colors.text, fontSize:FontSize.sm, fontWeight:FontWeight.semibold }}>
                        {b?.serviceType || 'Service'}
                      </Text>
                      <Text style={{ color:Colors.textMuted, fontSize:FontSize.xs, marginTop:2 }}>
                        Job: ₨ {c.jobPrice?.toLocaleString()} · Rate: {c.commissionRate}%
                      </Text>
                    </View>
                    <Text style={{ color:Colors.danger, fontWeight:FontWeight.extrabold, fontSize:FontSize.lg }}>
                      ₨ {c.commissionAmount?.toLocaleString()}
                    </Text>
                  </View>
                </Card>
              );
            })}
          </>
        )}

        {/* Payment Method */}
        <Text style={s.sectionLabel}>Select Payment Method</Text>
        {METHODS.map(m => (
          <TouchableOpacity
            key={m.key}
            style={[s.methodCard, method === m.key && s.methodCardActive]}
            onPress={() => setMethod(m.key)}
            activeOpacity={0.8}
          >
            <View style={{ flex: 1 }}>
              <Text style={[s.methodLabel, method === m.key && { color: Colors.primary }]}>
                {m.label}
              </Text>
              <Text style={s.methodNumber}>{m.number}</Text>
            </View>
            <View style={[s.radio, method === m.key && s.radioActive]}>
              {method === m.key && <View style={s.radioInner}/>}
            </View>
          </TouchableOpacity>
        ))}

        {/* Total Summary */}
        <View style={s.summaryBox}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:8 }}>
            <Text style={{ fontSize:FontSize.sm, color:Colors.textMuted }}>Pending Commissions</Text>
            <Text style={{ fontSize:FontSize.sm, color:Colors.text }}>{commissions.length} items</Text>
          </View>
          <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
            <Text style={{ fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text }}>
              Total to Pay
            </Text>
            <Text style={{ fontSize:FontSize.xl, fontWeight:FontWeight.extrabold, color:Colors.primary }}>
              ₨ {total.toLocaleString()}
            </Text>
          </View>
        </View>

        {/* Pay Button */}
        <TouchableOpacity
          style={[
            s.payBtn,
            (total === 0 || paying) && s.payBtnDisabled
          ]}
          onPress={handlePay}
          disabled={total === 0 || paying}
          activeOpacity={0.8}
        >
          {paying ? (
            <ActivityIndicator color={Colors.white} size="small"/>
          ) : (
            <Text style={s.payBtnTxt}>
              {total === 0
                ? 'No Commission Due ✅'
                : `Pay ₨ ${total.toLocaleString()} & Unlock 🔓`
              }
            </Text>
          )}
        </TouchableOpacity>

      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:          { flex:1, alignItems:'center', justifyContent:'center' },
  hero:            { alignItems:'center', paddingVertical:Spacing.xxl, gap:8 },
  heroTitle:       { fontSize:FontSize.xxl, fontWeight:FontWeight.extrabold, color:Colors.text },
  heroAmount:      { fontSize:44, fontWeight:FontWeight.extrabold, color:Colors.primary },
  heroSub:         { fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:20 },
  sectionLabel:    { fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:10, marginTop:Spacing.md, textTransform:'uppercase', letterSpacing:0.5 },
  methodCard:      { flexDirection:'row', alignItems:'center', backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1.5, borderColor:Colors.border, padding:Spacing.lg, marginBottom:10 },
  methodCardActive:{ borderColor:Colors.primary, backgroundColor:Colors.primaryBg },
  methodLabel:     { fontSize:FontSize.md, color:Colors.text, fontWeight:FontWeight.semibold },
  methodNumber:    { fontSize:FontSize.sm, color:Colors.textMuted, marginTop:2 },
  radio:           { width:22, height:22, borderRadius:11, borderWidth:2, borderColor:Colors.border, alignItems:'center', justifyContent:'center' },
  radioActive:     { borderColor:Colors.primary },
  radioInner:      { width:12, height:12, borderRadius:6, backgroundColor:Colors.primary },
  summaryBox:      { backgroundColor:Colors.surface2, borderRadius:Radius.lg, padding:Spacing.lg, marginTop:Spacing.lg, borderWidth:1, borderColor:Colors.border },
  payBtn:          { backgroundColor:Colors.primary, borderRadius:14, paddingVertical:16, alignItems:'center', marginTop:Spacing.xl, shadowColor:Colors.primary, shadowOffset:{width:0,height:6}, shadowOpacity:0.4, shadowRadius:12, elevation:8 },
  payBtnDisabled:  { backgroundColor:Colors.surface3, shadowOpacity:0, elevation:0 },
  payBtnTxt:       { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.white },
});