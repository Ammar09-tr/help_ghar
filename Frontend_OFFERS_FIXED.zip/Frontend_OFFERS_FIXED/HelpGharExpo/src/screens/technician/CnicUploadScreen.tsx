import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator, Image
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { techniciansApi } from '../../api/services';
import { Button, Card, ScreenWrapper, Badge } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function CnicUploadScreen({ navigation }: any) {
  const [profile, setProfile]     = useState<any>(null);
  const [frontImg, setFrontImg]   = useState<string | null>(null);
  const [backImg, setBackImg]     = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading]     = useState(true);

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      const r = await techniciansApi.getMyProfile();
      setProfile(r.data);
      if (r.data.cnicFrontImage) setFrontImg(r.data.cnicFrontImage);
      if (r.data.cnicBackImage)  setBackImg(r.data.cnicBackImage);
    } catch {}
    finally { setLoading(false); }
  };

  const pickImage = async (side: 'front' | 'back') => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow photo library access to upload CNIC');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 10],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      if (side === 'front') setFrontImg(result.assets[0].uri);
      else setBackImg(result.assets[0].uri);
    }
  };

  const takePhoto = async (side: 'front' | 'back') => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow camera access');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [16, 10],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      if (side === 'front') setFrontImg(result.assets[0].uri);
      else setBackImg(result.assets[0].uri);
    }
  };

  const handleImagePick = (side: 'front' | 'back') => {
    Alert.alert('Upload CNIC', `Select ${side} side of your CNIC`, [
      { text: '📷 Take Photo', onPress: () => takePhoto(side) },
      { text: '🖼️ From Gallery', onPress: () => pickImage(side) },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const handleUpload = async () => {
    if (!frontImg || !backImg) {
      Alert.alert('Missing Images', 'Please upload both front and back of your CNIC');
      return;
    }
    setUploading(true);
    try {
      const formData = new FormData();

      // Front image
      const frontFilename = `cnic_front_${Date.now()}.jpg`;
      formData.append('cnicFront', {
        uri: frontImg,
        name: frontFilename,
        type: 'image/jpeg',
      } as any);

      // Back image
      const backFilename = `cnic_back_${Date.now()}.jpg`;
      formData.append('cnicBack', {
        uri: backImg,
        name: backFilename,
        type: 'image/jpeg',
      } as any);

      await techniciansApi.uploadCnic(formData);

      Alert.alert(
        'CNIC Submitted ✅',
        'Your CNIC has been submitted for verification. Admin will review within 24 hours.',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.message || 'Upload failed. Try again.');
    } finally { setUploading(false); }
  };

  const statusConfig = {
    unverified: { label:'Not Submitted',  color:Colors.textMuted, bg:Colors.surface2, icon:'📋' },
    pending:    { label:'Under Review',   color:Colors.warning,   bg:Colors.warningBg, icon:'⏳' },
    verified:   { label:'Verified ✅',    color:Colors.success,   bg:Colors.successBg, icon:'✅' },
    rejected:   { label:'Rejected ❌',    color:Colors.danger,    bg:Colors.dangerBg,  icon:'❌' },
  };
  const status = profile?.cnicVerificationStatus || 'unverified';
  const cfg    = statusConfig[status as keyof typeof statusConfig];

  if (loading) return (
    <ScreenWrapper title="CNIC Verification" showBack>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </ScreenWrapper>
  );

  return (
    <ScreenWrapper title="CNIC Verification" showBack>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:40}}>

        {/* Status */}
        <View style={[s.statusBox, {backgroundColor:cfg.bg, borderColor:cfg.color+'40'}]}>
          <Text style={{fontSize:32}}>{cfg.icon}</Text>
          <View style={{flex:1}}>
            <Text style={[s.statusTitle, {color:cfg.color}]}>Status: {cfg.label}</Text>
            <Text style={s.statusSub}>
              {status === 'verified'   ? 'Your CNIC is verified. Customers trust verified technicians more!' :
               status === 'pending'    ? 'Admin is reviewing your documents. Usually takes 24 hours.' :
               status === 'rejected'   ? 'Your CNIC was rejected. Please resubmit clear images.' :
               'Upload your CNIC to build customer trust and get more jobs.'}
            </Text>
          </View>
        </View>

        {/* Why verify */}
        {status !== 'verified' && (
          <Card>
            <Text style={s.cardTitle}>Why Verify CNIC?</Text>
            {['✅ Get a verified badge on your profile', '✅ Customers trust verified technicians more', '✅ Higher chance of getting selected', '✅ Required for future premium features'].map((item, i) => (
              <Text key={i} style={s.benefitItem}>{item}</Text>
            ))}
          </Card>
        )}

        {/* Instructions */}
        <View style={s.instructBox}>
          <Text style={s.instructTitle}>📋 Instructions</Text>
          <Text style={s.instructItem}>• Take clear photos in good lighting</Text>
          <Text style={s.instructItem}>• All text must be readable</Text>
          <Text style={s.instructItem}>• No blurry or cropped images</Text>
          <Text style={s.instructItem}>• File size must be under 5MB</Text>
        </View>

        {/* Front CNIC */}
        <Text style={s.label}>CNIC Front Side *</Text>
        <TouchableOpacity
          style={[s.imgBox, frontImg && s.imgBoxFilled]}
          onPress={() => status !== 'verified' && handleImagePick('front')}
          disabled={status === 'verified'}
        >
          {frontImg ? (
            <>
              <Image source={{uri: frontImg}} style={s.imgPreview} resizeMode="cover"/>
              {status !== 'verified' && (
                <View style={s.imgOverlay}>
                  <Text style={{color:Colors.white, fontSize:FontSize.sm}}>Tap to change</Text>
                </View>
              )}
            </>
          ) : (
            <View style={s.imgPlaceholder}>
              <Text style={{fontSize:40}}>🪪</Text>
              <Text style={s.imgPlaceholderTxt}>Tap to upload front side</Text>
              <Text style={s.imgPlaceholderSub}>Photo or Gallery</Text>
            </View>
          )}
        </TouchableOpacity>

        {/* Back CNIC */}
        <Text style={s.label}>CNIC Back Side *</Text>
        <TouchableOpacity
          style={[s.imgBox, backImg && s.imgBoxFilled]}
          onPress={() => status !== 'verified' && handleImagePick('back')}
          disabled={status === 'verified'}
        >
          {backImg ? (
            <>
              <Image source={{uri: backImg}} style={s.imgPreview} resizeMode="cover"/>
              {status !== 'verified' && (
                <View style={s.imgOverlay}>
                  <Text style={{color:Colors.white, fontSize:FontSize.sm}}>Tap to change</Text>
                </View>
              )}
            </>
          ) : (
            <View style={s.imgPlaceholder}>
              <Text style={{fontSize:40}}>🪪</Text>
              <Text style={s.imgPlaceholderTxt}>Tap to upload back side</Text>
              <Text style={s.imgPlaceholderSub}>Photo or Gallery</Text>
            </View>
          )}
        </TouchableOpacity>

        {/* Submit button */}
        {status !== 'verified' && (
          <Button
            title={uploading ? 'Uploading...' : 'Submit for Verification 📤'}
            onPress={handleUpload}
            loading={uploading}
            disabled={!frontImg || !backImg || uploading}
            style={{marginTop:8}}
          />
        )}

        {status === 'rejected' && (
          <View style={s.rejectedBox}>
            <Text style={{fontSize:FontSize.sm, color:Colors.danger, lineHeight:18}}>
              ❌ Your previous submission was rejected. Please upload clearer images and resubmit.
            </Text>
          </View>
        )}
      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:           {flex:1, alignItems:'center', justifyContent:'center'},
  statusBox:        {flexDirection:'row', gap:12, alignItems:'flex-start', borderRadius:Radius.xl, borderWidth:1, padding:Spacing.lg, marginBottom:Spacing.lg},
  statusTitle:      {fontSize:FontSize.md, fontWeight:FontWeight.bold},
  statusSub:        {fontSize:FontSize.sm, color:Colors.textMuted, marginTop:4, lineHeight:18},
  cardTitle:        {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:10},
  benefitItem:      {fontSize:FontSize.sm, color:Colors.textMuted, marginBottom:4, lineHeight:18},
  instructBox:      {backgroundColor:Colors.infoBg, borderRadius:Radius.md, borderWidth:1, borderColor:'rgba(59,130,246,0.2)', padding:Spacing.lg, marginBottom:Spacing.lg},
  instructTitle:    {fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.info, marginBottom:8},
  instructItem:     {fontSize:FontSize.sm, color:Colors.info, marginBottom:3, lineHeight:18},
  label:            {fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:8, textTransform:'uppercase', letterSpacing:0.5},
  imgBox:           {height:160, backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:2, borderColor:Colors.border, borderStyle:'dashed', marginBottom:Spacing.lg, overflow:'hidden'},
  imgBoxFilled:     {borderStyle:'solid', borderColor:Colors.primary},
  imgPreview:       {width:'100%', height:'100%'},
  imgOverlay:       {position:'absolute', bottom:0, left:0, right:0, backgroundColor:'rgba(0,0,0,0.5)', paddingVertical:8, alignItems:'center'},
  imgPlaceholder:   {flex:1, alignItems:'center', justifyContent:'center', gap:8},
  imgPlaceholderTxt:{fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.textMuted},
  imgPlaceholderSub:{fontSize:FontSize.xs, color:Colors.textMuted},
  rejectedBox:      {backgroundColor:Colors.dangerBg, borderRadius:Radius.md, borderWidth:1, borderColor:'rgba(239,68,68,0.3)', padding:Spacing.md, marginTop:Spacing.md},
});
