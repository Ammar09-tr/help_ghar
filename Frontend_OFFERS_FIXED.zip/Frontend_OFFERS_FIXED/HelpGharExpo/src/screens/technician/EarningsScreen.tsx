import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { commissionApi, techniciansApi } from '../../api/services';
import { Commission } from '../../types';
import { EmptyState } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function EarningsScreen({ navigation }: any) {
  const [profile, setProfile]       = useState<any>(null);
  const [history, setHistory]       = useState<Commission[]>([]);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tab, setTab]               = useState<'all'|'paid'|'pending'>('all');

  const load = async () => {
    try {
      const [pRes, hRes] = await Promise.all([
        techniciansApi.getMyProfile(),
        commissionApi.getMyHistory(),
      ]);
      setProfile(pRes.data);
      setHistory(hRes.data);
    } catch {} finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  const filtered = tab === 'all' ? history
    : history.filter(c => c.status === tab);

  const totalCommPaid    = history.filter(c=>c.status==='paid').reduce((s,c)=>s+c.commissionAmount,0);
  const totalCommPending = history.filter(c=>c.status==='pending').reduce((s,c)=>s+c.commissionAmount,0);
  const netEarnings      = (profile?.totalEarnings||0) - totalCommPaid;

  const Header = () => (
    <View>
      {/* Stats */}
      <View style={s.header}><Text style={s.title}>Earnings</Text></View>
      <View style={s.grid}>
        {[
          { val:`₨ ${(profile?.totalEarnings||0).toLocaleString()}`, label:'Gross Earned',   color:Colors.text },
          { val:`₨ ${totalCommPaid.toLocaleString()}`,               label:'Commission Paid', color:Colors.danger },
          { val:`₨ ${netEarnings.toLocaleString()}`,                 label:'Net Earnings',    color:Colors.success },
          { val:String(profile?.totalJobs||0),                       label:'Total Jobs',      color:Colors.primary },
          { val:`${(profile?.averageRating||0).toFixed(1)} ★`,       label:'Rating',          color:Colors.warning },
          { val:`₨ ${totalCommPending.toLocaleString()}`,            label:'Pending Comm.',   color:totalCommPending>0?Colors.danger:Colors.textMuted },
        ].map((item,i)=>(
          <View key={i} style={s.statCard}>
            <Text style={[s.statVal, { color:item.color }]}>{item.val}</Text>
            <Text style={s.statLabel}>{item.label}</Text>
          </View>
        ))}
      </View>

      {/* Commission lock warning */}
      {profile?.isCommissionLocked && (
        <TouchableOpacity style={s.lockWarn} onPress={() => navigation.navigate('Commission')}>
          <Text style={{ fontSize:FontSize.sm, color:Colors.danger, textAlign:'center' }}>
            🔒 ₨ {profile.pendingCommission.toLocaleString()} commission pending — Tap to pay
          </Text>
        </TouchableOpacity>
      )}

      {/* Tab filter */}
      <View style={s.tabRow}>
        {([['all','All'],['paid','Paid'],['pending','Pending']] as const).map(([key,label])=>(
          <TouchableOpacity key={key} style={[s.tabBtn, tab===key&&s.tabBtnActive]} onPress={()=>setTab(key)}>
            <Text style={[s.tabTxt, tab===key&&{color:Colors.primary}]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={s.histLabel}>Commission History ({filtered.length})</Text>
    </View>
  );

  if (loading) return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}><Text style={s.title}>Earnings</Text></View>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={s.safe}>
      <FlatList
        data={filtered}
        keyExtractor={c => c._id}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={<Header/>}
        contentContainerStyle={{ paddingBottom:100 }}
        onRefresh={() => { setRefreshing(true); load(); }}
        refreshing={refreshing}
        ListEmptyComponent={
          <EmptyState emoji="💰" title="No records" subtitle={tab==='all'?'Complete jobs to see earnings here':`No ${tab} commissions`}/>
        }
        renderItem={({ item }) => {
          const b = item.booking as any;
          const fmtDate = (d:string) => { try { return new Date(d).toLocaleDateString('en-PK',{day:'numeric',month:'short'}); } catch { return ''; } };
          return (
            <View style={s.histItem}>
              <View style={s.histLeft}>
                <Text style={s.histService}>{b?.serviceType || 'Service'}</Text>
                <Text style={s.histDate}>{fmtDate(item.createdAt)}</Text>
              </View>
              <View style={s.histMid}>
                <Text style={s.histJob}>₨ {item.jobPrice.toLocaleString()}</Text>
                <Text style={s.histCommLabel}>- ₨ {item.commissionAmount.toLocaleString()} ({item.commissionRate}%)</Text>
              </View>
              <View style={s.histRight}>
                <View style={[s.statusPill, { backgroundColor:item.status==='paid'?Colors.successBg:Colors.warningBg }]}>
                  <Text style={[s.statusTxt, { color:item.status==='paid'?Colors.success:Colors.warning }]}>
                    {item.status==='paid' ? '✓ Paid' : '⏳ Due'}
                  </Text>
                </View>
              </View>
            </View>
          );
        }}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:       { flex:1, backgroundColor:Colors.bg },
  center:     { flex:1, alignItems:'center', justifyContent:'center' },
  header:     { paddingHorizontal:Spacing.xl, paddingTop:Spacing.lg, paddingBottom:Spacing.md },
  title:      { fontSize:FontSize.xxl, fontWeight:FontWeight.extrabold, color:Colors.text },
  grid:       { flexDirection:'row', flexWrap:'wrap', gap:10, padding:Spacing.xl, paddingTop:0 },
  statCard:   { flex:1, minWidth:'45%', backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, alignItems:'center', gap:4 },
  statVal:    { fontSize:FontSize.lg, fontWeight:FontWeight.extrabold },
  statLabel:  { fontSize:FontSize.xs, color:Colors.textMuted },
  lockWarn:   { marginHorizontal:Spacing.xl, backgroundColor:Colors.dangerBg, borderRadius:Radius.md, padding:Spacing.md, borderWidth:1, borderColor:'rgba(239,68,68,0.3)', marginBottom:Spacing.md },
  tabRow:     { flexDirection:'row', gap:8, paddingHorizontal:Spacing.xl, marginBottom:Spacing.md },
  tabBtn:     { paddingVertical:8, paddingHorizontal:16, borderRadius:Radius.full, backgroundColor:Colors.surface2, borderWidth:1, borderColor:Colors.border },
  tabBtnActive:{ backgroundColor:Colors.primaryBg, borderColor:Colors.primary },
  tabTxt:     { fontSize:FontSize.sm, fontWeight:FontWeight.medium, color:Colors.textMuted },
  histLabel:  { fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:4, textTransform:'uppercase', letterSpacing:0.5, paddingHorizontal:Spacing.xl },
  histItem:   { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingVertical:Spacing.md, paddingHorizontal:Spacing.xl, borderBottomWidth:1, borderBottomColor:Colors.border },
  histLeft:   { flex:1 },
  histService:{ color:Colors.text, fontSize:FontSize.sm, fontWeight:FontWeight.semibold },
  histDate:   { color:Colors.textMuted, fontSize:FontSize.xs, marginTop:2 },
  histMid:    { flex:1, alignItems:'center' },
  histJob:    { color:Colors.text, fontSize:FontSize.sm, fontWeight:FontWeight.semibold },
  histCommLabel:{ color:Colors.danger, fontSize:FontSize.xs },
  histRight:  { flex:1, alignItems:'flex-end' },
  statusPill: { paddingVertical:4, paddingHorizontal:10, borderRadius:Radius.full },
  statusTxt:  { fontSize:FontSize.xs, fontWeight:FontWeight.bold },
});
