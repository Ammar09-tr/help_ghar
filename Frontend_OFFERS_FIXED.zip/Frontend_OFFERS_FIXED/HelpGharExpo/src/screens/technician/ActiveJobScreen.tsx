import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator, Linking, Platform
} from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { bookingsApi, techniciansApi } from '../../api/services';
import { Button, Card, Divider, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';
import { useSocket } from '../../hooks/useSocket';

export default function ActiveJobScreen({ navigation, route }: any) {
  const { bookingId } = route.params;
  const [booking, setBooking]   = useState<any>(null);
  const [loading, setLoading]   = useState(true);
  const [acting, setActing]     = useState(false);
  const [myLocation, setMyLocation] = useState<{lat:number;lng:number}|null>(null);
  const mapRef = useRef<MapView>(null);
  const { sendLocation } = useSocket();

  useEffect(() => {
    load();
    startLocationTracking();
  }, []);

  const startLocationTracking = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setMyLocation({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      // Send live location to customer via socket
      sendLocation(bookingId, loc.coords.latitude, loc.coords.longitude);
      await techniciansApi.updateLocation(loc.coords.longitude, loc.coords.latitude);
    } catch {}

    // Track every 15 seconds
    const interval = setInterval(async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
        setMyLocation({ lat: loc.coords.latitude, lng: loc.coords.longitude });
        sendLocation(bookingId, loc.coords.latitude, loc.coords.longitude);
        await techniciansApi.updateLocation(loc.coords.longitude, loc.coords.latitude);
      } catch {}
    }, 15000);
    return () => clearInterval(interval);
  };

  const load = async () => {
    try { const r = await bookingsApi.getById(bookingId); setBooking(r.data); }
    catch {} finally { setLoading(false); }
  };

  const handleStart = async () => {
    setActing(true);
    try { await bookingsApi.startJob(bookingId); load(); }
    catch (err: any) { Alert.alert('Error', err?.response?.data?.message || 'Failed'); }
    finally { setActing(false); }
  };

  const handleComplete = () => {
    Alert.alert('Mark as Completed?', 'Confirm the job is finished.',[
      {text:'Cancel'},
      {text:'Yes, Complete', onPress: async () => {
        setActing(true);
        try {
          await bookingsApi.completeJob(bookingId);
          load();
          Alert.alert('Job Marked Complete ✅', 'Waiting for customer confirmation and payment.');
        } catch (err: any) { Alert.alert('Error', err?.response?.data?.message || 'Failed'); }
        finally { setActing(false); }
      }},
    ]);
  };

  const openNavigationToCustomer = () => {
    if (!booking?.customerLocation?.coordinates) return;
    const [lng, lat] = booking.customerLocation.coordinates;
    const url = Platform.OS === 'ios'
      ? `maps://?daddr=${lat},${lng}`
      : `google.navigation:q=${lat},${lng}`;
    Linking.openURL(url).catch(() => {
      Linking.openURL(`https://maps.google.com/?q=${lat},${lng}`);
    });
  };

  if (loading) return (
    <ScreenWrapper title="Active Job" showBack>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </ScreenWrapper>
  );
  if (!booking) return (
    <ScreenWrapper title="Active Job" showBack>
      <View style={s.center}><Text style={{color:Colors.textMuted}}>Job not found</Text></View>
    </ScreenWrapper>
  );

  const service  = SERVICE_TYPES.find(sv => sv.key === booking.serviceType);
  const cust     = booking.customer as any;
  const commission = booking.quotedPrice ? Math.round((booking.quotedPrice * 10) / 100) : 0;
  const earnings   = booking.quotedPrice ? booking.quotedPrice - commission : 0;

  const custCoords = booking.customerLocation?.coordinates;
  const custLat = custCoords ? custCoords[1] : 31.5204;
  const custLng = custCoords ? custCoords[0] : 74.3587;

  return (
    <ScreenWrapper title="Active Job" showBack noPadding>
      {/* ── Google Map ── */}
      <MapView
        ref={mapRef}
        style={s.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={{
          latitude: myLocation?.lat || custLat,
          longitude: myLocation?.lng || custLng,
          latitudeDelta: 0.03,
          longitudeDelta: 0.03,
        }}
        showsUserLocation={true}
      >
        {/* Customer location */}
        <Marker
          coordinate={{ latitude: custLat, longitude: custLng }}
          title={`${cust?.fullName || 'Customer'}`}
          description={booking.customerLocation?.address}
        >
          <View style={s.custMarker}>
            <Text style={{fontSize:18}}>🏠</Text>
          </View>
        </Marker>

        {/* My location */}
        {myLocation && (
          <Marker
            coordinate={{ latitude: myLocation.lat, longitude: myLocation.lng }}
            title="You"
          >
            <View style={s.myMarker}>
              <Text style={{fontSize:18}}>🔧</Text>
            </View>
          </Marker>
        )}
      </MapView>

      {/* Navigate button on map */}
      <TouchableOpacity style={s.navBtn} onPress={openNavigationToCustomer}>
        <Text style={s.navBtnTxt}>🗺️ Open Navigation</Text>
      </TouchableOpacity>

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        {/* Customer card */}
        <Card style={{borderColor:'rgba(59,130,246,0.4)'}}>
          <View style={s.custRow}>
            <View style={s.custAvatar}><Text style={{fontSize:22}}>👤</Text></View>
            <View style={{flex:1}}>
              <Text style={s.custName}>{cust?.fullName || 'Customer'}</Text>
              <Text style={s.custPhone}>{cust?.phone || ''}</Text>
              <Text style={{fontSize:FontSize.xs, color:Colors.textMuted}}>
                📍 {booking.customerLocation?.address}
              </Text>
            </View>
            <View style={{flexDirection:'row', gap:8}}>
              <TouchableOpacity style={s.iconBtn}
                onPress={() => navigation.navigate('Chat', {bookingId, otherName: cust?.fullName || 'Customer'})}>
                <Text style={{fontSize:18}}>💬</Text>
              </TouchableOpacity>
              {cust?.phone && (
                <TouchableOpacity style={s.iconBtn} onPress={() => Linking.openURL(`tel:${cust.phone}`)}>
                  <Text style={{fontSize:18}}>📞</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
          <Divider style={{marginVertical:12}}/>
          <Text style={{fontSize:FontSize.sm, color:Colors.textLight, lineHeight:18}}>
            {booking.problemDescription}
          </Text>
        </Card>

        {/* Payment breakdown */}
        <Card>
          <Text style={s.cardTitle}>Payment Breakdown</Text>
          <View style={s.pRow}><Text style={s.pLabel}>Agreed Price</Text><Text style={[s.pVal,{color:Colors.primary}]}>₨ {(booking.quotedPrice||0).toLocaleString()}</Text></View>
          <View style={s.pRow}><Text style={s.pLabel}>Platform Commission (10%)</Text><Text style={[s.pVal,{color:Colors.danger}]}>₨ {commission.toLocaleString()}</Text></View>
          <View style={[s.pRow,{borderTopWidth:1,borderTopColor:Colors.border,paddingTop:8,marginTop:4,marginBottom:0}]}>
            <Text style={{fontSize:FontSize.md,fontWeight:FontWeight.bold,color:Colors.text}}>Your Earnings</Text>
            <Text style={{fontSize:FontSize.xl,fontWeight:FontWeight.extrabold,color:Colors.success}}>₨ {earnings.toLocaleString()}</Text>
          </View>
        </Card>

        <View style={s.warnBox}>
          <Text style={{fontSize:FontSize.sm,color:Colors.warning,lineHeight:18}}>
            ⚠️ Pay ₨{commission.toLocaleString()} platform commission after this job to unlock your next request.
          </Text>
        </View>

        {booking.status === 'en_route' && (
          <Button title="🔧 Mark Job Started (Arrived)" onPress={handleStart} loading={acting}/>
        )}
        {booking.status === 'accepted' && (
          <Button title="🚀 I'm Heading There" onPress={handleStart} loading={acting}/>
        )}
        {booking.status === 'in_progress' && (
          <Button title="✅ Mark Job Completed" onPress={handleComplete} loading={acting} variant="success"/>
        )}
        {booking.status === 'completed' && (
          <View style={s.waitBox}>
            <Text style={{fontSize:28}}>⏳</Text>
            <Text style={s.waitTitle}>Waiting for customer confirmation...</Text>
            <Text style={s.waitSub}>Customer needs to confirm payment.</Text>
          </View>
        )}
        {booking.status === 'confirmed' && (
          <View style={s.doneBox}>
            <Text style={{fontSize:32}}>🎉</Text>
            <Text style={s.doneTitle}>Job Confirmed!</Text>
            <Text style={s.doneSub}>Customer confirmed payment. Pay commission to accept new jobs.</Text>
            <Button title="Pay Commission" onPress={() => navigation.navigate('Commission')} style={{marginTop:12}}/>
          </View>
        )}
      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:    {flex:1, alignItems:'center', justifyContent:'center'},
  map:       {width:'100%', height:240},
  custMarker:{backgroundColor:Colors.white, borderRadius:18, padding:4, borderWidth:2, borderColor:Colors.info},
  myMarker:  {backgroundColor:Colors.white, borderRadius:18, padding:4, borderWidth:2, borderColor:Colors.primary},
  navBtn:    {position:'absolute', top:248, right:12, backgroundColor:Colors.primary, borderRadius:Radius.lg, paddingVertical:8, paddingHorizontal:14, flexDirection:'row', alignItems:'center', shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.3, shadowRadius:4, elevation:5},
  navBtnTxt: {fontSize:FontSize.sm, color:Colors.white, fontWeight:FontWeight.semibold},
  scroll:    {padding:Spacing.xl, paddingBottom:40, paddingTop:Spacing.xxxl},
  custRow:   {flexDirection:'row', alignItems:'center', gap:12},
  custAvatar:{width:46, height:46, borderRadius:23, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center'},
  custName:  {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text},
  custPhone: {fontSize:FontSize.sm, color:Colors.textMuted},
  iconBtn:   {width:36, height:36, borderRadius:18, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:Colors.border},
  cardTitle: {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:12},
  pRow:      {flexDirection:'row', justifyContent:'space-between', marginBottom:8},
  pLabel:    {fontSize:FontSize.sm, color:Colors.textMuted},
  pVal:      {fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.text},
  warnBox:   {backgroundColor:Colors.warningBg, borderRadius:Radius.md, borderWidth:1, borderColor:'rgba(245,158,11,0.3)', padding:Spacing.md, marginBottom:Spacing.lg},
  waitBox:   {alignItems:'center', backgroundColor:Colors.surface, borderRadius:Radius.xl, padding:Spacing.xxl, borderWidth:1, borderColor:Colors.border, gap:8},
  waitTitle: {fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text},
  waitSub:   {fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:18},
  doneBox:   {alignItems:'center', backgroundColor:Colors.successBg, borderRadius:Radius.xl, padding:Spacing.xxl, borderWidth:1, borderColor:'rgba(34,197,94,0.3)', gap:6},
  doneTitle: {fontSize:FontSize.xl, fontWeight:FontWeight.extrabold, color:Colors.success},
  doneSub:   {fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:18},
});
