import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, Alert, Switch
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Location from 'expo-location';
import { techniciansApi, bookingsApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { useSocket } from '../../hooks/useSocket';
import { useNotificationStore } from '../../store/notificationStore';
import { Booking, Technician } from '../../types';
import { Card, Badge, Button, Stars } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function TechHomeScreen({ navigation }: any) {
  const user = useAuthStore(s => s.user);
  const { connect, on } = useSocket();
  const { addLocalNotification, unreadCount } = useNotificationStore();
  const [profile, setProfile]         = useState<Technician | null>(null);
  const [requests, setRequests]       = useState<Booking[]>([]);
  const [isOnline, setIsOnline]       = useState(false);
  const [refreshing, setRefreshing]   = useState(false);
  const [toggling, setToggling]       = useState(false);

  const load = async () => {
    try {
      // Always update location first
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          await techniciansApi.updateLocation(loc.coords.longitude, loc.coords.latitude);
        } else {
          await techniciansApi.updateLocation(74.3587, 31.5204); // Default Lahore
        }
      } catch {
        try { await techniciansApi.updateLocation(74.3587, 31.5204); } catch {}
      }

      const pRes = await techniciansApi.getMyProfile();
      setProfile(pRes.data);
      setIsOnline(pRes.data.availability === 'online');

      try {
        const jRes = await bookingsApi.getNearbyPending(15);
        setRequests(jRes.data.slice(0, 8));
      } catch { setRequests([]); }
    } catch {}
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  // Live location update every 30s
  useEffect(() => {
    if (!isOnline) return;
    const interval = setInterval(async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          await techniciansApi.updateLocation(loc.coords.longitude, loc.coords.latitude);
        }
      } catch {}
    }, 30000);
    return () => clearInterval(interval);
  }, [isOnline]);

  useEffect(() => {
    connect();
    const u1 = on('booking:new_request', (data: any) => {
      addLocalNotification('New Job Request 📥', data?.message || 'A customer needs your help!', 'booking', data);
      load(); // Refresh list
    });
    const u2 = on('booking:offer_accepted', (data: any) => {
      addLocalNotification('Offer Accepted! 🎉', data?.message || 'Customer selected you!', 'booking', data);
      navigation.navigate('ActiveJob', { bookingId: data?.bookingId });
      load();
    });
    const u3 = on('booking:offer_rejected', (data: any) => {
      addLocalNotification('Offer Not Selected', data?.message || 'Customer chose another technician', 'booking', data);
    });
    const u4 = on('booking:cancelled', (data: any) => {
      addLocalNotification('Booking Cancelled', data?.message || 'A booking was cancelled', 'booking', data);
      setRequests(prev => prev.filter(b => b._id !== data?.bookingId));
    });
    const u5 = on('commission:paid', () => { load(); });
    return () => { u1?.(); u2?.(); u3?.(); u4?.(); u5?.(); };
  }, []);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const toggleOnline = async (val: boolean) => {
    if (profile?.isCommissionLocked) {
      Alert.alert('Account Locked 🔒', 'Pay your pending commission to go online.', [
        { text:'Pay Now', onPress:()=>navigation.navigate('Commission') },
        { text:'Cancel' },
      ]);
      return;
    }
    setToggling(true);
    try {
      await techniciansApi.updateAvailability(val ? 'online' : 'offline');
      setIsOnline(val);
      if (profile) setProfile({ ...profile, availability: val ? 'online' : 'offline' });
    } catch { Alert.alert('Error', 'Could not update availability'); }
    finally { setToggling(false); }
  };

  // InDrive: Send offer (bid)
  const handleSendOffer = (bookingId: string) => {
    if (profile?.isCommissionLocked) {
      Alert.alert('Account Locked', 'Pay commission first.', [
        {text:'Pay Now', onPress:()=>navigation.navigate('Commission')}, {text:'Cancel'},
      ]);
      return;
    }
    navigation.navigate('SetPrice', { bookingId, mode: 'offer' });
  };

  // Reject request
  const handleReject = async (bookingId: string) => {
    try {
      await bookingsApi.reject(bookingId);
      setRequests(prev => prev.filter(b => b._id !== bookingId));
    } catch {}
  };

  const service = SERVICE_TYPES.find(sv => sv.key === profile?.skill);

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary}/>}
        contentContainerStyle={s.scroll}
      >
        {/* Header */}
        <View style={s.header}>
          <View>
            <Text style={s.headerSub}>Technician Dashboard 🔧</Text>
            <Text style={s.headerName}>{user?.fullName?.split(' ')[0]}</Text>
          </View>
          <View style={s.headerRight}>
            <TouchableOpacity style={s.notifBtn} onPress={() => navigation.navigate('Notifications')}>
              <Text style={{ fontSize:18 }}>🔔</Text>
              {unreadCount > 0 && (
                <View style={s.notifBadge}>
                  <Text style={s.notifBadgeTxt}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                </View>
              )}
            </TouchableOpacity>
            <View style={s.onlineRow}>
              <Text style={[s.onlineLabel, { color:isOnline ? Colors.success : Colors.textMuted }]}>
                {isOnline ? '● Online' : '○ Offline'}
              </Text>
              <Switch value={isOnline} onValueChange={toggleOnline} disabled={toggling}
                trackColor={{ false:Colors.surface3, true:Colors.success }} thumbColor={Colors.white}/>
            </View>
          </View>
        </View>

        {/* Commission Lock Banner */}
        {profile?.isCommissionLocked && (
          <TouchableOpacity style={s.lockBanner} onPress={() => navigation.navigate('Commission')}>
            <Text style={{ fontSize:22 }}>🔒</Text>
            <View style={{ flex:1 }}>
              <Text style={s.lockTitle}>Commission Due: ₨ {profile.pendingCommission.toLocaleString()}</Text>
              <Text style={s.lockSub}>Tap to pay and unlock new jobs</Text>
            </View>
            <Text style={{ fontSize:20, color:Colors.danger }}>›</Text>
          </TouchableOpacity>
        )}

        {/* Stats */}
        {profile && (
          <View style={s.statsGrid}>
            <View style={s.statCard}>
              <Text style={[s.statVal, { color:Colors.success }]}>₨ {profile.totalEarnings.toLocaleString()}</Text>
              <Text style={s.statLabel}>Total Earned</Text>
            </View>
            <View style={s.statCard}>
              <Text style={s.statVal}>{profile.totalJobs}</Text>
              <Text style={s.statLabel}>Jobs Done</Text>
            </View>
            <View style={s.statCard}>
              <Text style={[s.statVal, { color:Colors.warning }]}>{profile.averageRating.toFixed(1)} ★</Text>
              <Text style={s.statLabel}>Rating</Text>
            </View>
            <View style={s.statCard}>
              <Text style={s.statVal}>{service?.icon || '🛠️'}</Text>
              <Text style={s.statLabel}>{service?.label || 'Skill'}</Text>
            </View>
          </View>
        )}

        {/* Active job banner */}
        {profile?.activeBooking && (
          <TouchableOpacity style={s.activeJobBanner}
            onPress={() => navigation.navigate('ActiveJob', { bookingId: profile.activeBooking })}>
            <Text style={{ fontSize:22 }}>⚡</Text>
            <View style={{ flex:1 }}>
              <Text style={s.activeJobTitle}>Active Job In Progress</Text>
              <Text style={s.activeJobSub}>Tap to manage current job</Text>
            </View>
            <Text style={{ color:Colors.primary, fontSize:20 }}>›</Text>
          </TouchableOpacity>
        )}

        {/* InDrive mode info */}
        <View style={s.indriveInfo}>
          <Text style={s.indriveInfoTxt}>
            🏎️ <Text style={{ fontWeight:FontWeight.bold }}>InDrive Mode: </Text>
            Send your price offer. Customer chooses the best technician.
          </Text>
        </View>

        {/* Incoming Requests */}
        <Text style={s.sectionTitle}>
          📥 Nearby Requests
          {requests.length > 0 && (
            <Text style={{ color:Colors.primary }}> ({requests.length})</Text>
          )}
        </Text>

        {requests.length === 0 ? (
          <View style={s.emptyBox}>
            <Text style={{ fontSize:36 }}>📡</Text>
            <Text style={s.emptyTitle}>
              {isOnline ? 'Listening for jobs...' : 'Go online to see jobs'}
            </Text>
            <Text style={s.emptySub}>
              {isOnline
                ? 'New customer requests appear here. Send your price offer!'
                : 'Toggle the switch above to start receiving job requests'}
            </Text>
          </View>
        ) : (
          requests.map(req => {
            const sv   = SERVICE_TYPES.find(x => x.key === req.serviceType);
            const cust = req.customer as any;
            const timeAgo = (() => {
              try {
                const d = Date.now() - new Date(req.createdAt).getTime();
                return d < 60000 ? 'Just now' : `${Math.floor(d/60000)}m ago`;
              } catch { return ''; }
            })();

            return (
              <Card key={req._id} highlight>
                {/* Request Header */}
                <View style={s.reqHeader}>
                  <View style={s.reqIcon}>
                    <Text style={{ fontSize:22 }}>{sv?.icon || '🛠️'}</Text>
                  </View>
                  <View style={{ flex:1 }}>
                    <Text style={s.reqService}>{sv?.label || req.serviceType}</Text>
                    <Text style={s.reqCustomer}>👤 {cust?.fullName || 'Customer'}</Text>
                    <Text style={s.reqTime}>{timeAgo}</Text>
                  </View>
                  <Badge label="New" color={Colors.primary} bg={Colors.primaryBg} dot/>
                </View>

                {/* Problem description */}
                <Text style={s.reqDesc} numberOfLines={2}>{req.problemDescription}</Text>
                <Text style={s.reqAddr}>📍 {req.customerLocation?.address}, {req.customerLocation?.city}</Text>

                {/* Action buttons */}
                <View style={s.reqBtns}>
                  <Button
                    title="💰 Send Offer"
                    onPress={() => handleSendOffer(req._id)}
                    size="sm"
                    style={{ flex:2 }}
                  />
                  <Button
                    title="✕ Skip"
                    onPress={() => handleReject(req._id)}
                    variant="ghost"
                    size="sm"
                    style={{ flex:1 }}
                  />
                </View>
              </Card>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:            { flex:1, backgroundColor:Colors.bg },
  scroll:          { paddingHorizontal:Spacing.xl, paddingTop:Spacing.md, paddingBottom:100 },
  header:          { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:Spacing.lg },
  headerSub:       { fontSize:FontSize.sm, color:Colors.textMuted },
  headerName:      { fontSize:FontSize.xl, fontWeight:FontWeight.bold, color:Colors.text },
  headerRight:     { flexDirection:'row', alignItems:'center', gap:10 },
  notifBtn:        { width:38, height:38, borderRadius:19, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:Colors.border },
  notifBadge:      { position:'absolute', top:-4, right:-4, backgroundColor:Colors.danger, borderRadius:10, minWidth:18, height:18, alignItems:'center', justifyContent:'center', paddingHorizontal:3, borderWidth:1.5, borderColor:Colors.bg },
  notifBadgeTxt:   { fontSize:9, color:Colors.white, fontWeight:FontWeight.bold },
  onlineRow:       { flexDirection:'row', alignItems:'center', gap:6 },
  onlineLabel:     { fontSize:FontSize.sm, fontWeight:FontWeight.semibold },
  lockBanner:      { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.dangerBg, borderRadius:Radius.lg, borderWidth:1, borderColor:'rgba(239,68,68,0.3)', padding:Spacing.lg, marginBottom:Spacing.lg },
  lockTitle:       { fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.danger },
  lockSub:         { fontSize:FontSize.xs, color:Colors.danger, marginTop:2 },
  statsGrid:       { flexDirection:'row', flexWrap:'wrap', gap:10, marginBottom:Spacing.lg },
  statCard:        { flex:1, minWidth:'45%', backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, alignItems:'center', gap:4 },
  statVal:         { fontSize:FontSize.xl, fontWeight:FontWeight.extrabold, color:Colors.text },
  statLabel:       { fontSize:FontSize.xs, color:Colors.textMuted },
  activeJobBanner: { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.primaryBg, borderRadius:Radius.lg, borderWidth:1, borderColor:'rgba(255,92,26,0.3)', padding:Spacing.lg, marginBottom:Spacing.lg },
  activeJobTitle:  { fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.primary },
  activeJobSub:    { fontSize:FontSize.xs, color:Colors.primary },
  indriveInfo:     { backgroundColor:'rgba(59,130,246,0.08)', borderRadius:Radius.md, padding:Spacing.md, marginBottom:Spacing.lg, borderWidth:1, borderColor:'rgba(59,130,246,0.15)' },
  indriveInfoTxt:  { fontSize:FontSize.sm, color:Colors.info, lineHeight:18 },
  sectionTitle:    { fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:Spacing.md },
  emptyBox:        { alignItems:'center', backgroundColor:Colors.surface, borderRadius:Radius.xl, padding:Spacing.xxl, borderWidth:1, borderColor:Colors.border, gap:8 },
  emptyTitle:      { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text },
  emptySub:        { fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:18 },
  reqHeader:       { flexDirection:'row', alignItems:'center', gap:10, marginBottom:10 },
  reqIcon:         { width:44, height:44, borderRadius:Radius.md, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center' },
  reqService:      { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text },
  reqCustomer:     { fontSize:FontSize.sm, color:Colors.textMuted },
  reqTime:         { fontSize:FontSize.xs, color:Colors.textMuted },
  reqDesc:         { fontSize:FontSize.sm, color:Colors.textLight, lineHeight:18, marginBottom:6 },
  reqAddr:         { fontSize:FontSize.sm, color:Colors.textMuted, marginBottom:12 },
  reqBtns:         { flexDirection:'row', gap:10 },
});
