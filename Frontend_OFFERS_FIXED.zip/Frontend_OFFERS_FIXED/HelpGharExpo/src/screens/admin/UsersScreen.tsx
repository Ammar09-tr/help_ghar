import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { adminApi } from '../../api/services';
import { User } from '../../types';
import { Card, Button, EmptyState } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const FILTERS = [{key:'customer',label:'👤 Customers'},{key:'technician',label:'🔧 Technicians'}];

export default function AdminUsersScreen({ navigation }: any) {
  const [users, setUsers]       = useState<User[]>([]);
  const [filter, setFilter]     = useState('customer');
  const [loading, setLoading]   = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async (role?: string) => {
    setLoading(true);
    try { const r = await adminApi.getUsers(role||undefined); setUsers(r.data); }
    catch {} finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(filter); }, [filter]));

  const deactivate = (id: string, name: string) => {
    Alert.alert('Deactivate User',`Deactivate ${name}?`,[
      {text:'Cancel'},
      {text:'Deactivate',style:'destructive',onPress:async()=>{
        try { await adminApi.deactivateUser(id); load(filter); }
        catch {}
      }},
    ]);
  };

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}><Text style={s.title}>Users</Text></View>
      <FlatList horizontal data={FILTERS} keyExtractor={i=>i.key}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{paddingHorizontal:Spacing.xl,paddingBottom:Spacing.md,gap:8}}
        renderItem={({item})=>(
          <TouchableOpacity style={[s.filterBtn,filter===item.key&&s.filterBtnActive]} onPress={()=>setFilter(item.key)}>
            <Text style={[s.filterTxt,filter===item.key&&{color:Colors.primary}]}>{item.label}</Text>
          </TouchableOpacity>
        )}
      />
      {loading
        ? <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
        : <FlatList data={users} keyExtractor={u=>u._id}
            contentContainerStyle={{paddingHorizontal:Spacing.xl,paddingBottom:100}}
            showsVerticalScrollIndicator={false}
            onRefresh={()=>{setRefreshing(true);load(filter);}}
            refreshing={refreshing}
            ListEmptyComponent={<EmptyState emoji="👥" title="No users found"/>}
            renderItem={({item})=>(
              <Card>
                <View style={s.row}>
                  <View style={s.avatar}><Text style={{fontSize:22}}>{filter==='customer'?'👤':'🔧'}</Text></View>
                  <View style={{flex:1}}>
                    <Text style={s.name}>{item.fullName}</Text>
                    <Text style={s.meta}>{item.email}</Text>
                    <Text style={s.meta}>{item.phone}</Text>
                  </View>
                  <View style={{alignItems:'flex-end',gap:4}}>
                    <View style={[s.statusDot,{backgroundColor:item.isActive?Colors.success:Colors.danger}]}/>
                    <Text style={{fontSize:FontSize.xs,color:item.isActive?Colors.success:Colors.danger}}>
                      {item.isActive?'Active':'Inactive'}
                    </Text>
                  </View>
                </View>
                {item.isActive && (
                  <Button title="Deactivate" onPress={()=>deactivate(item._id,item.fullName)}
                    variant="ghost" size="sm" style={{marginTop:8}}/>
                )}
              </Card>
            )}
          />
      }
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:      {flex:1,backgroundColor:Colors.bg},
  center:    {flex:1,alignItems:'center',justifyContent:'center'},
  header:    {paddingHorizontal:Spacing.xl,paddingTop:Spacing.lg,paddingBottom:Spacing.md},
  title:     {fontSize:FontSize.xxl,fontWeight:FontWeight.extrabold,color:Colors.text},
  filterBtn: {paddingVertical:8,paddingHorizontal:16,borderRadius:Radius.full,backgroundColor:Colors.surface2,borderWidth:1,borderColor:Colors.border},
  filterBtnActive:{backgroundColor:Colors.primaryBg,borderColor:Colors.primary},
  filterTxt: {fontSize:FontSize.sm,fontWeight:FontWeight.medium,color:Colors.textMuted},
  row:       {flexDirection:'row',gap:12,alignItems:'center',marginBottom:6},
  avatar:    {width:44,height:44,borderRadius:22,backgroundColor:Colors.surface2,alignItems:'center',justifyContent:'center'},
  name:      {fontSize:FontSize.md,fontWeight:FontWeight.bold,color:Colors.text},
  meta:      {fontSize:FontSize.xs,color:Colors.textMuted,marginTop:1},
  statusDot: {width:8,height:8,borderRadius:4},
});
