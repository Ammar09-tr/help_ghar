import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { adminApi, commissionApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function AdminDashboardScreen({ navigation }: any) {
  const user = useAuthStore(s => s.user);
  const [stats, setStats]       = useState<any>(null);
  const [commStats, setCommStats] = useState<any>(null);
  const [loading, setLoading]   = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const [sRes, cRes] = await Promise.all([
        adminApi.getDashboard(),
        adminApi.adminGetStats(),
      ]);
      setStats(sRes.data);
      setCommStats(cRes.data);
    } catch {}
    finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  if (loading) return (
    <SafeAreaView style={s.safe}>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </SafeAreaView>
  );

  const STATS = [
    { val:stats?.users?.total||0,            label:'Total Users',        icon:'👥', color:Colors.info },
    { val:stats?.technicians?.total||0,       label:'Technicians',        icon:'🔧', color:Colors.primary },
    { val:stats?.technicians?.pending||0,     label:'Pending Approval',   icon:'⏳', color:Colors.warning },
    { val:stats?.bookings?.total||0,          label:'Total Bookings',     icon:'📋', color:Colors.text },
    { val:stats?.bookings?.active||0,         label:'Active Now',         icon:'⚡', color:Colors.primary },
    { val:stats?.bookings?.completed||0,      label:'Completed',          icon:'✅', color:Colors.success },
    { val:`₨ ${(commStats?.paid?.total||0).toLocaleString()}`,    label:'Revenue Earned',   icon:'💰', color:Colors.success },
    { val:`₨ ${(commStats?.pending?.total||0).toLocaleString()}`, label:'Pending Commission',icon:'🔒', color:Colors.danger },
  ];

  const ACTIONS = [
    { icon:'🔧', label:'Technicians',    badge:stats?.technicians?.pending, screen:'Technicians' },
    { icon:'📋', label:'All Bookings',   badge:stats?.bookings?.active,    screen:'All Bookings' },
    { icon:'👥', label:'Users',          badge:null,                        screen:'Users' },
    { icon:'💰', label:'Commission',     badge:commStats?.pending?.count,   screen:null },
  ];

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>{setRefreshing(true);load();}} tintColor={Colors.primary}/>}
        contentContainerStyle={s.scroll}
      >
        {/* Header */}
        <View style={s.header}>
          <View>
            <Text style={s.headerSub}>Admin Panel ⚙️</Text>
            <Text style={s.headerName}>{user?.fullName}</Text>
          </View>
          <TouchableOpacity style={s.refreshBtn} onPress={load}>
            <Text style={{ fontSize:18 }}>↻</Text>
          </TouchableOpacity>
        </View>

        {/* Stats Grid */}
        <Text style={s.sectionTitle}>Platform Overview</Text>
        <View style={s.grid}>
          {STATS.map((st,i)=>(
            <View key={i} style={s.statCard}>
              <Text style={{ fontSize:22 }}>{st.icon}</Text>
              <Text style={[s.statVal, { color:st.color }]}>{st.val}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        {/* Quick Actions */}
        <Text style={s.sectionTitle}>Quick Actions</Text>
        <View style={s.actionsGrid}>
          {ACTIONS.map((a,i)=>(
            <TouchableOpacity key={i} style={s.actionCard}
              onPress={()=>a.screen && navigation.navigate(a.screen)}
              activeOpacity={0.8}
            >
              <Text style={{ fontSize:30 }}>{a.icon}</Text>
              <Text style={s.actionLabel}>{a.label}</Text>
              {a.badge > 0 && (
                <View style={s.badge}>
                  <Text style={s.badgeTxt}>{a.badge > 99 ? '99+' : a.badge}</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Pending Technicians Alert */}
        {stats?.technicians?.pending > 0 && (
          <TouchableOpacity style={s.alertBanner} onPress={() => navigation.navigate('Technicians')}>
            <Text style={{ fontSize:22 }}>⚠️</Text>
            <View style={{ flex:1 }}>
              <Text style={s.alertTitle}>{stats.technicians.pending} Technicians Pending Approval</Text>
              <Text style={s.alertSub}>Review and approve technician registrations</Text>
            </View>
            <Text style={{ fontSize:20, color:Colors.warning }}>›</Text>
          </TouchableOpacity>
        )}

        {/* Commission Alert */}
        {commStats?.pending?.total > 0 && (
          <View style={s.commBanner}>
            <Text style={{ fontSize:22 }}>💰</Text>
            <View style={{ flex:1 }}>
              <Text style={s.commTitle}>₨ {commStats.pending.total.toLocaleString()} Commission Pending</Text>
              <Text style={s.commSub}>{commStats.pending.count} technicians have unpaid commission</Text>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:        { flex:1, backgroundColor:Colors.bg },
  center:      { flex:1, alignItems:'center', justifyContent:'center' },
  scroll:      { paddingHorizontal:Spacing.xl, paddingTop:Spacing.md, paddingBottom:100 },
  header:      { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:Spacing.xl },
  headerSub:   { fontSize:FontSize.sm, color:Colors.textMuted },
  headerName:  { fontSize:FontSize.xl, fontWeight:FontWeight.bold, color:Colors.text },
  refreshBtn:  { width:38, height:38, borderRadius:19, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:Colors.border },
  sectionTitle:{ fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:Spacing.md },
  grid:        { flexDirection:'row', flexWrap:'wrap', gap:10, marginBottom:Spacing.xl },
  statCard:    { width:'47%', backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, alignItems:'center', gap:4 },
  statVal:     { fontSize:FontSize.xl, fontWeight:FontWeight.extrabold },
  statLabel:   { fontSize:FontSize.xs, color:Colors.textMuted, textAlign:'center' },
  actionsGrid: { flexDirection:'row', flexWrap:'wrap', gap:10, marginBottom:Spacing.xl },
  actionCard:  { width:'47%', backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, alignItems:'center', gap:8, position:'relative' },
  actionLabel: { fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.text, textAlign:'center' },
  badge:       { position:'absolute', top:8, right:8, backgroundColor:Colors.danger, borderRadius:10, minWidth:20, height:20, alignItems:'center', justifyContent:'center', paddingHorizontal:4 },
  badgeTxt:    { fontSize:10, color:Colors.white, fontWeight:FontWeight.bold },
  alertBanner: { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.warningBg, borderRadius:Radius.lg, borderWidth:1, borderColor:'rgba(245,158,11,0.3)', padding:Spacing.lg, marginBottom:Spacing.md },
  alertTitle:  { fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.warning },
  alertSub:    { fontSize:FontSize.xs, color:Colors.warning, opacity:0.8 },
  commBanner:  { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.successBg, borderRadius:Radius.lg, borderWidth:1, borderColor:'rgba(34,197,94,0.3)', padding:Spacing.lg },
  commTitle:   { fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.success },
  commSub:     { fontSize:FontSize.xs, color:Colors.success, opacity:0.8 },
});
