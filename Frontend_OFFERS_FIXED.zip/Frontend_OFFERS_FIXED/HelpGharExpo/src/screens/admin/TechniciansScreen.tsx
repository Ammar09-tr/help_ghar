import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Alert, ActivityIndicator, TextInput
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { adminApi } from '../../api/services';
import { Technician } from '../../types';
import { Card, Button, Badge, Stars, EmptyState } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

const FILTERS = [
  {key:'pending',label:'⏳ Pending'},
  {key:'approved',label:'✅ Approved'},
  {key:'rejected',label:'❌ Rejected'},
  {key:'suspended',label:'🚫 Suspended'},
  {key:'',label:'All'},
];

export default function AdminTechniciansScreen() {
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [filter, setFilter]           = useState('pending');
  const [search, setSearch]           = useState('');
  const [loading, setLoading]         = useState(true);
  const [refreshing, setRefreshing]   = useState(false);

  const load = async (status?: string) => {
    setLoading(true);
    try { const r = await adminApi.getTechnicians(status||undefined); setTechnicians(r.data); }
    catch {} finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(filter); }, [filter]));

  const filtered = search
    ? technicians.filter(t => {
        const u = t.user as any;
        return u?.fullName?.toLowerCase().includes(search.toLowerCase()) ||
               u?.email?.toLowerCase().includes(search.toLowerCase()) ||
               t.skill?.toLowerCase().includes(search.toLowerCase());
      })
    : technicians;

  const approve = async (id: string, name: string) => {
    Alert.alert('Approve', `Approve ${name}?`, [
      { text:'Cancel' },
      { text:'Approve', onPress: async () => {
        try { await adminApi.approveTechnician(id); load(filter); Alert.alert('Done', `${name} approved! ✅`); }
        catch (err:any) { Alert.alert('Error', err?.response?.data?.message||'Failed'); }
      }},
    ]);
  };

  const reject = async (id: string, name: string) => {
    Alert.alert('Reject', `Reject ${name}?`, [
      { text:'Cancel' },
      { text:'Reject', style:'destructive', onPress: async () => {
        try { await adminApi.rejectTechnician(id,'Not meeting requirements'); load(filter); }
        catch {}
      }},
    ]);
  };

  const suspend = async (id: string) => {
    Alert.alert('Suspend Technician', 'This will prevent them from accepting jobs.', [
      { text:'Cancel' },
      { text:'Suspend', style:'destructive', onPress: async () => {
        try { await adminApi.suspendTechnician(id); load(filter); }
        catch {}
      }},
    ]);
  };

  const sColors: Record<string,string> = {
    pending:Colors.warning, approved:Colors.success,
    rejected:Colors.danger, suspended:Colors.textMuted,
  };

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Text style={s.title}>Technicians</Text>
        <Text style={s.count}>{filtered.length} found</Text>
      </View>

      {/* Search */}
      <View style={s.searchBar}>
        <Text style={{ fontSize:16 }}>🔍</Text>
        <TextInput style={s.searchInput} placeholder="Search by name, email, skill..."
          placeholderTextColor={Colors.textMuted} value={search} onChangeText={setSearch}/>
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Text style={{ color:Colors.textMuted }}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Filter tabs */}
      <FlatList horizontal data={FILTERS} keyExtractor={i=>i.key}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal:Spacing.xl, paddingBottom:Spacing.md, gap:8 }}
        renderItem={({item}) => (
          <TouchableOpacity style={[s.filterBtn, filter===item.key&&s.filterBtnActive]} onPress={()=>setFilter(item.key)}>
            <Text style={[s.filterTxt, filter===item.key&&{color:Colors.primary}]}>{item.label}</Text>
          </TouchableOpacity>
        )}
      />

      {loading ? (
        <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={t => t._id}
          contentContainerStyle={{ paddingHorizontal:Spacing.xl, paddingBottom:100 }}
          showsVerticalScrollIndicator={false}
          onRefresh={() => { setRefreshing(true); load(filter); }}
          refreshing={refreshing}
          ListEmptyComponent={<EmptyState emoji="🔧" title="No technicians" subtitle="No technicians in this category"/>}
          renderItem={({ item }) => {
            const u = item.user as any;
            const service = SERVICE_TYPES.find(sv => sv.key === item.skill);
            return (
              <Card>
                <View style={s.row}>
                  <View style={s.avatar}><Text style={{ fontSize:24 }}>👨‍🔧</Text></View>
                  <View style={{ flex:1 }}>
                    <View style={{ flexDirection:'row', alignItems:'center', gap:6 }}>
                      <Text style={s.name}>{u?.fullName || 'Technician'}</Text>
                      {item.cnicVerificationStatus === 'verified' && (
                        <Text style={{ fontSize:12 }}>✅</Text>
                      )}
                    </View>
                    <Text style={s.meta}>{service?.icon} {service?.label}</Text>
                    <Text style={s.meta}>📧 {u?.email}</Text>
                    <Text style={s.meta}>📞 {u?.phone}</Text>
                    {item.averageRating > 0 && <Stars rating={item.averageRating}/>}
                  </View>
                  <Badge
                    label={item.status}
                    color={sColors[item.status]||Colors.textMuted}
                    bg={(sColors[item.status]||Colors.textMuted)+'20'}
                    dot
                  />
                </View>

                {/* Stats tags */}
                <View style={s.tags}>
                  {[
                    `🪪 ${item.cnic||'N/A'}`,
                    `💼 ${item.yearsOfExperience}yr`,
                    `✅ ${item.totalJobs} jobs`,
                    `⭐ ${item.averageRating.toFixed(1)}`,
                    item.isCommissionLocked ? '🔒 Locked' : '🔓 Unlocked',
                  ].map((t,i) => (
                    <View key={i} style={[s.tag, t.includes('Locked') && !t.includes('Unlocked') && { backgroundColor:Colors.dangerBg }]}>
                      <Text style={[s.tagTxt, t.includes('Locked') && !t.includes('Unlocked') && { color:Colors.danger }]}>{t}</Text>
                    </View>
                  ))}
                </View>

                {/* Actions */}
                {item.status === 'pending' && (
                  <View style={s.btnRow}>
                    <Button title="✓ Approve" onPress={() => approve(item._id, u?.fullName||'')} variant="success" size="sm" style={{ flex:1 }}/>
                    <Button title="✕ Reject"  onPress={() => reject(item._id, u?.fullName||'')}  variant="danger"  size="sm" style={{ flex:1 }}/>
                  </View>
                )}
                {item.status === 'approved' && (
                  <Button title="🚫 Suspend" onPress={() => suspend(item._id)} variant="ghost" size="sm" style={{ marginTop:10 }}/>
                )}
              </Card>
            );
          }}
        />
      )}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:    { flex:1, backgroundColor:Colors.bg },
  center:  { flex:1, alignItems:'center', justifyContent:'center' },
  header:  { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:Spacing.xl, paddingTop:Spacing.lg, paddingBottom:Spacing.sm },
  title:   { fontSize:FontSize.xxl, fontWeight:FontWeight.extrabold, color:Colors.text },
  count:   { fontSize:FontSize.sm, color:Colors.textMuted },
  searchBar:  { flexDirection:'row', alignItems:'center', gap:10, backgroundColor:Colors.surface2, borderRadius:Radius.lg, paddingHorizontal:Spacing.lg, paddingVertical:10, marginHorizontal:Spacing.xl, marginBottom:Spacing.md, borderWidth:1, borderColor:Colors.border },
  searchInput:{ flex:1, color:Colors.text, fontSize:FontSize.md },
  filterBtn:  { paddingVertical:8, paddingHorizontal:14, borderRadius:Radius.full, backgroundColor:Colors.surface2, borderWidth:1, borderColor:Colors.border },
  filterBtnActive:{ backgroundColor:Colors.primaryBg, borderColor:Colors.primary },
  filterTxt:  { fontSize:FontSize.sm, fontWeight:FontWeight.medium, color:Colors.textMuted },
  row:     { flexDirection:'row', gap:12, alignItems:'flex-start', marginBottom:10 },
  avatar:  { width:46, height:46, borderRadius:23, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center' },
  name:    { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text },
  meta:    { fontSize:FontSize.xs, color:Colors.textMuted, marginTop:1 },
  tags:    { flexDirection:'row', gap:6, flexWrap:'wrap', marginBottom:10 },
  tag:     { paddingVertical:3, paddingHorizontal:8, borderRadius:Radius.full, backgroundColor:Colors.surface2 },
  tagTxt:  { fontSize:FontSize.xs, color:Colors.textMuted },
  btnRow:  { flexDirection:'row', gap:10 },
});
