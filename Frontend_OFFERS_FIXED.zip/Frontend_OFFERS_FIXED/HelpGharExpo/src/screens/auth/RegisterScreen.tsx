import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { authApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { Input, Button } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function RegisterScreen({ navigation }: any) {
  const [role, setRole]   = useState<'customer'|'technician'>('customer');
  const [form, setForm]   = useState({ fullName:'',email:'',phone:'',password:'',confirmPassword:'',cnic:'',skill:'electrician',yearsOfExperience:'',bio:'' });
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [loading, setLoading] = useState(false);
  const setAuth = useAuthStore(s => s.setAuth);
  const set = (k:string,v:string) => setForm(f=>({...f,[k]:v}));

  const validate = () => {
    const e:Record<string,string> = {};
    if (!form.fullName.trim())  e.fullName = 'Full name is required';
    if (!form.email.trim())     e.email    = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email';
    if (!form.phone.trim())     e.phone    = 'Phone is required';
    if (!form.password)         e.password = 'Password required';
    else if (form.password.length<6) e.password = 'Minimum 6 characters';
    if (form.password!==form.confirmPassword) e.confirmPassword = 'Passwords do not match';
    if (role==='technician' && !form.cnic.trim()) e.cnic = 'CNIC is required';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      if (role==='customer') {
        const res = await authApi.registerCustomer({ fullName:form.fullName.trim(), email:form.email.toLowerCase().trim(), phone:form.phone.trim(), password:form.password });
        await setAuth(res.data.access_token, res.data.user as any);
        navigation.reset({ index:0, routes:[{name:'CustomerApp'}] });
      } else {
        await authApi.registerTechnician({ fullName:form.fullName.trim(), email:form.email.toLowerCase().trim(), phone:form.phone.trim(), password:form.password, cnic:form.cnic.trim(), skill:form.skill, yearsOfExperience:form.yearsOfExperience?Number(form.yearsOfExperience):0, bio:form.bio.trim() });
        Alert.alert('Registration Submitted ✅','Your technician account is pending admin approval. You will be notified once approved.',[{ text:'OK', onPress:()=>navigation.navigate('Login') }]);
      }
    } catch (err:any) {
      const msg = err?.response?.data?.message || 'Registration failed.';
      Alert.alert('Error', Array.isArray(msg)?msg.join('\n'):msg);
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1}}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>
          <TouchableOpacity style={s.backBtn} onPress={()=>navigation.goBack()}>
            <Text style={{fontSize:18,color:Colors.text}}>←</Text>
          </TouchableOpacity>
          <Text style={s.heading}>Create Account</Text>
          <Text style={s.sub}>Join HelpGhar today</Text>

          {/* Role toggle */}
          <View style={s.roleRow}>
            {(['customer','technician'] as const).map(r=>(
              <TouchableOpacity key={r} style={[s.roleBtn,role===r&&s.roleBtnActive]} onPress={()=>setRole(r)}>
                <Text style={s.roleIcon}>{r==='customer'?'👤':'🔧'}</Text>
                <Text style={[s.roleLabel,role===r&&{color:Colors.white}]}>{r==='customer'?'Customer':'Technician'}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {role==='technician'&&(
            <View style={s.infoBanner}>
              <Text style={{fontSize:FontSize.sm,color:Colors.warning,lineHeight:18}}>⚠️  Technician accounts require admin approval before login.</Text>
            </View>
          )}

          <Input label="Full Name" placeholder="Ali Hassan" value={form.fullName} onChangeText={v=>set('fullName',v)} leftIcon="👤" error={errors.fullName}/>
          <Input label="Email" placeholder="ali@email.com" value={form.email} onChangeText={v=>set('email',v)} keyboardType="email-address" autoCapitalize="none" leftIcon="📧" error={errors.email}/>
          <Input label="Phone" placeholder="+923001234567" value={form.phone} onChangeText={v=>set('phone',v)} keyboardType="phone-pad" leftIcon="📞" error={errors.phone}/>
          <Input label="Password" placeholder="Min. 6 characters" value={form.password} onChangeText={v=>set('password',v)} secureTextEntry leftIcon="🔒" error={errors.password}/>
          <Input label="Confirm Password" placeholder="Re-enter password" value={form.confirmPassword} onChangeText={v=>set('confirmPassword',v)} secureTextEntry leftIcon="🔒" error={errors.confirmPassword}/>

          {role==='technician'&&(
            <>
              <Input label="CNIC" placeholder="36302-1234567-1" value={form.cnic} onChangeText={v=>set('cnic',v)} keyboardType="numeric" leftIcon="🪪" error={errors.cnic}/>
              <Text style={s.skillLabel}>Your Skill</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:Spacing.lg}}>
                {SERVICE_TYPES.map(sv=>(
                  <TouchableOpacity key={sv.key}
                    style={[s.skillChip, form.skill===sv.key&&s.skillChipActive]}
                    onPress={()=>set('skill',sv.key)}
                  >
                    <Text style={{fontSize:16}}>{sv.icon}</Text>
                    <Text style={[s.skillTxt, form.skill===sv.key&&{color:Colors.primary}]}>{sv.label}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <Input label="Years of Experience" placeholder="e.g. 5" value={form.yearsOfExperience} onChangeText={v=>set('yearsOfExperience',v)} keyboardType="numeric" leftIcon="📅"/>
              <Input label="Bio (optional)" placeholder="Describe your expertise..." value={form.bio} onChangeText={v=>set('bio',v)} multiline numberOfLines={3} style={{height:80,textAlignVertical:'top',paddingTop:12} as any}/>
            </>
          )}

          <Button title={role==='customer'?'Create Account →':'Submit for Approval →'} onPress={handleRegister} loading={loading} style={{marginTop:8}}/>

          <TouchableOpacity style={s.loginLink} onPress={()=>navigation.navigate('Login')}>
            <Text style={{fontSize:FontSize.sm,color:Colors.textMuted}}>Already have an account? <Text style={{color:Colors.primary}}>Sign In</Text></Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:   {flex:1,backgroundColor:Colors.bg},
  scroll: {flexGrow:1,paddingHorizontal:24,paddingVertical:20},
  backBtn:{width:36,height:36,borderRadius:18,backgroundColor:Colors.surface2,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:Colors.border,marginBottom:24},
  heading:{fontSize:FontSize.xxxl,fontWeight:FontWeight.extrabold,color:Colors.text,marginBottom:4},
  sub:    {fontSize:FontSize.md,color:Colors.textMuted,marginBottom:24},
  roleRow:{flexDirection:'row',gap:8,marginBottom:20,backgroundColor:Colors.surface2,borderRadius:Radius.md,padding:4},
  roleBtn:{flex:1,alignItems:'center',paddingVertical:12,borderRadius:Radius.sm,flexDirection:'row',justifyContent:'center',gap:8},
  roleBtnActive:{backgroundColor:Colors.primary},
  roleIcon:{fontSize:18},
  roleLabel:{fontSize:FontSize.sm,fontWeight:FontWeight.semibold,color:Colors.textMuted},
  infoBanner:{backgroundColor:'rgba(245,158,11,0.12)',borderRadius:Radius.md,borderWidth:1,borderColor:'rgba(245,158,11,0.3)',padding:12,marginBottom:16},
  skillLabel:{fontSize:FontSize.xs,color:Colors.textMuted,fontWeight:FontWeight.medium,marginBottom:8,textTransform:'uppercase',letterSpacing:0.5},
  skillChip: {flexDirection:'row',alignItems:'center',gap:6,paddingVertical:9,paddingHorizontal:14,borderRadius:Radius.full,borderWidth:1.5,borderColor:Colors.border,backgroundColor:Colors.surface2,marginRight:8},
  skillChipActive:{borderColor:Colors.primary,backgroundColor:Colors.primaryBg},
  skillTxt:{fontSize:FontSize.sm,color:Colors.textMuted,fontWeight:FontWeight.medium},
  loginLink:{alignItems:'center',marginTop:20,paddingBottom:20},
});
