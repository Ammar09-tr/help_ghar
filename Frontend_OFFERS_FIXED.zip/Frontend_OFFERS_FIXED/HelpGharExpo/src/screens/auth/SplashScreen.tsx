import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, FontSize, FontWeight, Spacing } from '../../constants/theme';

export default function SplashScreen({ navigation }: any) {
  const scale = useRef(new Animated.Value(0)).current;
  const fade  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.spring(scale, { toValue:1, tension:80, friction:8, useNativeDriver:true }),
      Animated.timing(fade,  { toValue:1, duration:500, useNativeDriver:true }),
    ]).start();
  }, []);

  return (
    <SafeAreaView style={s.safe}>
      <LinearGradient colors={['#0D0D0D','#1a0a05','#0D0D0D']} style={s.bg}/>
      <View style={s.container}>
        {/* Glow */}
        <View style={s.glow}/>

        {/* Logo */}
        <Animated.View style={[s.logoWrap,{transform:[{scale}]}]}>
          <LinearGradient colors={[Colors.primary,Colors.primaryDark]} style={s.logoBox}>
            <Text style={s.logoEmoji}>🏠</Text>
          </LinearGradient>
        </Animated.View>

        {/* Text */}
        <Animated.View style={[s.textWrap,{opacity:fade}]}>
          <Text style={s.appName}>Help<Text style={{color:Colors.primary}}>Ghar</Text></Text>
          <Text style={s.tagline}>Home services at your doorstep</Text>
          <Text style={s.sub}>Trusted electricians, plumbers, AC technicians{'\n'}and more — available near you.</Text>
        </Animated.View>

        {/* Buttons */}
        <Animated.View style={[s.btnWrap,{opacity:fade}]}>
          <TouchableOpacity style={s.btnPrimary} onPress={()=>navigation.navigate('Register')}>
            <Text style={s.btnPrimaryTxt}>Get Started  →</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.btnOutline} onPress={()=>navigation.navigate('Login')}>
            <Text style={s.btnOutlineTxt}>I already have an account</Text>
          </TouchableOpacity>
          <Text style={s.terms}>By continuing you agree to our Terms & Privacy Policy</Text>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:       { flex:1, backgroundColor:Colors.bg },
  bg:         { position:'absolute', inset:0 } as any,
  container:  { flex:1, alignItems:'center', justifyContent:'space-between', paddingHorizontal:28, paddingVertical:40 },
  glow:       { position:'absolute', top:-60, width:300, height:300, borderRadius:150, backgroundColor:'rgba(255,92,26,0.1)' },
  logoWrap:   { alignItems:'center', marginTop:20 },
  logoBox:    { width:100, height:100, borderRadius:28, alignItems:'center', justifyContent:'center', shadowColor:Colors.primary, shadowOffset:{width:0,height:12}, shadowOpacity:0.5, shadowRadius:20, elevation:14 },
  logoEmoji:  { fontSize:52 },
  textWrap:   { alignItems:'center', gap:10 },
  appName:    { fontSize:40, fontWeight:FontWeight.extrabold, color:Colors.text },
  tagline:    { fontSize:FontSize.md, color:Colors.textLight, marginTop:4 },
  sub:        { fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:20, marginTop:8 },
  btnWrap:    { width:'100%', gap:12 },
  btnPrimary: { backgroundColor:Colors.primary, borderRadius:14, paddingVertical:15, alignItems:'center', shadowColor:Colors.primary, shadowOffset:{width:0,height:6}, shadowOpacity:0.4, shadowRadius:12, elevation:8 },
  btnPrimaryTxt:{ fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.white },
  btnOutline: { borderRadius:14, paddingVertical:15, alignItems:'center', borderWidth:1.5, borderColor:Colors.border },
  btnOutlineTxt:{ fontSize:FontSize.md, fontWeight:FontWeight.semibold, color:Colors.text },
  terms:      { fontSize:FontSize.xs, color:Colors.textMuted, textAlign:'center', lineHeight:16 },
});
