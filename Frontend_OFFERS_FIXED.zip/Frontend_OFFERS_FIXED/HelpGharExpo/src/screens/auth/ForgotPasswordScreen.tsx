import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform,
  Alert, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Input } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import apiClient from '../../api/client';

export default function ForgotPasswordScreen({ navigation }: any) {
  const [step, setStep]             = useState<'email' | 'otp' | 'newpass'>('email');
  const [email, setEmail]           = useState('');
  const [otp, setOtp]               = useState('');
  const [newPassword, setNewPassword]     = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading]       = useState(false);
  const [errors, setErrors]         = useState<Record<string, string>>({});

  // Step 1: Email bhejo
  const handleSendEmail = async () => {
    if (!email.trim()) { setErrors({ email: 'Email required' }); return; }
    if (!/\S+@\S+\.\S+/.test(email)) { setErrors({ email: 'Invalid email' }); return; }
    setErrors({});
    setLoading(true);
    try {
      // Backend mein forgot password endpoint nahi hai abhi
      // Isliye direct alert show karte hain
      // Production mein implement karna hoga

      // Simulate karo
      await new Promise(r => setTimeout(r, 1000));
      Alert.alert(
        'OTP Sent 📧',
        `We have sent a password reset code to ${email}.\n\nFor testing use OTP: 123456`,
        [{ text: 'OK', onPress: () => setStep('otp') }]
      );
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.message || 'Could not send OTP');
    } finally { setLoading(false); }
  };

  // Step 2: OTP verify karo
  const handleVerifyOtp = async () => {
    if (!otp.trim()) { setErrors({ otp: 'OTP required' }); return; }
    if (otp.length < 4) { setErrors({ otp: 'Enter valid OTP' }); return; }
    setErrors({});
    setLoading(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      // Testing ke liye 123456 accept karo
      if (otp === '123456' || otp.length >= 4) {
        setStep('newpass');
      } else {
        Alert.alert('Wrong OTP', 'Please enter the correct OTP');
      }
    } finally { setLoading(false); }
  };

  // Step 3: New password set karo
  const handleResetPassword = async () => {
    const e: Record<string, string> = {};
    if (!newPassword) e.newPassword = 'Password required';
    else if (newPassword.length < 6) e.newPassword = 'Minimum 6 characters';
    if (newPassword !== confirmPassword) e.confirmPassword = 'Passwords do not match';
    if (Object.keys(e).length > 0) { setErrors(e); return; }
    setErrors({});
    setLoading(true);
    try {
      await new Promise(r => setTimeout(r, 1000));
      Alert.alert(
        'Password Reset! ✅',
        'Your password has been changed successfully. Please login with your new password.',
        [{ text: 'Login Now', onPress: () => navigation.navigate('Login') }]
      );
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={s.scroll}
          keyboardShouldPersistTaps="handled"
        >
          {/* Back */}
          <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
            <Text style={{ fontSize: 18, color: Colors.text }}>←</Text>
          </TouchableOpacity>

          {/* Icon */}
          <View style={s.iconWrap}>
            <Text style={{ fontSize: 52 }}>
              {step === 'email' ? '🔐' : step === 'otp' ? '📱' : '🔑'}
            </Text>
          </View>

          {/* Step indicators */}
          <View style={s.steps}>
            {['email', 'otp', 'newpass'].map((st, i) => (
              <View key={i} style={s.stepRow}>
                <View style={[s.stepDot, (step === st || (i === 0 && step !== 'email') || (i === 1 && step === 'newpass')) && s.stepDotDone]}>
                  <Text style={{ fontSize: 10, color: Colors.white }}>
                    {(i === 0 && step !== 'email') || (i === 1 && step === 'newpass') ? '✓' : i + 1}
                  </Text>
                </View>
                {i < 2 && <View style={[s.stepLine, ((i === 0 && step !== 'email') || (i === 1 && step === 'newpass')) && s.stepLineDone]} />}
              </View>
            ))}
          </View>

          {/* ── Step 1: Email ── */}
          {step === 'email' && (
            <View>
              <Text style={s.heading}>Forgot Password? 🤔</Text>
              <Text style={s.sub}>
                Apna registered email enter karo.{'\n'}
                Hum aapko password reset ka OTP bhejenge.
              </Text>
              <Input
                label="Email Address"
                placeholder="ali@example.com"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                leftIcon="📧"
                error={errors.email}
              />
              <TouchableOpacity
                style={[s.btn, loading && { opacity: 0.7 }]}
                onPress={handleSendEmail}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color={Colors.white} />
                  : <Text style={s.btnTxt}>Send OTP 📨</Text>
                }
              </TouchableOpacity>
            </View>
          )}

          {/* ── Step 2: OTP ── */}
          {step === 'otp' && (
            <View>
              <Text style={s.heading}>Enter OTP 🔢</Text>
              <Text style={s.sub}>
                OTP bheja gaya: <Text style={{ color: Colors.primary }}>{email}</Text>
                {'\n'}Spam folder bhi check karo.
              </Text>
              <Input
                label="OTP Code"
                placeholder="123456"
                value={otp}
                onChangeText={setOtp}
                keyboardType="numeric"
                maxLength={6}
                leftIcon="🔢"
                error={errors.otp}
              />
              <TouchableOpacity
                style={[s.btn, loading && { opacity: 0.7 }]}
                onPress={handleVerifyOtp}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color={Colors.white} />
                  : <Text style={s.btnTxt}>Verify OTP ✅</Text>
                }
              </TouchableOpacity>
              <TouchableOpacity
                style={s.resendBtn}
                onPress={() => { setStep('email'); setOtp(''); }}
              >
                <Text style={s.resendTxt}>← Change Email / Resend OTP</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ── Step 3: New Password ── */}
          {step === 'newpass' && (
            <View>
              <Text style={s.heading}>New Password 🔑</Text>
              <Text style={s.sub}>
                Apna naya password set karo.{'\n'}
                Minimum 6 characters hone chahiye.
              </Text>
              <Input
                label="New Password"
                placeholder="Minimum 6 characters"
                value={newPassword}
                onChangeText={setNewPassword}
                secureTextEntry
                leftIcon="🔒"
                error={errors.newPassword}
              />
              <Input
                label="Confirm New Password"
                placeholder="Re-enter new password"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
                leftIcon="🔒"
                error={errors.confirmPassword}
              />
              <TouchableOpacity
                style={[s.btn, loading && { opacity: 0.7 }]}
                onPress={handleResetPassword}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color={Colors.white} />
                  : <Text style={s.btnTxt}>Reset Password 🔑</Text>
                }
              </TouchableOpacity>
            </View>
          )}

          {/* Back to Login */}
          <TouchableOpacity
            style={s.loginLink}
            onPress={() => navigation.navigate('Login')}
          >
            <Text style={s.loginLinkTxt}>
              Yaad aa gaya? <Text style={{ color: Colors.primary }}>Sign In</Text>
            </Text>
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:       { flex: 1, backgroundColor: Colors.bg },
  scroll:     { flexGrow: 1, paddingHorizontal: 24, paddingVertical: 20 },
  backBtn:    { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border, marginBottom: 20 },
  iconWrap:   { alignItems: 'center', marginBottom: 20 },
  steps:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 28 },
  stepRow:    { flexDirection: 'row', alignItems: 'center' },
  stepDot:    { width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.surface3, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: Colors.border },
  stepDotDone:{ backgroundColor: Colors.primary, borderColor: Colors.primary },
  stepLine:   { width: 40, height: 2, backgroundColor: Colors.border },
  stepLineDone:{ backgroundColor: Colors.primary },
  heading:    { fontSize: FontSize.xxl, fontWeight: FontWeight.extrabold, color: Colors.text, marginBottom: 8 },
  sub:        { fontSize: FontSize.md, color: Colors.textMuted, lineHeight: 22, marginBottom: 24 },
  btn:        { backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 15, alignItems: 'center', shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  btnTxt:     { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.white },
  resendBtn:  { alignItems: 'center', marginTop: 16, paddingVertical: 8 },
  resendTxt:  { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.medium },
  loginLink:  { alignItems: 'center', marginTop: 28, paddingBottom: 20 },
  loginLinkTxt:{ fontSize: FontSize.sm, color: Colors.textMuted },
});
