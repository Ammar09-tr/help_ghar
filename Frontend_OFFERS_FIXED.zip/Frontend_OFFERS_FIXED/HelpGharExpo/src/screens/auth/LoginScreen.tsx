import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  KeyboardAvoidingView, Platform, Alert, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { authApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { Input } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function LoginScreen({ navigation }: any) {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [errors, setErrors]     = useState<Record<string, string>>({});
  const setAuth = useAuthStore(s => s.setAuth);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!email.trim())    e.email    = 'Email required';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Invalid email';
    if (!password)        e.password = 'Password required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await authApi.login({
        email:    email.toLowerCase().trim(),
        password: password,
      });
      await setAuth(res.data.access_token, res.data.user as any);
      const role = res.data.user.role;
      if (role === 'technician') {
        navigation.reset({ index: 0, routes: [{ name: 'TechnicianApp' }] });
      } else if (role === 'admin') {
        navigation.reset({ index: 0, routes: [{ name: 'AdminApp' }] });
      } else {
        navigation.reset({ index: 0, routes: [{ name: 'CustomerApp' }] });
      }
    } catch (err: any) {
      const msg = err?.response?.data?.message || 'Login failed. Check your credentials.';
      Alert.alert('Login Failed', Array.isArray(msg) ? msg.join('\n') : msg);
    } finally { setLoading(false); }
  };

  // // Quick fill for testing
  // const fillCustomer    = () => { setEmail('ali@example.com');    setPassword('Password@123'); };
  // const fillTechnician  = () => { setEmail('imran@example.com');  setPassword('Password@123'); };
  // const fillAdmin       = () => { setEmail('admin@helpghar.com'); setPassword('Password@123'); };

  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={s.scroll}
          keyboardShouldPersistTaps="handled"
        >
          {/* Back */}
          <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
            <Text style={{ fontSize: 18, color: Colors.text }}>←</Text>
          </TouchableOpacity>

          <Text style={s.heading}>Welcome Back 👋</Text>
          <Text style={s.sub}>Sign in to your account</Text>

          <Input
            label="Email"
            placeholder="ali@example.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            leftIcon="📧"
            error={errors.email}
          />

          <Input
            label="Password"
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            leftIcon="🔒"
            error={errors.password}
          />

          {/* Forgot Password */}
          <TouchableOpacity
            style={s.forgotBtn}
            onPress={() => navigation.navigate('ForgotPassword')}
          >
            <Text style={s.forgotTxt}>🔐 Forgot Password?</Text>
          </TouchableOpacity>

          {/* Login Button */}
          <TouchableOpacity
            style={[s.loginBtn, loading && { opacity: 0.7 }]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color={Colors.white} />
              : <Text style={s.loginBtnTxt}>Sign In →</Text>
            }
          </TouchableOpacity>

          {/* Divider */}
          <View style={s.divider}>
            <View style={s.line} />
            <Text style={s.orText}>or</Text>
            <View style={s.line} />
          </View>

          {/* Register */}
          <TouchableOpacity style={s.outlineBtn} onPress={() => navigation.navigate('Register')}>
            <Text style={s.outlineBtnTxt}>Create New Account</Text>
          </TouchableOpacity>

          {/* Test Accounts */}
          <View style={s.hint}>
            <Text style={s.hintTitle}>⚡ Quick Fill (Testing):</Text>
            <View style={s.hintBtns}>
              {/* {/* <TouchableOpacity style={s.hintBtn} onPress={fillCustomer}>
                <Text style={s.hintBtnTxt}>👤 Customer</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.hintBtn} onPress={fillTechnician}>
                <Text style={s.hintBtnTxt}>🔧 Technician</Text>
              </TouchableOpacity> */}
              {/* <TouchableOpacity style={s.hintBtn} onPress={fillAdmin}>
                <Text style={s.hintBtnTxt}>⚙️ Admin</Text>
              </TouchableOpacity>  */}
            </View>
            <Text style={s.hintNote}>Tap to auto-fill credentials</Text>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:       { flex: 1, backgroundColor: Colors.bg },
  scroll:     { flexGrow: 1, paddingHorizontal: 24, paddingVertical: 20 },
  backBtn:    { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border, marginBottom: 24 },
  heading:    { fontSize: FontSize.xxxl, fontWeight: FontWeight.extrabold, color: Colors.text, marginBottom: 4 },
  sub:        { fontSize: FontSize.md, color: Colors.textMuted, marginBottom: 24 },
  forgotBtn:  { alignSelf: 'flex-end', marginBottom: 20, marginTop: 4 },
  forgotTxt:  { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.medium },
  loginBtn:   { backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 15, alignItems: 'center', shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  loginBtnTxt:{ fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.white },
  divider:    { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 16 },
  line:       { flex: 1, height: 1, backgroundColor: Colors.border },
  orText:     { fontSize: FontSize.sm, color: Colors.textMuted },
  outlineBtn: { borderRadius: 14, paddingVertical: 15, alignItems: 'center', borderWidth: 1.5, borderColor: Colors.border },
  outlineBtnTxt:{ fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.text },
  hint:       { marginTop: 24, backgroundColor: Colors.surface2, borderRadius: Radius.md, padding: Spacing.lg },
  hintTitle:  { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.semibold, marginBottom: 10 },
  hintBtns:   { flexDirection: 'row', gap: 8, marginBottom: 8 },
  hintBtn:    { flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.sm, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  hintBtnTxt: { fontSize: FontSize.xs, color: Colors.primary, fontWeight: FontWeight.semibold },
  hintNote:   { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },
});
