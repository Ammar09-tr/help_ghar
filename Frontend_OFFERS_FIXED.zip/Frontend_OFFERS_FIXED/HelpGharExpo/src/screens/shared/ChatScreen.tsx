import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  TouchableOpacity, KeyboardAvoidingView, Platform,
  ActivityIndicator, Alert, Linking
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { chatApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { useSocket } from '../../hooks/useSocket';
import { Message } from '../../types';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function ChatScreen({ navigation, route }: any) {
  const { bookingId, otherName, otherPhone } = route.params || {};
  const user = useAuthStore(s => s.user);
  const { connect, joinBookingRoom, leaveBookingRoom, on, sendTyping, isConnected } = useSocket();

  const [messages, setMessages]     = useState<Message[]>([]);
  const [input, setInput]           = useState('');
  const [loading, setLoading]       = useState(true);
  const [sending, setSending]       = useState(false);
  const [isTyping, setIsTyping]     = useState(false);
  const [connected, setConnected]   = useState(false);
  const listRef   = useRef<FlatList>(null);
  const typingTimer = useRef<any>(null);

  // No booking — show empty state
  if (!bookingId) {
    return (
      <SafeAreaView style={s.safe}>
        <View style={s.header}>
          <Text style={s.headerTitle}>Messages</Text>
        </View>
        <View style={s.emptyCenter}>
          <Text style={{ fontSize: 52 }}>💬</Text>
          <Text style={s.emptyTitle}>No conversation open</Text>
          <Text style={s.emptySub}>
            Kisi booking se chat open karo.{'\n'}
            Booking → Chat button tap karo.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  useFocusEffect(useCallback(() => {
    // Make sure socket is connected
    connect();

    // Small delay to let socket connect
    const timer = setTimeout(() => {
      joinBookingRoom(bookingId);
      setConnected(isConnected());
    }, 500);

    loadMessages();

    const u1 = on('chat:message', (msg: any) => {
      console.log('📨 New message received:', msg?.content);
      setMessages(prev => {
        const exists = prev.find(m => m._id === msg._id);
        if (exists) return prev;
        return [...prev, msg];
      });
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 150);
    });

    const u2 = on('chat:typing', (data: { userId: string; isTyping: boolean }) => {
      if (data.userId !== user?._id) {
        setIsTyping(data.isTyping);
        if (data.isTyping) {
          setTimeout(() => setIsTyping(false), 3000);
        }
      }
    });

    const u3 = on('connect', () => {
      setConnected(true);
      joinBookingRoom(bookingId);
    });

    return () => {
      clearTimeout(timer);
      leaveBookingRoom(bookingId);
      u1?.();
      u2?.();
      u3?.();
    };
  }, [bookingId]));

  const loadMessages = async () => {
    try {
      console.log('📋 Loading messages for booking:', bookingId);
      const r = await chatApi.getMessages(bookingId);
      console.log('📋 Messages loaded:', r.data.length);
      setMessages(r.data);
      setTimeout(() => listRef.current?.scrollToEnd({ animated: false }), 200);
    } catch (err: any) {
      console.log('❌ Load messages error:', err?.response?.data);
      Alert.alert('Error', 'Could not load messages. Make sure you are part of this booking.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (text: string) => {
    setInput(text);
    sendTyping(bookingId, true);
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => sendTyping(bookingId, false), 1500);
  };

  const sendMessage = async () => {
    const content = input.trim();
    if (!content || sending) return;
    setInput('');
    setSending(true);
    sendTyping(bookingId, false);
    try {
      console.log('📤 Sending message:', content);
      const r = await chatApi.sendMessage(bookingId, content);
      console.log('✅ Message sent:', r.data._id);
      setMessages(prev => {
        if (prev.find(m => m._id === r.data._id)) return prev;
        return [...prev, r.data];
      });
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 150);
    } catch (err: any) {
      console.log('❌ Send error:', err?.response?.data);
      setInput(content);
      Alert.alert('Error', err?.response?.data?.message || 'Could not send message');
    } finally {
      setSending(false); }
  };

  const formatTime = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleTimeString('en-PK', {
        hour: '2-digit', minute: '2-digit'
      });
    } catch { return ''; }
  };

  const renderMessage = ({ item, index }: { item: Message; index: number }) => {
    const sender = item.sender as any;
    const isMe = sender?._id === user?._id || sender === user?._id;

    // Date separator
    const showDate = index === 0 || (() => {
      try {
        const prev = messages[index - 1];
        const prevDate = new Date(prev.createdAt).toDateString();
        const thisDate = new Date(item.createdAt).toDateString();
        return prevDate !== thisDate;
      } catch { return false; }
    })();

    return (
      <View>
        {showDate && (
          <View style={s.dateSep}>
            <View style={s.dateLine} />
            <Text style={s.dateText}>
              {(() => {
                try {
                  const d = new Date(item.createdAt);
                  const today = new Date();
                  const yesterday = new Date(today);
                  yesterday.setDate(yesterday.getDate() - 1);
                  if (d.toDateString() === today.toDateString()) return 'Today';
                  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
                  return d.toLocaleDateString('en-PK', { day: 'numeric', month: 'short' });
                } catch { return ''; }
              })()}
            </Text>
            <View style={s.dateLine} />
          </View>
        )}

        <View style={[s.msgRow, isMe && { flexDirection: 'row-reverse' }]}>
          {!isMe && (
            <View style={s.msgAvatar}>
              <Text style={{ fontSize: 14 }}>
                {user?.role === 'customer' ? '🔧' : '👤'}
              </Text>
            </View>
          )}
          <View style={[s.bubble, isMe ? s.bubbleMe : s.bubbleThem]}>
            <Text style={[s.bubbleTxt, isMe && { color: Colors.white }]}>
              {item.content}
            </Text>
            <Text style={[s.bubbleTime, isMe && { color: 'rgba(255,255,255,0.7)', textAlign: 'right' }]}>
              {formatTime(item.createdAt)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={s.safe}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Text style={{ fontSize: 18, color: Colors.text }}>←</Text>
        </TouchableOpacity>

        <View style={s.headerAvatar}>
          <Text style={{ fontSize: 20 }}>
            {user?.role === 'customer' ? '🔧' : '👤'}
          </Text>
        </View>

        <View style={{ flex: 1 }}>
          <Text style={s.headerName}>{otherName || 'Chat'}</Text>
          <Text style={[s.headerStatus, { color: isTyping ? Colors.warning : connected ? Colors.success : Colors.textMuted }]}>
            {isTyping ? 'typing...' : connected ? '● Online' : '○ Connecting...'}
          </Text>
        </View>

        {/* Call button */}
        {otherPhone && (
          <TouchableOpacity
            style={s.callBtn}
            onPress={() => Linking.openURL(`tel:${otherPhone}`)}
          >
            <Text style={{ fontSize: 18 }}>📞</Text>
          </TouchableOpacity>
        )}
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
      >
        {loading ? (
          <View style={s.center}>
            <ActivityIndicator color={Colors.primary} size="large" />
            <Text style={{ color: Colors.textMuted, marginTop: 12 }}>Loading messages...</Text>
          </View>
        ) : (
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={m => m._id}
            contentContainerStyle={[
              { padding: Spacing.lg, gap: 4 },
              messages.length === 0 && { flex: 1 }
            ]}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => {
              if (messages.length > 0) {
                listRef.current?.scrollToEnd({ animated: true });
              }
            }}
            ListEmptyComponent={
              <View style={s.emptyCenter}>
                <Text style={{ fontSize: 40 }}>💬</Text>
                <Text style={s.emptyTitle}>No messages yet</Text>
                <Text style={s.emptySub}>Start the conversation!</Text>
              </View>
            }
            renderItem={renderMessage}
          />
        )}

        {/* Typing indicator */}
        {isTyping && (
          <View style={s.typingBox}>
            <Text style={s.typingText}>
              {otherName || 'Other person'} is typing...
            </Text>
          </View>
        )}

        {/* Input Bar */}
        <View style={s.inputBar}>
          <TextInput
            style={s.chatInput}
            value={input}
            onChangeText={handleInputChange}
            placeholder="Type a message..."
            placeholderTextColor={Colors.textMuted}
            multiline
            maxLength={500}
            returnKeyType="send"
            onSubmitEditing={sendMessage}
          />
          <TouchableOpacity
            style={[
              s.sendBtn,
              (!input.trim() || sending) && { backgroundColor: Colors.surface3, elevation: 0 }
            ]}
            onPress={sendMessage}
            disabled={!input.trim() || sending}
          >
            {sending
              ? <ActivityIndicator color={Colors.white} size="small" />
              : <Text style={{ fontSize: 18, color: Colors.white }}>➤</Text>
            }
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:         { flex: 1, backgroundColor: Colors.bg },
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header:       { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.surface },
  backBtn:      { width: 34, height: 34, borderRadius: 17, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center' },
  headerAvatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  headerTitle:  { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  headerName:   { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  headerStatus: { fontSize: FontSize.xs, marginTop: 1 },
  callBtn:      { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
  emptyCenter:  { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xxl },
  emptyTitle:   { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginTop: 12, textAlign: 'center' },
  emptySub:     { fontSize: FontSize.md, color: Colors.textMuted, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  dateSep:      { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 14 },
  dateLine:     { flex: 1, height: 1, backgroundColor: Colors.border },
  dateText:     { fontSize: FontSize.xs, color: Colors.textMuted, backgroundColor: Colors.surface2, paddingHorizontal: 10, paddingVertical: 3, borderRadius: Radius.full },
  msgRow:       { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 4 },
  msgAvatar:    { width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  bubble:       { maxWidth: '75%', borderRadius: 18, paddingVertical: 10, paddingHorizontal: 14 },
  bubbleMe:     { backgroundColor: Colors.primary, borderBottomRightRadius: 4 },
  bubbleThem:   { backgroundColor: Colors.surface2, borderBottomLeftRadius: 4 },
  bubbleTxt:    { fontSize: FontSize.md, color: Colors.text, lineHeight: 20 },
  bubbleTime:   { fontSize: 10, color: Colors.textMuted, marginTop: 4 },
  typingBox:    { paddingHorizontal: Spacing.xl, paddingVertical: 6 },
  typingText:   { fontSize: FontSize.xs, color: Colors.textMuted, fontStyle: 'italic' },
  inputBar:     { flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.surface, borderTopWidth: 1, borderTopColor: Colors.border },
  chatInput:    { flex: 1, backgroundColor: Colors.surface2, borderRadius: 22, paddingHorizontal: Spacing.lg, paddingVertical: 10, color: Colors.text, fontSize: FontSize.md, maxHeight: 120, borderWidth: 1.5, borderColor: Colors.border },
  sendBtn:      { width: 46, height: 46, borderRadius: 23, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', shadowColor: Colors.primary, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 6, elevation: 4 },
});
