import React, { useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useSocket } from '../../hooks/useSocket';
import { useNotificationStore } from '../../store/notificationStore';
import { Notification } from '../../types';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const TYPE_CONFIG: Record<string, { icon:string; color:string }> = {
  booking:    { icon:'📋', color:Colors.primary },
  chat:       { icon:'💬', color:Colors.info },
  commission: { icon:'💰', color:Colors.warning },
  payment:    { icon:'✅', color:Colors.success },
  system:     { icon:'🔔', color:Colors.textMuted },
};

const EVENT_MAP: Record<string, { title:string; type:Notification['type'] }> = {
  'booking:accepted':         { title:'Booking Accepted ✅',      type:'booking' },
  'booking:rejected_by_tech': { title:'Technician Declined ❌',   type:'booking' },
  'booking:price_set':        { title:'Price Set 💰',             type:'booking' },
  'booking:started':          { title:'Job Started 🔧',           type:'booking' },
  'booking:completed':        { title:'Job Completed 🎉',         type:'booking' },
  'booking:cancelled':        { title:'Booking Cancelled ❌',     type:'booking' },
  'booking:new_request':      { title:'New Job Request 📥',       type:'booking' },
  'commission:due':           { title:'Commission Due 🔒',        type:'commission' },
  'commission:paid':          { title:'Commission Paid 🔓',       type:'commission' },
  'account:approved':         { title:'Account Approved 🎉',      type:'system' },
  'account:rejected':         { title:'Application Rejected ❌',  type:'system' },
};

export default function NotificationsScreen({ navigation }: any) {
  const { on } = useSocket();
  const { notifications, unreadCount, addLocalNotification, markRead, markAllRead, clearAll, loadFromStorage } = useNotificationStore();

  useEffect(() => {
    loadFromStorage();
    const unsubs = Object.entries(EVENT_MAP).map(([event, config]) =>
      on(event, (data: any) => {
        addLocalNotification(config.title, data?.message || config.title, config.type, data);
      })
    );
    return () => { unsubs.forEach(u => u?.()); };
  }, []);

  const timeAgo = (d: string) => {
    try {
      const diff = Date.now() - new Date(d).getTime();
      if (diff < 60000) return 'Just now';
      if (diff < 3600000) return `${Math.floor(diff/60000)}m ago`;
      if (diff < 86400000) return `${Math.floor(diff/3600000)}h ago`;
      return `${Math.floor(diff/86400000)}d ago`;
    } catch { return ''; }
  };

  const handlePress = (n: Notification) => {
    markRead(n._id);
    if (n.data?.bookingId) {
      if (n.type === 'chat') navigation.navigate('Chat', { bookingId: n.data.bookingId });
      else navigation.navigate('BookingDetail', { bookingId: n.data.bookingId });
    } else if (n.type === 'commission') {
      navigation.navigate('Commission');
    }
  };

  return (
    <SafeAreaView style={s.safe}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Text style={{ fontSize:18, color:Colors.text }}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Notifications</Text>
        <View style={{ flexDirection:'row', gap:8 }}>
          {unreadCount > 0 && (
            <TouchableOpacity onPress={markAllRead}>
              <Text style={s.actionTxt}>Mark all read</Text>
            </TouchableOpacity>
          )}
          {notifications.length > 0 && (
            <TouchableOpacity onPress={() => Alert.alert('Clear All','Delete all notifications?',[{text:'Cancel'},{text:'Clear',style:'destructive',onPress:clearAll}])}>
              <Text style={[s.actionTxt, { color:Colors.danger }]}>Clear</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Unread badge */}
      {unreadCount > 0 && (
        <View style={s.unreadBanner}>
          <Text style={s.unreadTxt}>{unreadCount} unread notification{unreadCount > 1 ? 's' : ''}</Text>
        </View>
      )}

      <FlatList
        data={notifications}
        keyExtractor={n => n._id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom:40, flexGrow:1 }}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={{ fontSize:52, marginBottom:12 }}>🔔</Text>
            <Text style={s.emptyTitle}>No notifications yet</Text>
            <Text style={s.emptySub}>Real-time alerts will appear here when you receive bookings, messages, and updates.</Text>
          </View>
        }
        renderItem={({ item }) => {
          const cfg = TYPE_CONFIG[item.type] || TYPE_CONFIG.system;
          return (
            <TouchableOpacity
              style={[s.item, !item.isRead && s.itemUnread]}
              onPress={() => handlePress(item)}
              activeOpacity={0.8}
            >
              <View style={[s.iconBox, { backgroundColor: cfg.color + '20' }]}>
                <Text style={{ fontSize:22 }}>{cfg.icon}</Text>
              </View>
              <View style={{ flex:1 }}>
                <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
                  <Text style={[s.itemTitle, !item.isRead && { color:Colors.text }]} numberOfLines={1}>
                    {item.title}
                  </Text>
                  {!item.isRead && <View style={[s.dot, { backgroundColor:cfg.color }]}/>}
                </View>
                <Text style={s.itemMsg} numberOfLines={2}>{item.message}</Text>
                <Text style={s.itemTime}>{timeAgo(item.createdAt)}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:        { flex:1, backgroundColor:Colors.bg },
  header:      { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal:Spacing.xl, paddingVertical:Spacing.md, borderBottomWidth:1, borderBottomColor:Colors.border },
  backBtn:     { width:36, height:36, borderRadius:18, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:Colors.border },
  title:       { fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text },
  actionTxt:   { fontSize:FontSize.sm, color:Colors.primary, fontWeight:FontWeight.medium },
  unreadBanner:{ backgroundColor:Colors.primaryBg, paddingVertical:8, paddingHorizontal:Spacing.xl },
  unreadTxt:   { fontSize:FontSize.sm, color:Colors.primary, fontWeight:FontWeight.medium },
  item:        { flexDirection:'row', gap:12, alignItems:'flex-start', padding:Spacing.lg, borderBottomWidth:1, borderBottomColor:Colors.border },
  itemUnread:  { backgroundColor:Colors.surface, borderLeftWidth:3, borderLeftColor:Colors.primary },
  iconBox:     { width:44, height:44, borderRadius:Radius.md, alignItems:'center', justifyContent:'center', flexShrink:0 },
  dot:         { width:8, height:8, borderRadius:4 },
  itemTitle:   { fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.textMuted, flex:1 },
  itemMsg:     { fontSize:FontSize.sm, color:Colors.textMuted, marginTop:3, lineHeight:18 },
  itemTime:    { fontSize:FontSize.xs, color:Colors.textMuted, marginTop:4 },
  empty:       { flex:1, alignItems:'center', justifyContent:'center', padding:Spacing.xxl, marginTop:60 },
  emptyTitle:  { fontSize:FontSize.xl, fontWeight:FontWeight.bold, color:Colors.text, textAlign:'center' },
  emptySub:    { fontSize:FontSize.md, color:Colors.textMuted, textAlign:'center', marginTop:8, lineHeight:22 },
});
