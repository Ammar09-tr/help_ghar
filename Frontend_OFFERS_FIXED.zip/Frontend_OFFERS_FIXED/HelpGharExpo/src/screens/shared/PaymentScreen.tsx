import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput, ActivityIndicator, Linking
} from 'react-native';
import { commissionApi } from '../../api/services';
import { Button, Card, ScreenWrapper, Divider } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const PAYMENT_METHODS = [
  {
    key: 'jazzcash',
    label: 'JazzCash',
    icon: '📱',
    color: '#E8180C',
    bg: '#fef2f2',
    number: '0300-1234567',
    instructions: '1. Open JazzCash app\n2. Go to "Send Money"\n3. Enter number: 0300-1234567\n4. Enter amount\n5. Complete payment\n6. Copy transaction ID',
  },
  {
    key: 'easypaisa',
    label: 'EasyPaisa',
    icon: '💚',
    color: '#22C55E',
    bg: '#f0fdf4',
    number: '0311-1234567',
    instructions: '1. Open EasyPaisa app\n2. Tap "Send Money"\n3. Enter number: 0311-1234567\n4. Enter amount\n5. Confirm payment\n6. Copy transaction ID',
  },
  {
    key: 'bank_transfer',
    label: 'Bank Transfer',
    icon: '🏦',
    color: Colors.info,
    bg: Colors.infoBg,
    number: 'HBL: 0123-4567890-01',
    instructions: '1. Open your banking app\n2. Go to "Fund Transfer"\n3. Account: 01234567890\n4. Bank: HBL\n5. Enter amount\n6. Copy transaction reference',
  },
  {
    key: 'cash',
    label: 'Cash to Agent',
    icon: '💵',
    color: Colors.warning,
    bg: Colors.warningBg,
    number: 'Visit any HelpGhar office',
    instructions: '1. Visit our office\n2. Show your booking ID\n3. Pay cash\n4. Get receipt\n5. Enter receipt number below',
  },
];

interface PaymentScreenProps {
  navigation: any;
  route: any;
}

export default function PaymentScreen({ navigation, route }: PaymentScreenProps) {
  const { amount, type, commissionId, bookingId } = route.params;
  // type: 'commission' | 'booking'

  const [method, setMethod]           = useState('jazzcash');
  const [txnId, setTxnId]             = useState('');
  const [paying, setPaying]           = useState(false);
  const [step, setStep]               = useState<'select' | 'instructions' | 'verify'>('select');

  const selectedMethod = PAYMENT_METHODS.find(m => m.key === method);

  const handleProceed = () => { setStep('instructions'); };

  const handleSubmitPayment = async () => {
    if (!txnId.trim()) {
      Alert.alert('Required', 'Please enter the transaction ID from your payment');
      return;
    }
    if (txnId.trim().length < 6) {
      Alert.alert('Invalid', 'Transaction ID must be at least 6 characters');
      return;
    }
    setPaying(true);
    try {
      if (type === 'commission') {
        await commissionApi.pay(method, txnId.trim());
        Alert.alert(
          'Payment Submitted! ✅',
          'Your payment has been submitted for verification.\n\nAdmin will verify and unlock your account within 1-2 hours.',
          [{ text: 'OK', onPress: () => navigation.goBack() }]
        );
      } else {
        // Customer paying for job
        Alert.alert(
          'Payment Recorded ✅',
          'Your payment has been recorded. Thank you!',
          [{ text: 'OK', onPress: () => navigation.goBack() }]
        );
      }
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.message || 'Payment failed. Please try again.');
    } finally { setPaying(false); }
  };

  const openPaymentApp = () => {
    const urls: Record<string,string> = {
      jazzcash:  'jazzcash://',
      easypaisa: 'easypaisa://',
    };
    const url = urls[method];
    if (url) {
      Linking.canOpenURL(url).then(can => {
        if (can) Linking.openURL(url);
        else Alert.alert('App not found', `Please install ${selectedMethod?.label} app`);
      });
    }
  };

  return (
    <ScreenWrapper title="Payment" showBack>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:40}}>

        {/* Amount card */}
        <View style={s.amountCard}>
          <Text style={s.amountLabel}>{type === 'commission' ? 'Commission Due' : 'Amount to Pay'}</Text>
          <Text style={s.amountValue}>₨ {Number(amount).toLocaleString()}</Text>
          {type === 'commission' && (
            <Text style={s.amountSub}>Pay this to unlock your account and receive new jobs</Text>
          )}
        </View>

        {/* Step 1: Select method */}
        {step === 'select' && (
          <>
            <Text style={s.sectionTitle}>Select Payment Method</Text>
            {PAYMENT_METHODS.map(m => (
              <TouchableOpacity
                key={m.key}
                style={[s.methodCard, method === m.key && {borderColor: m.color, borderWidth:2}]}
                onPress={() => setMethod(m.key)}
                activeOpacity={0.8}
              >
                <View style={[s.methodIcon, {backgroundColor: m.bg}]}>
                  <Text style={{fontSize:24}}>{m.icon}</Text>
                </View>
                <View style={{flex:1}}>
                  <Text style={s.methodLabel}>{m.label}</Text>
                  <Text style={s.methodNumber}>{m.number}</Text>
                </View>
                <View style={[s.radioOuter, method === m.key && {borderColor:m.color}]}>
                  {method === m.key && (
                    <View style={[s.radioInner, {backgroundColor:m.color}]}/>
                  )}
                </View>
              </TouchableOpacity>
            ))}
            <Button title={`Proceed with ${selectedMethod?.label} →`} onPress={handleProceed} style={{marginTop:8}}/>
          </>
        )}

        {/* Step 2: Instructions */}
        {step === 'instructions' && selectedMethod && (
          <>
            <View style={[s.instructBox, {backgroundColor:selectedMethod.bg, borderColor:selectedMethod.color+'40'}]}>
              <Text style={[s.instructTitle, {color:selectedMethod.color}]}>
                {selectedMethod.icon} Pay via {selectedMethod.label}
              </Text>
              <Text style={[s.instructAmt, {color:selectedMethod.color}]}>
                Amount: ₨ {Number(amount).toLocaleString()}
              </Text>
              <Divider style={{borderColor:selectedMethod.color+'20'}}/>
              <Text style={[s.instructSteps, {color:selectedMethod.color}]}>
                {selectedMethod.instructions}
              </Text>
            </View>

            {/* Open app button */}
            {['jazzcash','easypaisa'].includes(method) && (
              <Button
                title={`Open ${selectedMethod.label} App 📱`}
                onPress={openPaymentApp}
                variant="outline"
                style={{marginBottom:Spacing.lg}}
              />
            )}

            {/* Enter transaction ID */}
            <Text style={s.label}>Transaction ID / Reference *</Text>
            <TextInput
              style={s.txnInput}
              value={txnId}
              onChangeText={setTxnId}
              placeholder="Enter transaction ID from your payment..."
              placeholderTextColor={Colors.textMuted}
              autoCapitalize="characters"
            />
            <Text style={s.txnHint}>
              💡 Find transaction ID in your payment app under "Transaction History" or "Receipt"
            </Text>

            <Button
              title={paying ? 'Submitting...' : '✅ Submit Payment'}
              onPress={handleSubmitPayment}
              loading={paying}
              disabled={!txnId.trim()}
              style={{marginTop:8}}
            />
            <Button
              title="← Change Payment Method"
              onPress={() => setStep('select')}
              variant="ghost"
              style={{marginTop:8}}
            />
          </>
        )}

        {/* Info box */}
        <View style={s.infoBox}>
          <Text style={{fontSize:14}}>ℹ️</Text>
          <Text style={{flex:1, fontSize:FontSize.sm, color:Colors.info, lineHeight:18}}>
            After submitting, admin verifies your payment within 1-2 hours. Your account will be unlocked automatically.
          </Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  amountCard:    {backgroundColor:Colors.primaryBg, borderRadius:Radius.xl, borderWidth:1, borderColor:'rgba(255,92,26,0.3)', padding:Spacing.xxl, alignItems:'center', marginBottom:Spacing.xl, gap:6},
  amountLabel:   {fontSize:FontSize.sm, color:Colors.primary, fontWeight:FontWeight.medium},
  amountValue:   {fontSize:40, fontWeight:FontWeight.extrabold, color:Colors.primary},
  amountSub:     {fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center'},
  sectionTitle:  {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:12},
  methodCard:    {flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, marginBottom:10},
  methodIcon:    {width:48, height:48, borderRadius:Radius.md, alignItems:'center', justifyContent:'center'},
  methodLabel:   {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text},
  methodNumber:  {fontSize:FontSize.sm, color:Colors.textMuted, marginTop:2},
  radioOuter:    {width:22, height:22, borderRadius:11, borderWidth:2, borderColor:Colors.border, alignItems:'center', justifyContent:'center'},
  radioInner:    {width:12, height:12, borderRadius:6},
  instructBox:   {borderRadius:Radius.xl, borderWidth:1, padding:Spacing.xl, marginBottom:Spacing.lg},
  instructTitle: {fontSize:FontSize.lg, fontWeight:FontWeight.extrabold, marginBottom:4},
  instructAmt:   {fontSize:FontSize.xl, fontWeight:FontWeight.extrabold, marginBottom:12},
  instructSteps: {fontSize:FontSize.sm, lineHeight:24},
  label:         {fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:8, textTransform:'uppercase', letterSpacing:0.5},
  txnInput:      {backgroundColor:Colors.surface2, borderRadius:Radius.md, borderWidth:1.5, borderColor:Colors.border, padding:13, color:Colors.text, fontSize:FontSize.md, marginBottom:6},
  txnHint:       {fontSize:FontSize.xs, color:Colors.textMuted, lineHeight:16, marginBottom:Spacing.lg},
  infoBox:       {flexDirection:'row', gap:10, backgroundColor:Colors.infoBg, borderRadius:Radius.md, borderWidth:1, borderColor:'rgba(59,130,246,0.2)', padding:Spacing.md, marginTop:Spacing.lg, alignItems:'flex-start'},
});
