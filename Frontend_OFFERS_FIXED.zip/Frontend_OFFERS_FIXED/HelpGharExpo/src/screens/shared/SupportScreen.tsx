import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Alert, ActivityIndicator, Linking
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthStore } from '../../store/authStore';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const FAQS = [
  {
    q: 'Booking kaise karte hain?',
    a: 'Home screen par service select karo → problem describe karo → location confirm karo → "Find Technicians" tap karo.',
  },
  {
    q: 'Technician nahi aa raha?',
    a: 'Booking track karo aur technician se chat mein contact karo. Agar 30 min ho jayein to booking cancel karke dobara try karo.',
  },
  {
    q: 'Payment kaise hoti hai?',
    a: 'Job complete hone ke baad customer directly technician ko cash ya JazzCash se pay karta hai. Platform 10% commission leta hai.',
  },
  {
    q: 'Technician account approve nahi hua?',
    a: 'Admin 24-48 hours mein review karta hai. Email check karo ya support se contact karo.',
  },
  {
    q: 'Commission kaise pay karein?',
    a: 'Job complete hone ke baad Profile → Commission → Payment method select karo → Pay karo.',
  },
  {
    q: 'App crash ho rahi hai?',
    a: 'App force close karo aur dobara open karo. Agar masla rahe to support se contact karo.',
  },
  {
    q: 'Password bhool gaya?',
    a: 'Login screen par "Forgot Password?" tap karo aur apna email enter karo.',
  },
  {
    q: 'Booking cancel kaise karein?',
    a: 'Booking Detail screen open karo → "Cancel Booking" button tap karo. Sirf Pending ya Accepted bookings cancel ho sakti hain.',
  },
];

export default function SupportScreen({ navigation }: any) {
  const user = useAuthStore(s => s.user);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [subject, setSubject]         = useState('');
  const [message, setMessage]         = useState('');
  const [sending, setSending]         = useState(false);
  const [tab, setTab]                 = useState<'faq' | 'contact'>('faq');

  const handleSendTicket = async () => {
    if (!subject.trim()) { Alert.alert('Error', 'Subject enter karo'); return; }
    if (!message.trim()) { Alert.alert('Error', 'Message enter karo'); return; }
    setSending(true);
    try {
      await new Promise(r => setTimeout(r, 1000));
      Alert.alert(
        'Ticket Submitted ✅',
        'Aapka support ticket submit ho gaya. Hum 24 hours mein respond karenge.',
        [{
          text: 'OK',
          onPress: () => { setSubject(''); setMessage(''); }
        }]
      );
    } finally { setSending(false); }
  };

  return (
    <SafeAreaView style={s.safe}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Text style={{ fontSize: 18, color: Colors.text }}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>Help & Support</Text>
        <View style={{ width: 36 }} />
      </View>

      {/* Tabs */}
      <View style={s.tabRow}>
        <TouchableOpacity
          style={[s.tabBtn, tab === 'faq' && s.tabBtnActive]}
          onPress={() => setTab('faq')}
        >
          <Text style={[s.tabTxt, tab === 'faq' && { color: Colors.primary }]}>
            ❓ FAQs
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[s.tabBtn, tab === 'contact' && s.tabBtnActive]}
          onPress={() => setTab('contact')}
        >
          <Text style={[s.tabTxt, tab === 'contact' && { color: Colors.primary }]}>
            📩 Contact Us
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        {/* ── FAQ Tab ── */}
        {tab === 'faq' && (
          <View>
            <Text style={s.sectionTitle}>Frequently Asked Questions</Text>
            {FAQS.map((faq, i) => (
              <TouchableOpacity
                key={i}
                style={s.faqItem}
                onPress={() => setExpandedFaq(expandedFaq === i ? null : i)}
                activeOpacity={0.8}
              >
                <View style={s.faqHeader}>
                  <Text style={s.faqQ} numberOfLines={expandedFaq === i ? undefined : 1}>
                    {faq.q}
                  </Text>
                  <Text style={[s.faqArrow, expandedFaq === i && { color: Colors.primary }]}>
                    {expandedFaq === i ? '▲' : '▼'}
                  </Text>
                </View>
                {expandedFaq === i && (
                  <Text style={s.faqA}>{faq.a}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* ── Contact Tab ── */}
        {tab === 'contact' && (
          <View>
            {/* Quick Contact */}
            <Text style={s.sectionTitle}>Quick Contact</Text>
            <View style={s.quickRow}>
              <TouchableOpacity
                style={s.quickBtn}
                onPress={() => Linking.openURL('tel:+923001234567')}
              >
                <Text style={{ fontSize: 28 }}>📞</Text>
                <Text style={s.quickLabel}>Call Us</Text>
                <Text style={s.quickSub}>+92 300 1234567</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={s.quickBtn}
                onPress={() => Linking.openURL('mailto:support@helpghar.com')}
              >
                <Text style={{ fontSize: 28 }}>📧</Text>
                <Text style={s.quickLabel}>Email Us</Text>
                <Text style={s.quickSub}>support@helpghar.com</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={s.quickBtn}
                onPress={() => Linking.openURL('https://wa.me/923001234567')}
              >
                <Text style={{ fontSize: 28 }}>💬</Text>
                <Text style={s.quickLabel}>WhatsApp</Text>
                <Text style={s.quickSub}>Chat with us</Text>
              </TouchableOpacity>
            </View>

            {/* Support Hours */}
            <View style={s.hoursBox}>
              <Text style={s.hoursTitle}>🕐 Support Hours</Text>
              <Text style={s.hoursText}>Monday - Saturday: 9 AM - 9 PM</Text>
              <Text style={s.hoursText}>Sunday: 10 AM - 6 PM</Text>
            </View>

            {/* Submit Ticket */}
            <Text style={s.sectionTitle}>Submit a Ticket</Text>
            <View style={s.ticketForm}>
              {/* User info (auto filled) */}
              <View style={s.userInfo}>
                <Text style={s.userInfoTxt}>
                  👤 {user?.fullName || 'Unknown'} ({user?.role})
                </Text>
                <Text style={s.userInfoTxt}>📧 {user?.email}</Text>
              </View>

              <Text style={s.inputLabel}>Subject *</Text>
              <TextInput
                style={s.input}
                value={subject}
                onChangeText={setSubject}
                placeholder="e.g. Booking issue, Payment problem..."
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={s.inputLabel}>Message *</Text>
              <TextInput
                style={[s.input, s.textarea]}
                value={message}
                onChangeText={setMessage}
                placeholder="Describe your issue in detail..."
                placeholderTextColor={Colors.textMuted}
                multiline
                numberOfLines={5}
                textAlignVertical="top"
              />

              <TouchableOpacity
                style={[s.submitBtn, sending && { opacity: 0.7 }]}
                onPress={handleSendTicket}
                disabled={sending}
              >
                {sending
                  ? <ActivityIndicator color={Colors.white} />
                  : <Text style={s.submitBtnTxt}>Submit Ticket 📩</Text>
                }
              </TouchableOpacity>
            </View>
          </View>
        )}

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:         { flex: 1, backgroundColor: Colors.bg },
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border },
  backBtn:      { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
  headerTitle:  { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  tabRow:       { flexDirection: 'row', gap: 0, backgroundColor: Colors.surface2, margin: Spacing.xl, borderRadius: Radius.md, padding: 4 },
  tabBtn:       { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: Radius.sm },
  tabBtnActive: { backgroundColor: Colors.surface },
  tabTxt:       { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textMuted },
  scroll:       { paddingHorizontal: Spacing.xl, paddingBottom: 40 },
  sectionTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 12, marginTop: 4 },
  faqItem:      { backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.lg, marginBottom: 8 },
  faqHeader:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  faqQ:         { flex: 1, fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.text },
  faqArrow:     { fontSize: FontSize.sm, color: Colors.textMuted },
  faqA:         { fontSize: FontSize.sm, color: Colors.textMuted, lineHeight: 20, marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: Colors.border },
  quickRow:     { flexDirection: 'row', gap: 10, marginBottom: Spacing.xl },
  quickBtn:     { flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, alignItems: 'center', gap: 6 },
  quickLabel:   { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  quickSub:     { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },
  hoursBox:     { backgroundColor: Colors.infoBg, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(59,130,246,0.2)', padding: Spacing.lg, marginBottom: Spacing.xl, gap: 4 },
  hoursTitle:   { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.info, marginBottom: 4 },
  hoursText:    { fontSize: FontSize.sm, color: Colors.info },
  ticketForm:   { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.lg },
  userInfo:     { backgroundColor: Colors.surface2, borderRadius: Radius.md, padding: Spacing.md, marginBottom: Spacing.lg, gap: 4 },
  userInfoTxt:  { fontSize: FontSize.xs, color: Colors.textMuted },
  inputLabel:   { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  input:        { backgroundColor: Colors.surface2, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border, padding: 13, color: Colors.text, fontSize: FontSize.md, marginBottom: 16 },
  textarea:     { height: 120, textAlignVertical: 'top', paddingTop: 12 },
  submitBtn:    { backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 14, alignItems: 'center', shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 6 },
  submitBtnTxt: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.white },
});
