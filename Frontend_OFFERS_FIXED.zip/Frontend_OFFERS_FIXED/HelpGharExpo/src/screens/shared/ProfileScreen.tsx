import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput, Modal, ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { usersApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { Button, Stars } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

export default function ProfileScreen({ navigation }: any) {
  const { user, logout, updateUser } = useAuthStore();
  const [editModal, setEditModal] = useState(false);
  const [form, setForm] = useState({ fullName:user?.fullName||'', phone:user?.phone||'' });
  const [saving, setSaving] = useState(false);

  const handleLogout = () => {
    Alert.alert('Sign Out','Are you sure?',[
      { text:'Cancel' },
      { text:'Sign Out', style:'destructive', onPress: async () => {
        await logout();
        navigation.reset({ index:0, routes:[{ name:'Splash' }] });
      }},
    ]);
  };

  const handleSwitch = async () => {
    await logout();
    navigation.reset({ index:0, routes:[{ name:'Login' }] });
  };

  const confirmSwitch = (role: string) => {
    if (user?.role === role) return;
    Alert.alert(`Switch to ${role}`,'Logout ho kar dusre account mein login karein?',[
      { text:'Cancel' },
      { text:'Switch', onPress: handleSwitch },
    ]);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const r = await usersApi.updateProfile({ fullName:form.fullName.trim(), phone:form.phone.trim() });
      updateUser(r.data as any);
      setEditModal(false);
      Alert.alert('Saved','Profile updated successfully.');
    } catch (err:any) {
      Alert.alert('Error', err?.response?.data?.message||'Could not update profile');
    } finally { setSaving(false); }
  };

  const roleIcon  = user?.role==='customer'?'👤':user?.role==='technician'?'🔧':'⚙️';
  const roleLabel = user?.role==='customer'?'Customer':user?.role==='technician'?'Technician':'Admin';

  const menuItems = [
    { icon:'✏️', label:'Edit Profile',       onPress:()=>setEditModal(true) },
    ...(user?.role==='technician' ? [{ icon:'🪪', label:'CNIC Verification', onPress:()=>navigation.navigate('CnicUpload') }] : []),
    { icon:'🔔', label:'Notifications',       onPress:()=>navigation.navigate('Notifications') },
    { icon:'❓', label:'Help & Support',      onPress:()=>navigation.navigate('Support') },
    { icon:'🛡️', label:'Privacy & Security', onPress:()=>{} },
  ];

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom:100 }}>

        {/* Hero */}
        <View style={s.hero}>
          <View style={s.heroGlow}/>
          <View style={s.avatarWrap}><Text style={{ fontSize:40 }}>{roleIcon}</Text></View>
          <Text style={s.heroName}>{user?.fullName}</Text>
          <Text style={s.heroRole}>{roleLabel}</Text>
          <Text style={s.heroEmail}>{user?.email}</Text>
          <View style={s.heroStats}>
            <View style={s.heroStat}>
              <Text style={s.heroStatVal}>{user?.totalBookings||0}</Text>
              <Text style={s.heroStatLabel}>Bookings</Text>
            </View>
            <View style={s.heroDiv}/>
            <View style={s.heroStat}>
              <Stars rating={user?.averageRating||0} size={16}/>
              <Text style={s.heroStatLabel}>Rating</Text>
            </View>
            <View style={s.heroDiv}/>
            <View style={s.heroStat}>
              <Text style={s.heroStatVal} numberOfLines={1}>{user?.phone||'-'}</Text>
              <Text style={s.heroStatLabel}>Phone</Text>
            </View>
          </View>
        </View>

        {/* Switch Account */}
        <View style={s.switchBox}>
          <Text style={s.switchTitle}>🔄 Switch Account</Text>
          <Text style={s.switchSub}>Dusre account mein switch karo</Text>
          <View style={s.switchRow}>
            <TouchableOpacity style={[s.switchBtn, user?.role==='customer'&&s.switchBtnCustomer]} onPress={()=>confirmSwitch('customer')} activeOpacity={0.8}>
              <Text style={{ fontSize:22 }}>👤</Text>
              <Text style={[s.switchBtnLabel, user?.role==='customer'&&{ color:Colors.primary }]}>Customer</Text>
              {user?.role==='customer' && <View style={[s.activeDot,{backgroundColor:Colors.primary}]}/>}
            </TouchableOpacity>
            <TouchableOpacity style={[s.switchBtn, user?.role==='technician'&&s.switchBtnTech]} onPress={()=>confirmSwitch('technician')} activeOpacity={0.8}>
              <Text style={{ fontSize:22 }}>🔧</Text>
              <Text style={[s.switchBtnLabel, user?.role==='technician'&&{ color:Colors.info }]}>Technician</Text>
              {user?.role==='technician' && <View style={[s.activeDot,{backgroundColor:Colors.info}]}/>}
            </TouchableOpacity>
            <TouchableOpacity style={[s.switchBtn, user?.role==='admin'&&s.switchBtnAdmin]} onPress={()=>confirmSwitch('admin')} activeOpacity={0.8}>
              <Text style={{ fontSize:22 }}>⚙️</Text>
              <Text style={[s.switchBtnLabel, user?.role==='admin'&&{ color:Colors.warning }]}>Admin</Text>
              {user?.role==='admin' && <View style={[s.activeDot,{backgroundColor:Colors.warning}]}/>}
            </TouchableOpacity>
          </View>
          <View style={s.credBox}>
            <Text style={s.credTitle}>📋 Test Credentials:</Text>
            <Text style={s.credText}>👤  ali@example.com  /  Password@123</Text>
            <Text style={s.credText}>🔧  imran@example.com  /  Password@123</Text>
            <Text style={s.credText}>⚙️  admin@helpghar.com  /  Password@123</Text>
          </View>
        </View>

        {/* Menu */}
        <View style={{ paddingHorizontal:Spacing.xl }}>
          {menuItems.map((item,i)=>(
            <TouchableOpacity key={i} style={s.menuItem} onPress={item.onPress} activeOpacity={0.7}>
              <Text style={{ fontSize:20, width:30 }}>{item.icon}</Text>
              <Text style={s.menuLabel}>{item.label}</Text>
              <Text style={{ fontSize:20, color:Colors.textMuted }}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ paddingHorizontal:Spacing.xl, marginTop:8 }}>
          <Button title="🚪 Sign Out" onPress={handleLogout} variant="outline"/>
        </View>
        <Text style={s.version}>HelpGhar v1.0.0 · Made with ❤️ in Pakistan</Text>
      </ScrollView>

      {/* Edit Modal */}
      <Modal visible={editModal} transparent animationType="slide">
        <View style={s.modalBg}>
          <View style={s.modal}>
            <Text style={s.modalTitle}>Edit Profile</Text>
            <Text style={s.inputLabel}>Full Name</Text>
            <TextInput style={s.modalInput} value={form.fullName} onChangeText={v=>setForm(f=>({...f,fullName:v}))} placeholder="Your name" placeholderTextColor={Colors.textMuted}/>
            <Text style={s.inputLabel}>Phone</Text>
            <TextInput style={s.modalInput} value={form.phone} onChangeText={v=>setForm(f=>({...f,phone:v}))} placeholder="+923001234567" placeholderTextColor={Colors.textMuted} keyboardType="phone-pad"/>
            <View style={{ flexDirection:'row', gap:12, marginTop:8 }}>
              <Button title="Cancel" onPress={()=>setEditModal(false)} variant="outline" size="sm" style={{ flex:1 }}/>
              <Button title="Save" onPress={handleSave} loading={saving} size="sm" style={{ flex:1 }}/>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:          { flex:1, backgroundColor:Colors.bg },
  hero:          { alignItems:'center', padding:Spacing.xxl, paddingTop:Spacing.xxxl, position:'relative', overflow:'hidden' },
  heroGlow:      { position:'absolute', top:-40, width:260, height:260, borderRadius:130, backgroundColor:'rgba(255,92,26,0.08)' },
  avatarWrap:    { width:88, height:88, borderRadius:44, backgroundColor:Colors.primary, alignItems:'center', justifyContent:'center', marginBottom:14, shadowColor:Colors.primary, shadowOffset:{width:0,height:8}, shadowOpacity:0.4, shadowRadius:16, elevation:10 },
  heroName:      { fontSize:FontSize.xxl, fontWeight:FontWeight.extrabold, color:Colors.text },
  heroRole:      { fontSize:FontSize.sm, color:Colors.primary, fontWeight:FontWeight.semibold, marginTop:2 },
  heroEmail:     { fontSize:FontSize.sm, color:Colors.textMuted, marginTop:2 },
  heroStats:     { flexDirection:'row', gap:20, marginTop:20, backgroundColor:Colors.surface, borderRadius:Radius.xl, paddingVertical:14, paddingHorizontal:20, borderWidth:1, borderColor:Colors.border },
  heroStat:      { alignItems:'center', gap:2 },
  heroStatVal:   { fontSize:FontSize.sm, fontWeight:FontWeight.bold, color:Colors.text, maxWidth:90 },
  heroStatLabel: { fontSize:FontSize.xs, color:Colors.textMuted },
  heroDiv:       { width:1, backgroundColor:Colors.border, alignSelf:'stretch' },
  switchBox:     { marginHorizontal:Spacing.xl, marginTop:Spacing.xl, marginBottom:Spacing.lg, backgroundColor:Colors.surface, borderRadius:Radius.xl, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg },
  switchTitle:   { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:2 },
  switchSub:     { fontSize:FontSize.xs, color:Colors.textMuted, marginBottom:14 },
  switchRow:     { flexDirection:'row', gap:8, marginBottom:14 },
  switchBtn:     { flex:1, alignItems:'center', paddingVertical:14, borderRadius:Radius.lg, borderWidth:1.5, borderColor:Colors.border, backgroundColor:Colors.surface2, gap:6, position:'relative' },
  switchBtnCustomer:{ borderColor:Colors.primary, backgroundColor:Colors.primaryBg },
  switchBtnTech: { borderColor:Colors.info, backgroundColor:Colors.infoBg },
  switchBtnAdmin:{ borderColor:Colors.warning, backgroundColor:Colors.warningBg },
  switchBtnLabel:{ fontSize:FontSize.xs, fontWeight:FontWeight.semibold, color:Colors.textMuted },
  activeDot:     { position:'absolute', top:6, right:6, width:8, height:8, borderRadius:4 },
  credBox:       { backgroundColor:Colors.surface2, borderRadius:Radius.md, padding:Spacing.md, gap:4 },
  credTitle:     { fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.semibold, marginBottom:6 },
  credText:      { fontSize:FontSize.xs, color:Colors.textMuted, lineHeight:20 },
  menuItem:      { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, marginBottom:8 },
  menuLabel:     { flex:1, fontSize:FontSize.md, color:Colors.text },
  version:       { fontSize:FontSize.xs, color:Colors.textMuted, textAlign:'center', marginTop:24, paddingBottom:20 },
  modalBg:       { flex:1, backgroundColor:'rgba(0,0,0,0.7)', justifyContent:'flex-end' },
  modal:         { backgroundColor:Colors.surface, borderTopLeftRadius:24, borderTopRightRadius:24, padding:24 },
  modalTitle:    { fontSize:FontSize.xl, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:20 },
  inputLabel:    { fontSize:FontSize.xs, color:Colors.textMuted, fontWeight:FontWeight.medium, marginBottom:6, textTransform:'uppercase', letterSpacing:0.5 },
  modalInput:    { backgroundColor:Colors.surface2, borderRadius:Radius.md, borderWidth:1.5, borderColor:Colors.border, padding:13, color:Colors.text, fontSize:FontSize.md, marginBottom:16 },
});
