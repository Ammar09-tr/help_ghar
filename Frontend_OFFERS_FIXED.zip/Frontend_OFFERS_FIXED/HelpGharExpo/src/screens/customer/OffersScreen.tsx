import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Alert, ActivityIndicator, Linking
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { bookingsApi } from '../../api/services';
import { useSocket } from '../../hooks/useSocket';
import { ScreenWrapper, Card, Button, Stars, Badge } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function OffersScreen({ navigation, route }: any) {
  const { bookingId, serviceType } = route.params;
  const { on, joinBookingRoom, leaveBookingRoom } = useSocket();
  const [offers, setOffers]     = useState<any[]>([]);
  const [booking, setBooking]   = useState<any>(null);
  const [loading, setLoading]   = useState(true);
  const [selecting, setSelecting] = useState<string|null>(null);

  const load = async () => {
    try {
      const [oRes, bRes] = await Promise.all([
        bookingsApi.getOffers(bookingId),
        bookingsApi.getById(bookingId),
      ]);
      setOffers(oRes.data);
      setBooking(bRes.data);
    } catch { } finally { setLoading(false); }
  };

  useFocusEffect(useCallback(() => {
    load();
    joinBookingRoom(bookingId);
    const u1 = on('booking:new_offer', () => load());
    const u2 = on('booking:accepted', () => {
      navigation.replace('TrackBooking', { bookingId });
    });
    return () => { leaveBookingRoom(bookingId); u1?.(); u2?.(); };
  }, [bookingId]));

  const handleSelect = async (offerId: string, techName: string, price: number) => {
    Alert.alert(
      'Select This Technician?',
      `${techName} — PKR ${price.toLocaleString()}\n\nAll other offers will be automatically rejected.`,
      [
        { text: 'Cancel' },
        {
          text: 'Yes, Select', onPress: async () => {
            setSelecting(offerId);
            try {
              await bookingsApi.selectOffer(bookingId, offerId);
              Alert.alert('Technician Selected! 🎉', 'Technician is on the way!', [
                { text: 'Track Booking', onPress: () => navigation.replace('TrackBooking', { bookingId }) },
              ]);
            } catch (err: any) {
              Alert.alert('Error', err?.response?.data?.message || 'Could not select offer');
            } finally { setSelecting(null); }
          }
        },
      ]
    );
  };

  const service = SERVICE_TYPES.find(s => s.key === serviceType);

  return (
    <ScreenWrapper title={`${service?.icon || '🛠️'} Technician Offers`} showBack
      rightElement={
        <View style={s.badge}>
          <Text style={s.badgeTxt}>{offers.length} offer{offers.length !== 1 ? 's' : ''}</Text>
        </View>
      }
    >
      {/* Booking Summary */}
      {booking && (
        <View style={s.summary}>
          <Text style={s.summaryTitle}>📋 Your Request</Text>
          <Text style={s.summaryDesc} numberOfLines={2}>{booking.problemDescription}</Text>
          <Text style={s.summaryAddr}>📍 {booking.customerLocation?.address}</Text>
        </View>
      )}

      {/* Info banner */}
      <View style={s.infoBanner}>
        <Text style={s.infoTxt}>
          💡 InDrive model — Technicians send their prices. You pick the best one!
        </Text>
      </View>

      {loading ? (
        <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
      ) : (
        <FlatList
          data={offers}
          keyExtractor={o => o._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 40 }}
          onRefresh={load} refreshing={false}
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={{ fontSize: 48 }}>⏳</Text>
              <Text style={s.emptyTitle}>Waiting for offers...</Text>
              <Text style={s.emptySub}>
                Nearby technicians are reviewing your request.{'\n'}
                Offers appear here in real-time.
              </Text>
              <View style={s.pulseBox}>
                <Text style={s.pulseTxt}>● Broadcasting to nearby technicians</Text>
              </View>
            </View>
          }
          renderItem={({ item, index }) => {
            const tech = item.technician as any;
            const user = tech?.user || tech;
            const commission = Math.round((item.price * 10) / 100);
            const isSelecting = selecting === item._id;

            return (
              <Card style={[s.offerCard, index === 0 && s.offerCardBest]}>
                {index === 0 && offers.length > 1 && (
                  <View style={s.bestBadge}>
                    <Text style={s.bestBadgeTxt}>💰 Lowest Price</Text>
                  </View>
                )}

                <View style={s.offerHeader}>
                  <View style={s.techAvatar}>
                    <Text style={{ fontSize: 24 }}>👨‍🔧</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.techName}>{user?.fullName || 'Technician'}</Text>
                    <Stars rating={tech?.averageRating || 0}/>
                    <Text style={s.techMeta}>
                      ✅ {tech?.totalJobs || 0} jobs · {tech?.yearsOfExperience || 0}yr exp
                    </Text>
                  </View>
                  <View style={s.priceBox}>
                    <Text style={s.priceVal}>₨ {item.price.toLocaleString()}</Text>
                    <Text style={s.priceSub}>total</Text>
                  </View>
                </View>

                {item.note && (
                  <View style={s.noteBox}>
                    <Text style={s.noteTxt}>💬 "{item.note}"</Text>
                  </View>
                )}

                <View style={s.breakdown}>
                  <Text style={s.breakdownTxt}>Service: ₨ {item.price.toLocaleString()}</Text>
                  <Text style={[s.breakdownTxt, { color: Colors.textMuted }]}>
                    Platform fee (10%): ₨ {commission.toLocaleString()}
                  </Text>
                </View>

                <View style={s.offerActions}>
                  {user?.phone && (
                    <TouchableOpacity
                      style={s.callBtn}
                      onPress={() => Linking.openURL(`tel:${user.phone}`)}>
                      <Text style={{ fontSize: 16 }}>📞</Text>
                    </TouchableOpacity>
                  )}
                  <Button
                    title={isSelecting ? 'Selecting...' : '✓ Select This Technician'}
                    onPress={() => handleSelect(item._id, user?.fullName || 'Technician', item.price)}
                    loading={isSelecting}
                    style={{ flex: 1 }}
                  />
                </View>
              </Card>
            );
          }}
        />
      )}
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  badge:        { backgroundColor: Colors.primaryBg, borderRadius: Radius.full, paddingVertical: 4, paddingHorizontal: 10 },
  badgeTxt:     { fontSize: FontSize.xs, color: Colors.primary, fontWeight: FontWeight.bold },
  summary:      { backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.lg, marginBottom: Spacing.md, borderWidth: 1, borderColor: Colors.border },
  summaryTitle: { fontSize: FontSize.sm, color: Colors.textMuted, marginBottom: 4, fontWeight: FontWeight.semibold },
  summaryDesc:  { fontSize: FontSize.md, color: Colors.text, marginBottom: 4 },
  summaryAddr:  { fontSize: FontSize.sm, color: Colors.textMuted },
  infoBanner:   { backgroundColor: Colors.infoBg, borderRadius: Radius.md, padding: Spacing.md, marginBottom: Spacing.lg, borderWidth: 1, borderColor: 'rgba(59,130,246,0.2)' },
  infoTxt:      { fontSize: FontSize.sm, color: Colors.info, lineHeight: 18 },
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 60 },
  empty:        { alignItems: 'center', paddingVertical: 40, gap: 10 },
  emptyTitle:   { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  emptySub:     { fontSize: FontSize.md, color: Colors.textMuted, textAlign: 'center', lineHeight: 22 },
  pulseBox:     { backgroundColor: Colors.successBg, borderRadius: Radius.full, paddingVertical: 8, paddingHorizontal: 16, marginTop: 8 },
  pulseTxt:     { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.medium },
  offerCard:    { marginBottom: Spacing.md, position: 'relative', overflow: 'hidden' },
  offerCardBest:{ borderColor: Colors.primary, borderWidth: 2 },
  bestBadge:    { position: 'absolute', top: 0, right: 0, backgroundColor: Colors.primary, paddingVertical: 4, paddingHorizontal: 10, borderBottomLeftRadius: Radius.md },
  bestBadgeTxt: { fontSize: FontSize.xs, color: Colors.white, fontWeight: FontWeight.bold },
  offerHeader:  { flexDirection: 'row', gap: 12, alignItems: 'flex-start', marginBottom: 12, marginTop: 4 },
  techAvatar:   { width: 48, height: 48, borderRadius: 24, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center' },
  techName:     { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  techMeta:     { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  priceBox:     { alignItems: 'flex-end' },
  priceVal:     { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.primary },
  priceSub:     { fontSize: FontSize.xs, color: Colors.textMuted },
  noteBox:      { backgroundColor: Colors.surface2, borderRadius: Radius.sm, padding: Spacing.sm, marginBottom: Spacing.sm },
  noteTxt:      { fontSize: FontSize.sm, color: Colors.textMuted, fontStyle: 'italic' },
  breakdown:    { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.md },
  breakdownTxt: { fontSize: FontSize.xs, color: Colors.text },
  offerActions: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  callBtn:      { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
});
