import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, Alert, TextInput, ScrollView
} from 'react-native';
import * as Location from 'expo-location';
import { techniciansApi, bookingsApi } from '../../api/services';
import { Technician } from '../../types';
import { Card, Button, Stars, EmptyState, ScreenWrapper, Badge } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function TechnicianListScreen({ navigation, route }: any) {
  const { serviceType, bookingId } = route.params || {};
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading]         = useState(true);
  const [selectedTech, setSelectedTech] = useState<string | null>(null);
  const [price, setPrice]             = useState('');
  const [offerLoading, setOfferLoading] = useState(false);
  const [filter, setFilter]           = useState<'all'|'online'>('online');

  useEffect(() => { load(); }, []);

  const load = async () => {
    let lng = 74.3587, lat = 31.5204;
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        lng = loc.coords.longitude;
        lat = loc.coords.latitude;
      }
    } catch {}
    try {
      const res = await techniciansApi.getNearby(serviceType, lng, lat, 30);
      setTechnicians(res.data);
    } catch {}
    setLoading(false);
  };

  const handleRequest = async (techId: string) => {
    navigation.navigate('BookService', { preselected: serviceType });
  };

  const service = SERVICE_TYPES.find(s => s.key === serviceType);
  const filtered = filter === 'online'
    ? technicians.filter(t => t.availability === 'online')
    : technicians;

  return (
    <ScreenWrapper title={`${service?.icon || '🛠️'} ${service?.label || 'Technicians'}`} showBack>
      {/* Filter */}
      <View style={s.filterRow}>
        {(['online','all'] as const).map(f => (
          <TouchableOpacity key={f} style={[s.filterBtn, filter===f && s.filterBtnActive]} onPress={() => setFilter(f)}>
            <Text style={[s.filterTxt, filter===f && { color:Colors.primary }]}>
              {f === 'online' ? '🟢 Online' : '👥 All'}
            </Text>
          </TouchableOpacity>
        ))}
        <Text style={s.count}>{filtered.length} found</Text>
      </View>

      {loading ? (
        <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={t => t._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom:40 }}
          ListEmptyComponent={
            <EmptyState emoji="🔍" title="No technicians nearby"
              subtitle="No technicians found. Your booking will be sent to all nearby technicians automatically."
              action="Book Anyway" onAction={() => navigation.navigate('BookService', { preselected: serviceType })}/>
          }
          renderItem={({ item }) => {
            const user = item.user as any;
            const isSelected = selectedTech === item._id;
            return (
              <Card style={[s.card, isSelected && s.cardSelected]}>
                <View style={s.row}>
                  <View style={s.avatar}>
                    <Text style={{ fontSize:26 }}>👨‍🔧</Text>
                  </View>
                  <View style={{ flex:1 }}>
                    <View style={{ flexDirection:'row', alignItems:'center', gap:8 }}>
                      <Text style={s.name}>{user?.fullName || 'Technician'}</Text>
                      <View style={[s.onlineDot, {
                        backgroundColor: item.availability==='online' ? Colors.success
                          : item.availability==='busy' ? Colors.warning : Colors.textMuted
                      }]}/>
                    </View>
                    <Stars rating={item.averageRating}/>
                    <View style={s.tags}>
                      <View style={s.tag}><Text style={s.tagTxt}>✅ {item.totalJobs} jobs</Text></View>
                      <View style={s.tag}><Text style={s.tagTxt}>📅 {item.yearsOfExperience}yr exp</Text></View>
                      {item.availability === 'busy' && <View style={[s.tag, { backgroundColor:'rgba(245,158,11,0.15)' }]}><Text style={[s.tagTxt, { color:Colors.warning }]}>Busy</Text></View>}
                    </View>
                  </View>
                  <Badge
                    label={item.averageRating > 4.5 ? '⭐ Top' : item.totalJobs > 50 ? '🔥 Pro' : '✓ Verified'}
                    color={item.averageRating > 4.5 ? Colors.warning : Colors.success}
                    bg={item.averageRating > 4.5 ? Colors.warningBg : Colors.successBg}
                  />
                </View>

                {item.bio && (
                  <Text style={s.bio} numberOfLines={2}>{item.bio}</Text>
                )}

                <View style={s.footer}>
                  <View>
                    <Text style={s.priceLabel}>Price after inspection</Text>
                    <Text style={{ fontSize:FontSize.xs, color:Colors.textMuted }}></Text>
                  </View>
                  <Button
                    title={item.availability === 'busy' ? 'Busy' : '📩 Request'}
                    onPress={() => handleRequest(item._id)}
                    size="sm"
                    variant={item.availability === 'busy' ? 'ghost' : 'primary'}
                    disabled={item.availability === 'busy'}
                    style={{ width:'auto', paddingHorizontal:16 } as any}
                  />
                </View>
              </Card>
            );
          }}
        />
      )}
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:       { flex:1, alignItems:'center', justifyContent:'center', marginTop:60 },
  filterRow:    { flexDirection:'row', gap:8, marginBottom:Spacing.lg, alignItems:'center' },
  filterBtn:    { paddingVertical:8, paddingHorizontal:14, borderRadius:Radius.full, backgroundColor:Colors.surface2, borderWidth:1, borderColor:Colors.border },
  filterBtnActive:{ backgroundColor:Colors.primaryBg, borderColor:Colors.primary },
  filterTxt:    { fontSize:FontSize.sm, fontWeight:FontWeight.medium, color:Colors.textMuted },
  count:        { marginLeft:'auto', fontSize:FontSize.xs, color:Colors.textMuted },
  card:         { marginBottom:Spacing.md },
  cardSelected: { borderColor:Colors.primary, borderWidth:2 },
  row:          { flexDirection:'row', gap:12, alignItems:'flex-start', marginBottom:10 },
  avatar:       { width:52, height:52, borderRadius:26, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center' },
  name:         { fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text },
  onlineDot:    { width:8, height:8, borderRadius:4 },
  tags:         { flexDirection:'row', gap:6, marginTop:4, flexWrap:'wrap' },
  tag:          { backgroundColor:Colors.surface2, borderRadius:Radius.full, paddingVertical:2, paddingHorizontal:8 },
  tagTxt:       { fontSize:FontSize.xs, color:Colors.textMuted },
  bio:          { fontSize:FontSize.sm, color:Colors.textMuted, fontStyle:'italic', marginBottom:10, lineHeight:18 },
  footer:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center' },
  priceLabel:   { fontSize:FontSize.sm, fontWeight:FontWeight.semibold, color:Colors.text },
});
