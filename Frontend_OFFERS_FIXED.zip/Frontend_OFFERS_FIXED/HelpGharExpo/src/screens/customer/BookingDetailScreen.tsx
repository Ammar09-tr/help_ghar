import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator, Modal, TextInput, Linking, AppState
} from 'react-native';
import { bookingsApi } from '../../api/services';
import { useSocket } from '../../hooks/useSocket';
import { Button, Card, Badge, Divider, Stars, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES, BOOKING_STATUS_COLORS, BOOKING_STATUS_LABELS } from '../../constants/api';

export default function BookingDetailScreen({ navigation, route }: any) {
  const { bookingId } = route.params;
  const { on, joinBookingRoom, leaveBookingRoom } = useSocket();

  const [booking, setBooking]           = useState<any>(null);
  const [offers, setOffers]             = useState<any[]>([]);
  const [loading, setLoading]           = useState(true);
  const [offersLoading, setOffersLoading] = useState(false);
  const [confirmModal, setConfirmModal] = useState(false);
  const [rating, setRating]             = useState(5);
  const [review, setReview]             = useState('');
  const [finalPrice, setFinalPrice]     = useState('');
  const [confirming, setConfirming]     = useState(false);
  const [cancelling, setCancelling]     = useState(false);
  const [selectingOffer, setSelectingOffer] = useState<string | null>(null);
  const appState = useRef(AppState.currentState);

  useEffect(() => {
    load();
    joinBookingRoom(bookingId);

    // ✅ Real-time: new offer aaya
    const u1 = on('booking:new_offer', (data: any) => {
      console.log('📥 New offer received!', data?.offer?.price);
      loadOffers(); // reload offers
    });

    const u2 = on('booking:offer_accepted', () => { load(); });
    const u3 = on('booking:accepted', () => { load(); });
    const u4 = on('booking:started', () => { load(); });
    const u5 = on('booking:completed', () => { load(); });

    // App foreground pe refresh
    const sub = AppState.addEventListener('change', nextState => {
      if (appState.current.match(/inactive|background/) && nextState === 'active') {
        load();
        loadOffers();
      }
      appState.current = nextState;
    });

    // Auto refresh every 10 seconds when pending
    const interval = setInterval(() => {
      if (booking?.status === 'pending') {
        loadOffers();
      }
    }, 10000);

    return () => {
      leaveBookingRoom(bookingId);
      u1?.(); u2?.(); u3?.(); u4?.(); u5?.();
      sub.remove();
      clearInterval(interval);
    };
  }, [bookingId]);

  const load = async () => {
    try {
      const r = await bookingsApi.getById(bookingId);
      setBooking(r.data);
      if (r.data.quotedPrice) setFinalPrice(String(r.data.quotedPrice));
      if (r.data.status === 'pending') {
        await loadOffers();
      }
    } catch (err: any) {
      console.log('Load booking error:', err?.response?.data);
    } finally {
      setLoading(false);
    }
  };

 const loadOffers = async () => {
    setOffersLoading(true);
    try {
      const r = await bookingsApi.getOffers(bookingId);
      console.log('📋 Offers loaded:', r.data?.length);
      console.log('📋 Offers data:', JSON.stringify(r.data?.map((o:any) => ({price: o.price, status: o.status}))));
      setOffers(r.data || []);
    } catch (err: any) {
      console.log('❌ Offers error status:', err?.response?.status);
      console.log('❌ Offers error:', JSON.stringify(err?.response?.data));
      setOffers([]);
    } finally {
      setOffersLoading(false);
    }
  };

  const handleSelectOffer = (offer: any) => {
    const tech = offer.technician?.user || offer.technician;
    Alert.alert(
      'Select This Technician? ✅',
      `${tech?.fullName || 'Technician'} offered ₨ ${offer.price?.toLocaleString()}\n\nAre you sure?`,
      [
        { text: 'Cancel' },
        {
          text: 'Yes, Select!',
          onPress: async () => {
            setSelectingOffer(offer._id);
            try {
              await bookingsApi.selectOffer(bookingId, offer._id);
              Alert.alert('Technician Selected! 🎉', 'The technician is on the way!', [
                { text: 'Track', onPress: () => navigation.replace('TrackBooking', { bookingId }) },
              ]);
            } catch (err: any) {
              Alert.alert('Error', err?.response?.data?.message || 'Could not select');
            } finally { setSelectingOffer(null); }
          },
        },
      ]
    );
  };

  const handleConfirm = async () => {
    if (!finalPrice || Number(finalPrice) <= 0) {
      Alert.alert('Error', 'Enter a valid amount');
      return;
    }
    setConfirming(true);
    try {
      await bookingsApi.confirmCompletion(bookingId, {
        finalPrice: Number(finalPrice), rating, review: review.trim() || undefined,
      });
      setConfirmModal(false);
      Alert.alert('Confirmed ✅', 'Thank you!', [
        { text: 'OK', onPress: () => { load(); navigation.goBack(); } },
      ]);
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.message || 'Failed');
    } finally { setConfirming(false); }
  };

  const handleCancel = () => {
    Alert.alert('Cancel Booking', 'Are you sure?', [
      { text: 'No' },
      {
        text: 'Yes, Cancel', style: 'destructive',
        onPress: async () => {
          setCancelling(true);
          try {
            await bookingsApi.cancel(bookingId, 'Cancelled by customer');
            Alert.alert('Cancelled', 'Booking cancelled.', [
              { text: 'OK', onPress: () => { load(); navigation.goBack(); } },
            ]);
          } catch (err: any) {
            Alert.alert('Error', err?.response?.data?.message || 'Cannot cancel');
          } finally { setCancelling(false); }
        },
      },
    ]);
  };

  if (loading) return (
    <ScreenWrapper title="Booking Detail" showBack>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </ScreenWrapper>
  );
  if (!booking) return (
    <ScreenWrapper title="Booking Detail" showBack>
      <View style={s.center}><Text style={{ color: Colors.textMuted }}>Not found</Text></View>
    </ScreenWrapper>
  );

  const service   = SERVICE_TYPES.find(sv => sv.key === booking.serviceType);
  const sColor    = BOOKING_STATUS_COLORS[booking.status] || Colors.textMuted;
  const tech      = booking.technician as any;
  const techUser  = tech?.user || tech;
  const fmtDate   = (d?: string) => {
    try { return d ? new Date(d).toLocaleString('en-PK', { dateStyle:'medium', timeStyle:'short' }) : '-'; }
    catch { return '-'; }
  };

  return (
    <ScreenWrapper
      title="Booking Detail"
      showBack
      rightElement={
        <Badge label={BOOKING_STATUS_LABELS[booking.status] || booking.status} color={sColor} bg={sColor + '20'} dot/>
      }
    >
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>

        {/* Service Summary */}
        <Card>
          <View style={s.row}>
            <View style={s.svcIcon}><Text style={{ fontSize: 28 }}>{service?.icon || '🛠️'}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.svcName}>{service?.label || booking.serviceType}</Text>
              <Text style={s.meta}>{booking.customerLocation?.address}, {booking.customerLocation?.city}</Text>
              <Text style={s.meta}>Created: {fmtDate(booking.createdAt)}</Text>
            </View>
          </View>
          <Divider style={{ marginVertical: 12 }}/>
          <Text style={s.desc}>{booking.problemDescription}</Text>
          {booking.customerNote && <Text style={s.note}>📝 {booking.customerNote}</Text>}
        </Card>

        {/* ── INDRIVE OFFERS SECTION ── */}
        {booking.status === 'pending' && (
          <View style={s.offersSection}>

            {/* Header */}
            <View style={s.offersTitleRow}>
              <Text style={s.offersTitle}>🏎️ Price Offers</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                {offersLoading && <ActivityIndicator size="small" color={Colors.primary}/>}
                <View style={s.offersCountBadge}>
                  <Text style={s.offersCountTxt}>{offers.length} offers</Text>
                </View>
                <TouchableOpacity onPress={loadOffers} style={s.refreshBtn}>
                  <Text style={s.refreshBtnTxt}>↻</Text>
                </TouchableOpacity>
              </View>
            </View>

            {offers.length === 0 ? (
              <View style={s.waitingBox}>
                <Text style={{ fontSize: 40, marginBottom: 8 }}>⏳</Text>
                <Text style={s.waitingTitle}>Waiting for offers...</Text>
                <Text style={s.waitingSub}>
                  Nearby technicians are reviewing your request.{'\n'}
                  Pull down to refresh or wait for automatic updates.
                </Text>
                <TouchableOpacity style={s.manualRefreshBtn} onPress={loadOffers}>
                  <Text style={s.manualRefreshTxt}>↻ Check for Offers</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <Text style={s.offersHint}>
                  💡 Select the best offer — lowest price shown first
                </Text>
                {offers
                  .sort((a, b) => a.price - b.price)
                  .map((offer, index) => {
                    const offerTech = offer.technician?.user || offer.technician;
                    const isSelecting = selectingOffer === offer._id;

                    return (
                      <View key={offer._id} style={[s.offerCard, index === 0 && s.offerCardBest]}>
                        {index === 0 && (
                          <View style={s.bestBadge}>
                            <Text style={s.bestBadgeTxt}>🏆 Best Price</Text>
                          </View>
                        )}

                        <View style={s.offerRow}>
                          <View style={s.offerAvatar}>
                            <Text style={{ fontSize: 24 }}>👨‍🔧</Text>
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={s.offerTechName}>{offerTech?.fullName || 'Technician'}</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 2 }}>
                              {offer.technician?.averageRating > 0 && (
                                <Stars rating={offer.technician.averageRating} size={12}/>
                              )}
                              {offer.technician?.totalJobs > 0 && (
                                <Text style={s.offerMeta}>{offer.technician.totalJobs} jobs</Text>
                              )}
                            </View>
                            {offer.note && (
                              <Text style={s.offerNote} numberOfLines={2}>"{offer.note}"</Text>
                            )}
                          </View>
                          <View style={s.offerPriceBox}>
                            <Text style={s.offerPrice}>₨ {offer.price?.toLocaleString()}</Text>
                            <Text style={s.offerPriceLabel}>quoted</Text>
                          </View>
                        </View>

                        <TouchableOpacity
                          style={[s.selectBtn, index === 0 && s.selectBtnBest]}
                          onPress={() => handleSelectOffer(offer)}
                          disabled={!!selectingOffer}
                        >
                          {isSelecting
                            ? <ActivityIndicator color={Colors.white} size="small"/>
                            : <Text style={s.selectBtnTxt}>
                                {index === 0 ? '✅ Select Best Offer' : '✓ Select'}
                              </Text>
                          }
                        </TouchableOpacity>
                      </View>
                    );
                  })
                }
              </>
            )}

            {/* Cancel option */}
            <Button
              title="Cancel Booking"
              onPress={handleCancel}
              variant="outline"
              loading={cancelling}
              style={{ marginTop: 8 }}
            />
          </View>
        )}

        {/* Technician Card (after accepted) */}
        {techUser && booking.status !== 'pending' && (
          <Card>
            <Text style={s.cardTitle}>Your Technician</Text>
            <View style={s.row}>
              <View style={s.techAvatar}><Text style={{ fontSize: 24 }}>👨‍🔧</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={s.svcName}>{techUser?.fullName || 'Assigned'}</Text>
                <Text style={s.meta}>{techUser?.phone || ''}</Text>
                {techUser?.averageRating > 0 && <Stars rating={techUser.averageRating}/>}
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TouchableOpacity style={s.iconBtn}
                  onPress={() => navigation.navigate('Chat', { bookingId: booking._id, otherName: techUser?.fullName })}>
                  <Text style={{ fontSize: 18 }}>💬</Text>
                </TouchableOpacity>
                {techUser?.phone && (
                  <TouchableOpacity style={s.iconBtn} onPress={() => Linking.openURL(`tel:${techUser.phone}`)}>
                    <Text style={{ fontSize: 18 }}>📞</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </Card>
        )}

        {/* Payment */}
        {booking.quotedPrice && (
          <Card>
            <Text style={s.cardTitle}>Payment</Text>
            <View style={s.priceRow}>
              <Text style={s.priceLabel}>Quoted Price</Text>
              <Text style={s.priceVal}>₨ {booking.quotedPrice.toLocaleString()}</Text>
            </View>
            {booking.finalPrice && (
              <View style={s.priceRow}>
                <Text style={s.priceLabel}>Final Price</Text>
                <Text style={[s.priceVal, { color: Colors.success }]}>₨ {booking.finalPrice.toLocaleString()}</Text>
              </View>
            )}
            {booking.commissionAmount && (
              <View style={s.priceRow}>
                <Text style={s.priceLabel}>Platform Fee (10%)</Text>
                <Text style={s.priceVal}>₨ {booking.commissionAmount.toLocaleString()}</Text>
              </View>
            )}
          </Card>
        )}

        {/* Timeline */}
        <Card>
          <Text style={s.cardTitle}>Timeline</Text>
          {[
            { label: 'Request Created',  time: fmtDate(booking.createdAt),   done: true },
            { label: 'Accepted',         time: fmtDate(booking.acceptedAt),  done: !!booking.acceptedAt },
            { label: 'Job Started',      time: fmtDate(booking.startedAt),   done: !!booking.startedAt },
            { label: 'Completed',        time: fmtDate(booking.completedAt), done: !!booking.completedAt },
            { label: 'Confirmed & Paid', time: fmtDate(booking.confirmedAt), done: !!booking.confirmedAt, last: true },
          ].map((step, i) => (
            <View key={i} style={s.stepRow}>
              <View style={{ alignItems: 'center' }}>
                <View style={[s.stepDot, step.done && s.stepDotDone]}>
                  <Text style={{ fontSize: 10, color: step.done ? Colors.white : Colors.textMuted }}>
                    {step.done ? '✓' : i + 1}
                  </Text>
                </View>
                {!(step as any).last && <View style={[s.stepLine, step.done && s.stepLineDone]}/>}
              </View>
              <View style={{ flex: 1, paddingTop: 2, paddingBottom: (step as any).last ? 0 : 14 }}>
                <Text style={[{ fontSize: FontSize.sm, fontWeight: FontWeight.medium }, step.done ? { color: Colors.text } : { color: Colors.textMuted }]}>
                  {step.label}
                </Text>
                <Text style={{ fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 }}>{step.time}</Text>
              </View>
            </View>
          ))}
        </Card>

        {booking.customerRating && (
          <Card>
            <Text style={s.cardTitle}>Your Review</Text>
            <Stars rating={booking.customerRating} size={22}/>
            {booking.customerReview && (
              <Text style={{ fontSize: FontSize.sm, color: Colors.textMuted, fontStyle: 'italic', marginTop: 8, lineHeight: 18 }}>
                "{booking.customerReview}"
              </Text>
            )}
          </Card>
        )}

        {booking.status === 'completed' && (
          <Button title="✅ Confirm & Pay" onPress={() => setConfirmModal(true)} style={{ marginBottom: 12 }}/>
        )}
        {['accepted'].includes(booking.status) && (
          <Button title="Cancel Booking" onPress={handleCancel} variant="outline" loading={cancelling}/>
        )}

      </ScrollView>

      {/* Confirm Modal */}
      <Modal visible={confirmModal} transparent animationType="slide">
        <View style={s.modalBg}>
          <View style={s.modal}>
            <Text style={s.modalTitle}>Confirm Payment ⭐</Text>
            <Text style={{ fontSize: FontSize.sm, color: Colors.textMuted, marginBottom: 20 }}>
              Enter amount paid and rate the service
            </Text>
            <Text style={s.inputLabel}>Amount Paid (₨)</Text>
            <TextInput
              style={s.modalInput}
              value={finalPrice}
              onChangeText={setFinalPrice}
              keyboardType="numeric"
              placeholder={booking.quotedPrice ? `₨ ${booking.quotedPrice}` : 'Enter amount'}
              placeholderTextColor={Colors.textMuted}
            />
            <Text style={s.inputLabel}>Rating</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginBottom: 16 }}>
              {[1, 2, 3, 4, 5].map(i => (
                <TouchableOpacity key={i} onPress={() => setRating(i)}>
                  <Text style={{ fontSize: 32, color: i <= rating ? Colors.warning : Colors.surface3 }}>★</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={s.inputLabel}>Review (optional)</Text>
            <TextInput
              style={[s.modalInput, { height: 80, textAlignVertical: 'top', paddingTop: 12 }]}
              value={review}
              onChangeText={setReview}
              placeholder="Share your experience..."
              placeholderTextColor={Colors.textMuted}
              multiline
            />
            <View style={{ flexDirection: 'row', gap: 12, marginTop: 8 }}>
              <Button title="Cancel" onPress={() => setConfirmModal(false)} variant="outline" size="sm" style={{ flex: 1 }}/>
              <Button title="Confirm ✅" onPress={handleConfirm} loading={confirming} size="sm" style={{ flex: 1 }}/>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: 60 },
  row:          { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  svcIcon:      { width: 52, height: 52, borderRadius: Radius.md, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center' },
  svcName:      { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  meta:         { fontSize: FontSize.sm, color: Colors.textMuted, marginTop: 2 },
  desc:         { fontSize: FontSize.md, color: Colors.text, lineHeight: 20 },
  note:         { fontSize: FontSize.sm, color: Colors.textMuted, marginTop: 8, fontStyle: 'italic' },
  cardTitle:    { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 12 },
  techAvatar:   { width: 46, height: 46, borderRadius: 23, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center' },
  iconBtn:      { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
  priceRow:     { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  priceLabel:   { fontSize: FontSize.sm, color: Colors.textMuted },
  priceVal:     { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.text },
  stepRow:      { flexDirection: 'row', gap: 12 },
  stepDot:      { width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.surface3, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  stepDotDone:  { backgroundColor: Colors.success },
  stepLine:     { width: 2, flex: 1, backgroundColor: Colors.surface3, marginVertical: 3 },
  stepLineDone: { backgroundColor: Colors.success },

  // Offers
  offersSection:   { marginBottom: Spacing.lg },
  offersTitleRow:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  offersTitle:     { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  offersCountBadge:{ backgroundColor: Colors.primaryBg, borderRadius: Radius.full, paddingVertical: 4, paddingHorizontal: 10, borderWidth: 1, borderColor: Colors.primary },
  offersCountTxt:  { fontSize: FontSize.xs, color: Colors.primary, fontWeight: FontWeight.bold },
  refreshBtn:      { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
  refreshBtnTxt:   { fontSize: FontSize.md, color: Colors.primary },
  offersHint:      { fontSize: FontSize.sm, color: Colors.textMuted, marginBottom: 12, fontStyle: 'italic' },

  waitingBox:      { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.xxl, alignItems: 'center', marginBottom: Spacing.lg, gap: 4 },
  waitingTitle:    { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  waitingSub:      { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 20 },
  manualRefreshBtn:{ marginTop: 12, backgroundColor: Colors.primaryBg, borderRadius: Radius.full, paddingVertical: 8, paddingHorizontal: 20, borderWidth: 1, borderColor: Colors.primary },
  manualRefreshTxt:{ fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.semibold },

  offerCard:       { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.border, padding: Spacing.lg, marginBottom: Spacing.md, position: 'relative', overflow: 'hidden' },
  offerCardBest:   { borderColor: Colors.primary, backgroundColor: 'rgba(255,92,26,0.03)' },
  bestBadge:       { position: 'absolute', top: 0, right: 0, backgroundColor: Colors.primary, paddingVertical: 4, paddingHorizontal: 12, borderBottomLeftRadius: Radius.md },
  bestBadgeTxt:    { fontSize: FontSize.xs, color: Colors.white, fontWeight: FontWeight.bold },
  offerRow:        { flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 },
  offerAvatar:     { width: 48, height: 48, borderRadius: 24, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center' },
  offerTechName:   { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  offerMeta:       { fontSize: FontSize.xs, color: Colors.textMuted },
  offerNote:       { fontSize: FontSize.sm, color: Colors.textMuted, fontStyle: 'italic', marginTop: 4 },
  offerPriceBox:   { alignItems: 'flex-end' },
  offerPrice:      { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.primary },
  offerPriceLabel: { fontSize: FontSize.xs, color: Colors.textMuted },
  selectBtn:       { backgroundColor: Colors.surface2, borderRadius: Radius.md, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  selectBtnBest:   { backgroundColor: Colors.primary, borderColor: Colors.primary },
  selectBtnTxt:    { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.white },

  // Modal
  modalBg:    { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modal:      { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 4 },
  inputLabel: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  modalInput: { backgroundColor: Colors.surface2, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border, padding: 13, color: Colors.text, fontSize: FontSize.md, marginBottom: 16 },
});
