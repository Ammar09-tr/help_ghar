import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform, Alert, ActivityIndicator, Image
} from 'react-native';
import * as Location from 'expo-location';
import * as ImagePicker from 'expo-image-picker';
import { bookingsApi } from '../../api/services';
import { Input, Button, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function BookServiceScreen({ navigation, route }: any) {
  const preselected = route?.params?.preselected || 'electrician';
  const [selectedService, setSelectedService] = useState(preselected);
  const [description, setDescription]         = useState('');
  const [note, setNote]                       = useState('');
  const [address, setAddress]                 = useState('');
  const [city, setCity]                       = useState('');
  const [coords, setCoords]                   = useState<{lat:number;lng:number}|null>(null);
  const [locLoading, setLocLoading]           = useState(false);
  const [images, setImages]                   = useState<string[]>([]);
  const [loading, setLoading]                 = useState(false);
  const [errors, setErrors]                   = useState<Record<string,string>>({});

  useEffect(() => { fetchLocation(); }, []);

  const fetchLocation = async () => {
    setLocLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setCoords({ lat:31.5204, lng:74.3587 });
        setAddress('Gulberg III'); setCity('Lahore');
        setLocLoading(false); return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      const geo = await Location.reverseGeocodeAsync({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      if (geo.length > 0) {
        const g = geo[0];
        setAddress([g.streetNumber, g.street, g.district].filter(Boolean).join(', '));
        setCity(g.city || g.region || '');
      }
    } catch {
      setCoords({ lat:31.5204, lng:74.3587 });
      setAddress('Gulberg III'); setCity('Lahore');
    }
    setLocLoading(false);
  };

  const pickImage = async () => {
    if (images.length >= 3) { Alert.alert('Limit', 'Maximum 3 photos'); return; }
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permission needed'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, quality: 0.7,
    });
    if (!result.canceled && result.assets[0]) {
      setImages(prev => [...prev, result.assets[0].uri]);
    }
  };

  const validate = () => {
    const e:Record<string,string> = {};
    if (!description.trim())               e.description = 'Please describe the problem';
    else if (description.trim().length<10) e.description = 'Please provide more detail';
    if (!address.trim()) e.address = 'Address required';
    if (!city.trim())    e.city    = 'City required';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    if (!coords) { Alert.alert('Location required'); return; }
    setLoading(true);
    try {
      const res = await bookingsApi.create({
        serviceType: selectedService,
        problemDescription: description.trim(),
        customerNote: note.trim() || undefined,
        customerLocation: { longitude:coords.lng, latitude:coords.lat, address:address.trim(), city:city.trim() },
      });

      Alert.alert(
        'Request Sent! 🎉',
        'Nearby technicians will send you their price offers. You choose the best one!',
        [
          {
            text: 'View Offers',
            onPress: () => navigation.replace('Offers', {
              bookingId: res.data._id,
              serviceType: selectedService,
            })
          },
        ]
      );
    } catch (err:any) {
      const msg = err?.response?.data?.message || 'Failed to create booking.';
      Alert.alert('Error', Array.isArray(msg)?msg.join('\n'):msg);
    } finally { setLoading(false); }
  };

  return (
    <ScreenWrapper title="Book a Service" showBack>
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1}}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:40}}>

          {/* InDrive info */}
          <View style={s.indriveBox}>
            <Text style={{fontSize:20}}>🏷️</Text>
            <View style={{flex:1}}>
              <Text style={s.indriveTitle}></Text>
              <Text style={s.indriveSub}>Send your request → Multiple technicians bid → You pick the best price!</Text>
            </View>
          </View>

          {/* Service Selection */}
          <Text style={s.label}>Select Service</Text>
          <View style={s.serviceGrid}>
            {SERVICE_TYPES.map(sv=>(
              <TouchableOpacity key={sv.key}
                style={[s.serviceItem, selectedService===sv.key&&s.serviceItemActive]}
                onPress={()=>setSelectedService(sv.key)} activeOpacity={0.8}>
                <Text style={{fontSize:26}}>{sv.icon}</Text>
                <Text style={[s.serviceLabel, selectedService===sv.key&&{color:Colors.primary}]}>{sv.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Input label="Problem Description *" placeholder="e.g. Fan stopped working, socket sparking..."
            value={description} onChangeText={setDescription} multiline numberOfLines={4}
            style={{height:100,textAlignVertical:'top',paddingTop:12} as any} error={errors.description}/>

          {/* Photos */}
          <Text style={s.label}>Upload Photos (optional, max 3)</Text>
          <View style={s.photoRow}>
            {images.map((uri,i)=>(
              <View key={i} style={s.photoThumb}>
                <Image source={{uri}} style={{width:'100%',height:'100%',borderRadius:Radius.sm}}/>
                <TouchableOpacity style={s.photoRemove} onPress={()=>setImages(prev=>prev.filter((_,j)=>j!==i))}>
                  <Text style={{color:Colors.white,fontSize:12,fontWeight:FontWeight.bold}}>✕</Text>
                </TouchableOpacity>
              </View>
            ))}
            {images.length<3 && (
              <TouchableOpacity style={s.photoAdd} onPress={pickImage}>
                <Text style={{fontSize:28,color:Colors.textMuted}}>📷</Text>
                <Text style={{fontSize:FontSize.xs,color:Colors.textMuted}}>Add Photo</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Location */}
          <Text style={s.label}>Your Location *</Text>
          <View style={s.mapBox}>
            <Text style={{fontSize:24}}>📍</Text>
            {locLoading
              ? <ActivityIndicator color={Colors.primary} style={{flex:1}}/>
              : <Text style={{flex:1,fontSize:FontSize.sm,color:Colors.text}}>
                  {coords ? `${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}` : 'Getting location...'}
                </Text>
            }
            <TouchableOpacity style={s.refreshBtn} onPress={fetchLocation}>
              <Text style={{fontSize:FontSize.xs,color:Colors.primary,fontWeight:FontWeight.medium}}>↻ Refresh</Text>
            </TouchableOpacity>
          </View>

          <Input label="Address *" placeholder="e.g. House 12, Street 5, Gulberg III"
            value={address} onChangeText={setAddress} leftIcon="🏠" error={errors.address}/>
          <Input label="City *" placeholder="e.g. Lahore"
            value={city} onChangeText={setCity} leftIcon="🌆" error={errors.city}/>
          <Input label="Note to Technicians (optional)" placeholder="Any specific instructions..."
            value={note} onChangeText={setNote} multiline numberOfLines={2}
            style={{height:70,textAlignVertical:'top',paddingTop:10} as any}/>

          <Button
            title={loading ? 'Sending Request...' : '🔍 Find Technicians'}
            onPress={handleSubmit} loading={loading} style={{marginTop:8}}/>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  indriveBox:  {flexDirection:'row',gap:10,backgroundColor:Colors.primaryBg,borderRadius:Radius.lg,borderWidth:1,borderColor:'rgba(255,92,26,0.3)',padding:Spacing.lg,marginBottom:Spacing.xl,alignItems:'flex-start'},
  indriveTitle:{fontSize:FontSize.sm,fontWeight:FontWeight.bold,color:Colors.primary,marginBottom:2},
  indriveSub:  {fontSize:FontSize.xs,color:Colors.textMuted,lineHeight:16},
  label:       {fontSize:FontSize.xs,color:Colors.textMuted,fontWeight:FontWeight.medium,marginBottom:8,textTransform:'uppercase',letterSpacing:0.5},
  serviceGrid: {flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:Spacing.xl},
  serviceItem: {width:'22%',backgroundColor:Colors.surface,borderRadius:Radius.lg,borderWidth:1.5,borderColor:Colors.border,padding:10,alignItems:'center',gap:4},
  serviceItemActive:{borderColor:Colors.primary,backgroundColor:Colors.primaryBg},
  serviceLabel:{fontSize:10,fontWeight:FontWeight.semibold,color:Colors.textMuted,textAlign:'center'},
  photoRow:    {flexDirection:'row',gap:10,marginBottom:Spacing.lg,flexWrap:'wrap'},
  photoThumb:  {width:80,height:80,borderRadius:Radius.sm,overflow:'hidden',position:'relative'},
  photoRemove: {position:'absolute',top:4,right:4,backgroundColor:'rgba(0,0,0,0.6)',width:20,height:20,borderRadius:10,alignItems:'center',justifyContent:'center'},
  photoAdd:    {width:80,height:80,borderRadius:Radius.sm,borderWidth:1.5,borderColor:Colors.border,borderStyle:'dashed',backgroundColor:Colors.surface2,alignItems:'center',justifyContent:'center',gap:4},
  mapBox:      {backgroundColor:Colors.surface2,borderRadius:Radius.md,borderWidth:1,borderColor:Colors.border,padding:Spacing.lg,flexDirection:'row',alignItems:'center',gap:10,marginBottom:Spacing.md},
  refreshBtn:  {backgroundColor:Colors.surface3,borderRadius:Radius.sm,paddingVertical:6,paddingHorizontal:10},
});
