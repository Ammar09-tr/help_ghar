import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, TextInput
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { bookingsApi } from '../../api/services';
import { useAuthStore } from '../../store/authStore';
import { useSocket } from '../../hooks/useSocket';
import { useNotificationStore } from '../../store/notificationStore';
import { Booking } from '../../types';
import { BookingCard, Badge, EmptyState } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';
import { SERVICE_TYPES } from '../../constants/api';

export default function CustomerHomeScreen({ navigation }: any) {
  const user = useAuthStore(s => s.user);
  const { connect, on } = useSocket();
  const { unreadCount, addLocalNotification, loadFromStorage } = useNotificationStore();
  const [bookings, setBookings]     = useState<Booking[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch]         = useState('');

  const activeBooking = bookings.find(b =>
    ['pending', 'accepted', 'en_route', 'in_progress'].includes(b.status)
  );
  const recentBookings = bookings
    .filter(b => ['confirmed', 'cancelled', 'rejected'].includes(b.status))
    .slice(0, 3);

  const filteredServices = SERVICE_TYPES.filter(s =>
    s.label.toLowerCase().includes(search.toLowerCase()) || !search
  );

  const load = async () => {
    try {
      const r = await bookingsApi.getMyBookings();
      setBookings(r.data);
    } catch {}
  };

  useFocusEffect(useCallback(() => {
    load();
    loadFromStorage();
  }, []));

  useEffect(() => {
    connect();

    const u1 = on('booking:new_offer', (data: any) => {
      addLocalNotification(
        'New Offer Received! 💰',
        data?.message || 'A technician sent a price offer',
        'booking', data,
      );
      load();
    });

    const u2 = on('booking:accepted', (data: any) => {
      addLocalNotification('Booking Accepted ✅', data?.message || 'Technician accepted!', 'booking', data);
      load();
    });

    const u3 = on('booking:completed', (data: any) => {
      addLocalNotification('Job Completed 🎉', data?.message || 'Confirm and pay', 'booking', data);
      load();
    });

    const u4 = on('booking:price_set', (data: any) => {
      addLocalNotification('Price Set 💰', data?.message || `Price: ₨${data?.quotedPrice}`, 'booking', data);
      load();
    });

    const u5 = on('booking:started', (data: any) => {
      addLocalNotification('Job Started 🔧', data?.message || 'Technician started!', 'booking', data);
      load();
    });

    return () => { u1?.(); u2?.(); u3?.(); u4?.(); u5?.(); };
  }, []);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const greeting = () => {
    const h = new Date().getHours();
    return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  };

  // ✅ Navigate based on booking status
  const handleBookingPress = (booking: Booking) => {
    if (booking.status === 'pending') {
      // Pending = show offers screen
      navigation.navigate('BookingDetail', { bookingId: booking._id });
    } else if (['accepted', 'en_route', 'in_progress'].includes(booking.status)) {
      navigation.navigate('TrackBooking', { bookingId: booking._id });
    } else {
      navigation.navigate('BookingDetail', { bookingId: booking._id });
    }
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary}/>}
        contentContainerStyle={s.scroll}
      >
        {/* Header */}
        <View style={s.header}>
          <View>
            <Text style={s.greeting}>{greeting()} 👋</Text>
            <Text style={s.userName}>{user?.fullName?.split(' ')[0]}</Text>
          </View>
          <TouchableOpacity style={s.notifBtn} onPress={() => navigation.navigate('Notifications')}>
            <Text style={{ fontSize: 20 }}>🔔</Text>
            {unreadCount > 0 && (
              <View style={s.notifBadge}>
                <Text style={s.notifBadgeTxt}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Search */}
        <View style={s.searchBar}>
          <Text style={{ fontSize: 18 }}>🔍</Text>
          <TextInput
            style={s.searchInput}
            placeholder="Search services..."
            placeholderTextColor={Colors.textMuted}
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Text style={{ fontSize: 16, color: Colors.textMuted }}>✕</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Promo Banner */}
        {!search && (
          <LinearGradient colors={[Colors.primary, Colors.primaryLight]} style={s.banner} start={{ x:0, y:0 }} end={{ x:1, y:1 }}>
            <View style={s.bannerBg}><Text style={{ fontSize: 80, opacity: 0.15 }}>🏠</Text></View>
            <Text style={s.bannerSub}>First booking?</Text>
            <Text style={s.bannerTitle}>Get 20% OFF</Text>
            <View style={s.bannerCode}>
              <Text style={{ fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.white }}>HELPGHAR20</Text>
            </View>
          </LinearGradient>
        )}

        {/* Services */}
        <Text style={s.sectionTitle}>
          {search ? `Results for "${search}"` : 'Our Services'}
        </Text>
        <View style={s.serviceGrid}>
          {filteredServices.map(sv => (
            <TouchableOpacity key={sv.key} style={s.serviceItem} activeOpacity={0.8}
              onPress={() => navigation.navigate('BookService', { preselected: sv.key })}>
              <Text style={{ fontSize: 28 }}>{sv.icon}</Text>
              <Text style={s.serviceLabel}>{sv.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Active Booking */}
        {!search && activeBooking && (
          <>
            <View style={s.sectionRow}>
              <Text style={s.sectionTitle}>
                {activeBooking.status === 'pending' ? '⏳ Waiting for Offers' : '📍 Active Booking'}
              </Text>
              {/* Offer count badge */}
              {activeBooking.status === 'pending' && (
                <TouchableOpacity
                  style={s.viewOfferBtn}
                  onPress={() => navigation.navigate('BookingDetail', { bookingId: activeBooking._id })}
                >
                  <Text style={s.viewOfferBtnTxt}>View Offers →</Text>
                </TouchableOpacity>
              )}
            </View>

            {/* Pending booking — special card */}
            {activeBooking.status === 'pending' ? (
              <TouchableOpacity
                style={s.pendingCard}
                onPress={() => navigation.navigate('BookingDetail', { bookingId: activeBooking._id })}
                activeOpacity={0.85}
              >
                <View style={s.pendingTop}>
                  <View style={s.pendingIcon}>
                    <Text style={{ fontSize: 26 }}>
                      {SERVICE_TYPES.find(s => s.key === activeBooking.serviceType)?.icon || '🛠️'}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.pendingService}>
                      {SERVICE_TYPES.find(s => s.key === activeBooking.serviceType)?.label || activeBooking.serviceType}
                    </Text>
                    <Text style={s.pendingDesc} numberOfLines={1}>{activeBooking.problemDescription}</Text>
                  </View>
                  <View style={s.pendingBadge}>
                    <Text style={s.pendingBadgeTxt}>Pending</Text>
                  </View>
                </View>
                <View style={s.pendingBottom}>
                  <Text style={s.pendingHint}>
                    🏎️ Technicians are reviewing and sending price offers. Tap to see offers!
                  </Text>
                </View>
              </TouchableOpacity>
            ) : (
              <BookingCard
                booking={activeBooking}
                viewAs="customer"
                onPress={() => handleBookingPress(activeBooking)}
              />
            )}

            {/* Action buttons for non-pending */}
            {['accepted', 'en_route', 'in_progress'].includes(activeBooking.status) && (
              <View style={s.actionRow}>
                <TouchableOpacity style={s.actionBtn}
                  onPress={() => navigation.navigate('Chat', { bookingId: activeBooking._id, otherName: 'Technician' })}>
                  <Text style={s.actionBtnTxt}>💬 Chat</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.actionBtn}
                  onPress={() => navigation.navigate('TrackBooking', { bookingId: activeBooking._id })}>
                  <Text style={s.actionBtnTxt}>📍 Track</Text>
                </TouchableOpacity>
              </View>
            )}
            {activeBooking.status === 'completed' && (
              <TouchableOpacity style={[s.actionBtn, s.actionBtnPrimary, { marginBottom: Spacing.lg }]}
                onPress={() => navigation.navigate('BookingDetail', { bookingId: activeBooking._id })}>
                <Text style={[s.actionBtnTxt, { color: Colors.white }]}>✅ Confirm & Pay</Text>
              </TouchableOpacity>
            )}
          </>
        )}

        {/* CTA */}
        {!search && !activeBooking && (
          <TouchableOpacity style={s.ctaBox} onPress={() => navigation.navigate('BookService')}>
            <Text style={{ fontSize: 36 }}>🏠</Text>
            <Text style={s.ctaTitle}>Need help at home?</Text>
            <Text style={s.ctaSub}>Tap to book a service now</Text>
          </TouchableOpacity>
        )}

        {/* Recent */}
        {!search && recentBookings.length > 0 && (
          <>
            <View style={s.sectionRow}>
              <Text style={s.sectionTitle}>Recent Bookings</Text>
              <TouchableOpacity onPress={() => navigation.navigate('CustomerApp', { screen: 'Bookings' })}>
                <Text style={{ fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.medium }}>See all →</Text>
              </TouchableOpacity>
            </View>
            {recentBookings.map(b => (
              <BookingCard key={b._id} booking={b} viewAs="customer"
                onPress={() => navigation.navigate('BookingDetail', { bookingId: b._id })}/>
            ))}
          </>
        )}

        {!search && bookings.length === 0 && (
          <EmptyState emoji="🏠" title="No bookings yet"
            subtitle="Book your first home service and get help instantly"
            action="Book a Service" onAction={() => navigation.navigate('BookService')}/>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:           { flex: 1, backgroundColor: Colors.bg },
  scroll:         { paddingHorizontal: Spacing.xl, paddingTop: Spacing.md, paddingBottom: 100 },
  header:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.lg },
  greeting:       { fontSize: FontSize.sm, color: Colors.textMuted },
  userName:       { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  notifBtn:       { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border },
  notifBadge:     { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.danger, borderRadius: 10, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, borderWidth: 1.5, borderColor: Colors.bg },
  notifBadgeTxt:  { fontSize: 9, color: Colors.white, fontWeight: FontWeight.bold },
  searchBar:      { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.surface2, borderRadius: Radius.lg, paddingHorizontal: Spacing.lg, paddingVertical: 12, marginBottom: Spacing.xl, borderWidth: 1, borderColor: Colors.border },
  searchInput:    { flex: 1, color: Colors.text, fontSize: FontSize.md },
  banner:         { borderRadius: Radius.xl, padding: Spacing.xl, marginBottom: Spacing.xl, overflow: 'hidden', position: 'relative' },
  bannerBg:       { position: 'absolute', right: -10, top: -10 },
  bannerSub:      { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.8)', marginBottom: 4 },
  bannerTitle:    { fontSize: FontSize.xxxl, fontWeight: FontWeight.extrabold, color: Colors.white, marginBottom: 10 },
  bannerCode:     { backgroundColor: 'rgba(255,255,255,0.2)', alignSelf: 'flex-start', borderRadius: Radius.full, paddingVertical: 5, paddingHorizontal: 14 },
  sectionTitle:   { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.md },
  sectionRow:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  serviceGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: Spacing.xl },
  serviceItem:    { width: '22%', backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: 12, alignItems: 'center', gap: 4 },
  serviceLabel:   { fontSize: 10, fontWeight: FontWeight.semibold, color: Colors.textMuted, textAlign: 'center' },

  // Pending card
  pendingCard:    { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 2, borderColor: Colors.primary, marginBottom: Spacing.md, overflow: 'hidden' },
  pendingTop:     { flexDirection: 'row', alignItems: 'center', gap: 12, padding: Spacing.lg },
  pendingIcon:    { width: 48, height: 48, borderRadius: Radius.md, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  pendingService: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  pendingDesc:    { fontSize: FontSize.sm, color: Colors.textMuted, marginTop: 2 },
  pendingBadge:   { backgroundColor: Colors.warningBg, borderRadius: Radius.full, paddingVertical: 4, paddingHorizontal: 10, borderWidth: 1, borderColor: 'rgba(245,158,11,0.3)' },
  pendingBadgeTxt:{ fontSize: FontSize.xs, color: Colors.warning, fontWeight: FontWeight.bold },
  pendingBottom:  { backgroundColor: Colors.primaryBg, padding: Spacing.md, borderTopWidth: 1, borderTopColor: 'rgba(255,92,26,0.2)' },
  pendingHint:    { fontSize: FontSize.sm, color: Colors.primary, lineHeight: 18 },

  viewOfferBtn:   { backgroundColor: Colors.primaryBg, borderRadius: Radius.full, paddingVertical: 6, paddingHorizontal: 14, borderWidth: 1, borderColor: Colors.primary },
  viewOfferBtnTxt:{ fontSize: FontSize.xs, color: Colors.primary, fontWeight: FontWeight.bold },

  actionRow:      { flexDirection: 'row', gap: 10, marginTop: -4, marginBottom: Spacing.lg },
  actionBtn:      { flex: 1, backgroundColor: Colors.surface2, borderRadius: Radius.md, paddingVertical: 10, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  actionBtnPrimary:{ backgroundColor: Colors.primary, borderColor: Colors.primary },
  actionBtnTxt:   { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.text },
  ctaBox:         { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xxl, alignItems: 'center', marginBottom: Spacing.xl, borderWidth: 1, borderColor: Colors.border, borderStyle: 'dashed', gap: 8 },
  ctaTitle:       { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  ctaSub:         { fontSize: FontSize.sm, color: Colors.textMuted },
});
