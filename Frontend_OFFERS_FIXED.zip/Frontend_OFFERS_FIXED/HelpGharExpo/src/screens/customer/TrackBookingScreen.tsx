import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator, Linking, Platform, Dimensions
} from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { bookingsApi } from '../../api/services';
import { useSocket } from '../../hooks/useSocket';
import { Button, Stars, ScreenWrapper } from '../../components/common';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '../../constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function TrackBookingScreen({ navigation, route }: any) {
  const { bookingId } = route.params;
  const [booking, setBooking]       = useState<any>(null);
  const [loading, setLoading]       = useState(true);
  const [techLocation, setTechLocation] = useState<{lat:number;lng:number} | null>(null);
  const mapRef = useRef<MapView>(null);
  const { joinBookingRoom, leaveBookingRoom, on } = useSocket();

  useEffect(() => {
    load();
    joinBookingRoom(bookingId);
    const u1 = on('booking:started',   () => load());
    const u2 = on('booking:completed', () => load());
    const u3 = on('booking:price_set', () => load());
    const u4 = on('location:technician', (data: any) => {
      setTechLocation({ lat: data.latitude, lng: data.longitude });
      // Animate map to show both markers
      mapRef.current?.animateToRegion({
        latitude: data.latitude,
        longitude: data.longitude,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      }, 1000);
    });
    return () => {
      leaveBookingRoom(bookingId);
      u1?.(); u2?.(); u3?.(); u4?.();
    };
  }, [bookingId]);

  const load = async () => {
    try {
      const r = await bookingsApi.getById(bookingId);
      setBooking(r.data);
    } catch {}
    finally { setLoading(false); }
  };

  if (loading) return (
    <ScreenWrapper title="Track Booking" showBack>
      <View style={s.center}><ActivityIndicator color={Colors.primary} size="large"/></View>
    </ScreenWrapper>
  );
  if (!booking) return (
    <ScreenWrapper title="Track Booking" showBack>
      <View style={s.center}><Text style={{color:Colors.textMuted}}>Booking not found</Text></View>
    </ScreenWrapper>
  );

  const tech     = booking.technician as any;
  const techUser = tech?.user || tech;
  const custCoords = booking.customerLocation?.coordinates;
  const custLat = custCoords ? custCoords[1] : 31.5204;
  const custLng = custCoords ? custCoords[0] : 74.3587;

  const STEPS = [
    { label:'Request Sent',        done:true,                                                                    time:booking.createdAt },
    { label:'Technician Accepted', done:['accepted','en_route','in_progress','completed','confirmed'].includes(booking.status), time:booking.acceptedAt },
    { label:'En Route to You',     done:['en_route','in_progress','completed','confirmed'].includes(booking.status),            time:null },
    { label:'Job In Progress',     done:['in_progress','completed','confirmed'].includes(booking.status),                       time:booking.startedAt },
    { label:'Job Completed',       done:['completed','confirmed'].includes(booking.status),                     time:booking.completedAt },
  ];

  const fmtTime = (t?: string) => {
    if (!t) return '';
    try { return new Date(t).toLocaleTimeString('en-PK', {hour:'2-digit', minute:'2-digit'}); }
    catch { return ''; }
  };

  return (
    <ScreenWrapper title="Track Booking" showBack noPadding>
      {/* ── Google Map ── */}
      <MapView
        ref={mapRef}
        style={s.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={{
          latitude: custLat,
          longitude: custLng,
          latitudeDelta: 0.03,
          longitudeDelta: 0.03,
        }}
        showsUserLocation={true}
        showsMyLocationButton={true}
      >
        {/* Customer Location Marker */}
        <Marker
          coordinate={{ latitude: custLat, longitude: custLng }}
          title="Your Location"
          description={booking.customerLocation?.address}
          pinColor={Colors.primary}
        >
          <View style={s.markerBox}>
            <Text style={{fontSize:20}}>🏠</Text>
          </View>
        </Marker>

        {/* Technician Live Location Marker */}
        {techLocation && (
          <Marker
            coordinate={{ latitude: techLocation.lat, longitude: techLocation.lng }}
            title={techUser?.fullName || 'Technician'}
            description="Technician location"
          >
            <View style={s.techMarkerBox}>
              <Text style={{fontSize:20}}>🔧</Text>
            </View>
          </Marker>
        )}

        {/* Route line between tech and customer */}
        {techLocation && (
          <Polyline
            coordinates={[
              { latitude: techLocation.lat, longitude: techLocation.lng },
              { latitude: custLat, longitude: custLng },
            ]}
            strokeColor={Colors.primary}
            strokeWidth={3}
            lineDashPattern={[5, 5]}
          />
        )}
      </MapView>

      {/* En route banner */}
      {booking.status === 'en_route' && techLocation && (
        <View style={s.etaBanner}>
          <Text style={s.etaTxt}>🚴 Technician is on the way</Text>
        </View>
      )}

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        {/* Technician card */}
        {techUser ? (
          <View style={s.techCard}>
            <View style={s.techAvatar}><Text style={{fontSize:24}}>👨‍🔧</Text></View>
            <View style={{flex:1}}>
              <Text style={s.techName}>{techUser?.fullName || 'Technician'}</Text>
              {techUser?.averageRating > 0 && <Stars rating={techUser.averageRating}/>}
              {booking.quotedPrice && (
                <Text style={s.quotedPrice}>Quoted: ₨ {booking.quotedPrice.toLocaleString()}</Text>
              )}
            </View>
            <View style={s.techBtns}>
              <TouchableOpacity style={s.techBtn}
                onPress={() => navigation.navigate('Chat', {bookingId, otherName: techUser?.fullName || 'Technician'})}>
                <Text style={{fontSize:18}}>💬</Text>
              </TouchableOpacity>
              {techUser?.phone && (
                <TouchableOpacity style={s.techBtn} onPress={() => Linking.openURL(`tel:${techUser.phone}`)}>
                  <Text style={{fontSize:18}}>📞</Text>
                </TouchableOpacity>
              )}
              {/* Open in Google Maps */}
              {techLocation && (
                <TouchableOpacity style={s.techBtn}
                  onPress={() => {
                    const url = Platform.OS === 'ios'
                      ? `maps://?daddr=${custLat},${custLng}`
                      : `google.navigation:q=${custLat},${custLng}`;
                    Linking.openURL(url);
                  }}>
                  <Text style={{fontSize:18}}>🗺️</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ) : (
          <View style={s.waitBox}>
            <Text style={{fontSize:32}}>⏳</Text>
            <Text style={s.waitTitle}>Waiting for technician offers...</Text>
            <Text style={s.waitSub}>Technicians are reviewing your request and sending price offers.</Text>
          </View>
        )}

        {/* Status steps */}
        <Text style={s.sectionTitle}>Status Updates</Text>
        <View style={s.stepsCard}>
          {STEPS.map((step, i) => (
            <View key={i} style={s.stepRow}>
              <View style={{alignItems:'center'}}>
                <View style={[s.stepDot, step.done && s.stepDotDone]}>
                  <Text style={{fontSize:10, color: step.done ? Colors.white : Colors.textMuted}}>
                    {step.done ? '✓' : i+1}
                  </Text>
                </View>
                {i < STEPS.length-1 && <View style={[s.stepLine, step.done && s.stepLineDone]}/>}
              </View>
              <View style={{flex:1, paddingTop:2, paddingBottom: i < STEPS.length-1 ? 16 : 0}}>
                <Text style={[s.stepLabel, step.done && {color:Colors.text, fontWeight:FontWeight.semibold}]}>
                  {step.label}
                </Text>
                {step.time && <Text style={s.stepTime}>{fmtTime(step.time)}</Text>}
              </View>
            </View>
          ))}
        </View>

        {booking.status === 'completed' && (
          <Button title="✅ Confirm & Pay"
            onPress={() => navigation.navigate('BookingDetail', {bookingId})}
            style={{marginTop:8}}/>
        )}
        {['pending','accepted'].includes(booking.status) && (
          <Button title="Cancel Booking"
            onPress={() => navigation.navigate('BookingDetail', {bookingId})}
            variant="outline" style={{marginTop:8}}/>
        )}
      </ScrollView>
    </ScreenWrapper>
  );
}

const s = StyleSheet.create({
  center:        {flex:1, alignItems:'center', justifyContent:'center'},
  map:           {width:'100%', height:280},
  markerBox:     {backgroundColor:Colors.white, borderRadius:20, padding:4, borderWidth:2, borderColor:Colors.primary, shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.3, shadowRadius:4, elevation:4},
  techMarkerBox: {backgroundColor:Colors.white, borderRadius:20, padding:4, borderWidth:2, borderColor:Colors.info, shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.3, shadowRadius:4, elevation:4},
  etaBanner:     {backgroundColor:'rgba(139,92,246,0.9)', paddingVertical:8, paddingHorizontal:16, alignItems:'center'},
  etaTxt:        {fontSize:FontSize.sm, color:Colors.white, fontWeight:FontWeight.semibold},
  scroll:        {padding:Spacing.xl, paddingBottom:40},
  techCard:      {flexDirection:'row', alignItems:'center', gap:12, backgroundColor:Colors.surface, borderRadius:Radius.lg, padding:Spacing.lg, borderWidth:1, borderColor:'rgba(59,130,246,0.4)', marginBottom:Spacing.xl},
  techAvatar:    {width:46, height:46, borderRadius:23, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center'},
  techName:      {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text},
  quotedPrice:   {fontSize:FontSize.sm, color:Colors.primary, fontWeight:FontWeight.semibold, marginTop:2},
  techBtns:      {flexDirection:'row', gap:8},
  techBtn:       {width:36, height:36, borderRadius:18, backgroundColor:Colors.surface2, alignItems:'center', justifyContent:'center', borderWidth:1, borderColor:Colors.border},
  waitBox:       {alignItems:'center', backgroundColor:Colors.surface, borderRadius:Radius.xl, padding:Spacing.xxl, borderWidth:1, borderColor:Colors.border, marginBottom:Spacing.xl, gap:8},
  waitTitle:     {fontSize:FontSize.lg, fontWeight:FontWeight.bold, color:Colors.text, textAlign:'center'},
  waitSub:       {fontSize:FontSize.sm, color:Colors.textMuted, textAlign:'center', lineHeight:18},
  sectionTitle:  {fontSize:FontSize.md, fontWeight:FontWeight.bold, color:Colors.text, marginBottom:12},
  stepsCard:     {backgroundColor:Colors.surface, borderRadius:Radius.lg, borderWidth:1, borderColor:Colors.border, padding:Spacing.lg, marginBottom:Spacing.lg},
  stepRow:       {flexDirection:'row', gap:12},
  stepDot:       {width:22, height:22, borderRadius:11, backgroundColor:Colors.surface3, alignItems:'center', justifyContent:'center', flexShrink:0},
  stepDotDone:   {backgroundColor:Colors.success},
  stepLine:      {width:2, flex:1, backgroundColor:Colors.surface3, marginVertical:3},
  stepLineDone:  {backgroundColor:Colors.success},
  stepLabel:     {fontSize:FontSize.sm, color:Colors.textMuted},
  stepTime:      {fontSize:FontSize.xs, color:Colors.textMuted, marginTop:2},
});
