# HelpGhar Setup Guide

## 1. Google Maps API Key Setup

### Step 1: Get API Key
1. Go to: https://console.cloud.google.com
2. Create new project: "HelpGhar"
3. Enable these APIs:
   - Maps SDK for Android
   - Maps SDK for iOS
   - Directions API
   - Geocoding API
4. Go to "Credentials" → "Create API Key"
5. Copy your API key

### Step 2: Add to app.json
Replace in app.json:
```json
"YOUR_ANDROID_GOOGLE_MAPS_API_KEY" → your actual key
"YOUR_IOS_GOOGLE_MAPS_API_KEY"     → your actual key
```

### Step 3: Install
```bash
npm install react-native-maps
npx expo start --clear
```

---

## 2. FCM Push Notifications Setup

### Step 1: Create Firebase Project
1. Go to: https://console.firebase.google.com
2. Create new project: "HelpGhar"
3. Add Android app: com.helpghar.app
4. Download google-services.json → put in HelpGharExpo/

### Step 2: Get Expo Project ID
```bash
npx expo login
npx eas init
```
Copy projectId from app.json → extra.eas.projectId

### Step 3: Update in code
In src/hooks/usePushNotifications.ts:
```ts
projectId: 'your-actual-expo-project-id'
```

### Step 4: Backend FCM (optional - for background notifications)
Install in backend:
```bash
npm install firebase-admin
```

Add to .env:
```
FIREBASE_SERVICE_ACCOUNT_PATH=./firebase-service-account.json
```

---

## 3. CNIC Upload (Cloudinary)

### Step 1: Create Cloudinary Account
1. Go to: https://cloudinary.com (free)
2. Get: Cloud Name, API Key, API Secret

### Step 2: Add to backend .env
```
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### Step 3: Install in backend
```bash
npm install cloudinary multer-storage-cloudinary
```

---

## 4. Payment Gateway (JazzCash)

### For Testing (Current Implementation)
- Manual transaction ID entry
- Works immediately without merchant account

### For Production
1. Apply at: https://sandbox.jazzcash.com.pk
2. Get: Merchant ID, Password, Integrity Salt
3. Add to backend .env:
```
JAZZCASH_MERCHANT_ID=your_merchant_id
JAZZCASH_PASSWORD=your_password
JAZZCASH_INTEGRITY_KEY=your_salt
```

---

## 5. Run Commands

### Backend
```bash
cd helpghar-backend
cp .env.example .env
# Edit .env with your values
npm install
npm run start:dev
```

### Frontend
```bash
cd HelpGharExpo
npm install
# Edit src/constants/api.ts with your IP
npx expo start --clear
```

---

## 6. Test Accounts
```
Customer:   ali@example.com   / Password@123
Technician: imran@example.com / Password@123
Admin:      admin@helpghar.com / Password@123
```
